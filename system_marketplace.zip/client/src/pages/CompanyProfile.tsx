import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { SystemHeader } from "@/components/SystemHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Building2, Save, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function CompanyProfile() {
  const { data: profile, refetch } = trpc.companyProfile.getProfile.useQuery();
  const upsertProfile = trpc.companyProfile.upsertProfile.useMutation({
    onSuccess: () => {
      toast.success("会社プロフィールを保存しました");
      refetch();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const createInitialProfile = trpc.companyProfile.createInitialProfile.useMutation({
    onSuccess: () => {
      toast.success("初期プロフィールを作成しました");
      refetch();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    upsertProfile.mutate({
      companyName: formData.get("companyName") as string,
      companyNameKana: formData.get("companyNameKana") as string || undefined,
      postalCode: formData.get("postalCode") as string || undefined,
      address: formData.get("address") as string || undefined,
      phone: formData.get("phone") as string || undefined,
      fax: formData.get("fax") as string || undefined,
      email: formData.get("email") as string || undefined,
      website: formData.get("website") as string || undefined,
      logoUrl: formData.get("logoUrl") as string || undefined,
      bankName: formData.get("bankName") as string || undefined,
      branchName: formData.get("branchName") as string || undefined,
      accountType: formData.get("accountType") as string || undefined,
      accountNumber: formData.get("accountNumber") as string || undefined,
      accountHolder: formData.get("accountHolder") as string || undefined,
      representativeName: formData.get("representativeName") as string || undefined,
      representativeTitle: formData.get("representativeTitle") as string || undefined,
      businessNumber: formData.get("businessNumber") as string || undefined,
      taxIdNumber: formData.get("taxIdNumber") as string || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <SystemHeader />
      
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
            <Building2 className="h-8 w-8 text-blue-600" />
            会社プロフィール設定
          </h1>
          <p className="text-gray-600">
            見積書・請求書に表示される自社情報を設定します
          </p>
        </div>

        {!profile && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-blue-900 mb-1">
                    まだプロフィールが作成されていません
                  </p>
                  <p className="text-sm text-blue-700">
                    ユーザー情報から初期プロフィールを自動作成できます
                  </p>
                </div>
                <Button
                  onClick={() => createInitialProfile.mutate()}
                  disabled={createInitialProfile.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  初期プロフィール作成
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 基本情報 */}
          <Card>
            <CardHeader>
              <CardTitle>基本情報</CardTitle>
              <CardDescription>会社の基本的な情報を入力してください</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="companyName">会社名 *</Label>
                  <Input
                    id="companyName"
                    name="companyName"
                    defaultValue={profile?.companyName}
                    required
                    placeholder="株式会社サンプル"
                  />
                </div>
                <div>
                  <Label htmlFor="companyNameKana">会社名（カナ）</Label>
                  <Input
                    id="companyNameKana"
                    name="companyNameKana"
                    defaultValue={profile?.companyNameKana || ""}
                    placeholder="カブシキガイシャサンプル"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="postalCode">郵便番号</Label>
                  <Input
                    id="postalCode"
                    name="postalCode"
                    defaultValue={profile?.postalCode || ""}
                    placeholder="123-4567"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">電話番号</Label>
                  <Input
                    id="phone"
                    name="phone"
                    defaultValue={profile?.phone || ""}
                    placeholder="03-1234-5678"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">住所</Label>
                <Textarea
                  id="address"
                  name="address"
                  defaultValue={profile?.address || ""}
                  rows={2}
                  placeholder="東京都渋谷区..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">メールアドレス</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    defaultValue={profile?.email || ""}
                    placeholder="info@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="fax">FAX番号</Label>
                  <Input
                    id="fax"
                    name="fax"
                    defaultValue={profile?.fax || ""}
                    placeholder="03-1234-5679"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="website">ウェブサイト</Label>
                  <Input
                    id="website"
                    name="website"
                    type="url"
                    defaultValue={profile?.website || ""}
                    placeholder="https://example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="logoUrl">ロゴURL</Label>
                  <Input
                    id="logoUrl"
                    name="logoUrl"
                    type="url"
                    defaultValue={profile?.logoUrl || ""}
                    placeholder="https://example.com/logo.png"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 代表者情報 */}
          <Card>
            <CardHeader>
              <CardTitle>代表者情報</CardTitle>
              <CardDescription>代表者の情報を入力してください</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="representativeName">代表者名</Label>
                  <Input
                    id="representativeName"
                    name="representativeName"
                    defaultValue={profile?.representativeName || ""}
                    placeholder="山田 太郎"
                  />
                </div>
                <div>
                  <Label htmlFor="representativeTitle">役職</Label>
                  <Input
                    id="representativeTitle"
                    name="representativeTitle"
                    defaultValue={profile?.representativeTitle || ""}
                    placeholder="代表取締役"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 銀行情報 */}
          <Card>
            <CardHeader>
              <CardTitle>銀行情報</CardTitle>
              <CardDescription>請求書に表示する振込先情報を入力してください</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="bankName">銀行名</Label>
                  <Input
                    id="bankName"
                    name="bankName"
                    defaultValue={profile?.bankName || ""}
                    placeholder="〇〇銀行"
                  />
                </div>
                <div>
                  <Label htmlFor="branchName">支店名</Label>
                  <Input
                    id="branchName"
                    name="branchName"
                    defaultValue={profile?.branchName || ""}
                    placeholder="〇〇支店"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="accountType">口座種別</Label>
                  <Input
                    id="accountType"
                    name="accountType"
                    defaultValue={profile?.accountType || ""}
                    placeholder="普通"
                  />
                </div>
                <div>
                  <Label htmlFor="accountNumber">口座番号</Label>
                  <Input
                    id="accountNumber"
                    name="accountNumber"
                    defaultValue={profile?.accountNumber || ""}
                    placeholder="1234567"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="accountHolder">口座名義</Label>
                <Input
                  id="accountHolder"
                  name="accountHolder"
                  defaultValue={profile?.accountHolder || ""}
                  placeholder="カ）サンプル"
                />
              </div>
            </CardContent>
          </Card>

          {/* その他の情報 */}
          <Card>
            <CardHeader>
              <CardTitle>その他の情報</CardTitle>
              <CardDescription>法人番号やインボイス番号などを入力してください</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="businessNumber">法人番号</Label>
                  <Input
                    id="businessNumber"
                    name="businessNumber"
                    defaultValue={profile?.businessNumber || ""}
                    placeholder="1234567890123"
                  />
                </div>
                <div>
                  <Label htmlFor="taxIdNumber">適格請求書発行事業者登録番号</Label>
                  <Input
                    id="taxIdNumber"
                    name="taxIdNumber"
                    defaultValue={profile?.taxIdNumber || ""}
                    placeholder="T1234567890123"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button
              type="submit"
              size="lg"
              disabled={upsertProfile.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Save className="h-5 w-5 mr-2" />
              保存
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
