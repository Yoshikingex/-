import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { getSystemRoute } from "@/../../shared/system-routes";
import { 
  Sparkles, 
  ArrowLeft,
  Music,
  Users,
  Clock,
  CreditCard,
  ShoppingCart,
  Calendar,
  MessageSquare,
  Image as ImageIcon,
  Video,
  Play,
  Share2,
  TrendingUp,
  Mail,
  Bot,
  FileText,
  Receipt,
  Briefcase,
  BarChart3,
  FileCheck,
  Search,
  Workflow,
  Loader2,
  Download,
} from "lucide-react";

const iconMap: Record<string, any> = {
  Music,
  Users,
  Clock,
  CreditCard,
  ShoppingCart,
  Calendar,
  MessageSquare,
  Image: ImageIcon,
  Video,
  Share2,
  TrendingUp,
  Mail,
  Bot,
  FileText,
  Receipt,
  Briefcase,
  BarChart3,
  FileCheck,
  Search,
  Workflow,
};

export default function Systems() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { data: systems, isLoading } = trpc.systems.getAll.useQuery();
  const { data: userSystems } = trpc.systems.getUserSystems.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: currentPlan } = trpc.plans.getCurrent.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const userSystemIds = new Set(userSystems?.map(us => us.systemId) || []);

  const categories = [
    { id: "all", label: "すべて" },
    { id: "ai", label: "AI技術" },
    { id: "management", label: "業務管理" },
    { id: "marketing", label: "マーケティング" },
    { id: "automation", label: "自動化" },
  ];

  const filteredSystems = (category: string) => {
    if (!systems) return [];
    if (category === "all") return systems;
    return systems.filter(s => s.category === category);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="ghost">ダッシュボード</Button>
                </Link>
                {user?.role === 'admin' && (
                  <Link href="/admin">
                    <Button variant="outline">管理画面</Button>
                  </Link>
                )}
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button variant="default">ログイン / 新規登録</Button>
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              システム一覧
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl">
              20種類の業務効率化システムから、ビジネスに必要なものを選択できます。
            </p>
            {isAuthenticated && currentPlan && (
              <div className="mt-6 flex items-center gap-4">
                <Badge className="text-base px-4 py-2 bg-primary text-primary-foreground">
                  現在のプラン: {currentPlan.name}
                </Badge>
                <span className="text-muted-foreground">
                  利用可能: {userSystemIds.size} / {currentPlan.systemLimit} システム
                </span>
              </div>
            )}
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-8">
                {categories.map(cat => (
                  <TabsTrigger key={cat.id} value={cat.id}>
                    {cat.label}
                  </TabsTrigger>
                ))}
              </TabsList>

              {categories.map(cat => (
                <TabsContent key={cat.id} value={cat.id}>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredSystems(cat.id).map(system => {
                      const Icon = iconMap[system.icon] || Sparkles;
                      const isSelected = userSystemIds.has(system.id);

                      return (
                        <Card 
                          key={system.id} 
                          className={`border-2 transition-all hover:shadow-lg cursor-pointer ${
                            isSelected ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
                          }`}
                          onClick={() => window.location.href = `/system/${system.id}`}
                        >
                          <CardHeader>
                            <div className="flex items-start justify-between mb-4">
                              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                                <Icon className="w-7 h-7 text-white" />
                              </div>
                              {isSelected && (
                                <Badge className="bg-accent text-accent-foreground">
                                  利用中
                                </Badge>
                              )}
                            </div>
                            <CardTitle className="text-xl mb-2">{system.name}</CardTitle>
                            <Badge variant="secondary" className="w-fit mb-2">
                              {system.category === 'ai' && 'AI技術'}
                              {system.category === 'management' && '業務管理'}
                              {system.category === 'marketing' && 'マーケティング'}
                              {system.category === 'automation' && '自動化'}
                            </Badge>
                          </CardHeader>
                          <CardContent>
                            <CardDescription className="text-base mb-4">
                              {system.description}
                            </CardDescription>
                            <div className="space-y-2">
                              <Button 
                                variant="default" 
                                className="w-full"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setLocation(getSystemRoute(system.id));
                                }}
                              >
                                <Play className="w-4 h-4 mr-2" />
                                利用する
                              </Button>
                              <Link href={`/system/${system.id}`}>
                                <Button variant="outline" className="w-full">
                                  詳細を見る
                                </Button>
                              </Link>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          )}

          {/* CTA Section */}
          {!isAuthenticated && (
            <div className="mt-16 text-center py-12 bg-gradient-to-br from-primary to-accent rounded-2xl text-primary-foreground">
              <h2 className="text-3xl font-bold mb-4">
                今すぐ始めましょう
              </h2>
              <p className="text-lg mb-6 opacity-90">
                月額29,800円から、必要なシステムを自由に選択
              </p>
              <div className="flex gap-4 justify-center">
                <a href={getLoginUrl()}>
                  <Button size="lg" variant="secondary" className="text-lg px-8">
                    無料で始める
                  </Button>
                </a>
                <Link href="/pricing">
                  <Button size="lg" variant="outline" className="text-lg px-8 bg-transparent text-primary-foreground border-primary-foreground hover:bg-primary-foreground/10">
                    料金プランを見る
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
