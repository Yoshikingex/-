import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

function createNonAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("pdfGenerator.generateSystemPDF", () => {
  it("管理者はPDFを生成できる", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    // システムID 1のPDFを生成（実際のシステムが存在する場合）
    try {
      const result = await caller.pdfGenerator.generateSystemPDF({ systemId: 1 });
      
      expect(result).toHaveProperty("pdfBase64");
      expect(result).toHaveProperty("fileName");
      expect(typeof result.pdfBase64).toBe("string");
      expect(result.pdfBase64.length).toBeGreaterThan(0);
      expect(result.fileName).toContain(".pdf");
    } catch (error: any) {
      // システムが存在しない場合はNOT_FOUNDエラーが返る
      expect(error.code).toBe("NOT_FOUND");
    }
  });

  it("管理者以外はPDFを生成できない", async () => {
    const { ctx } = createNonAdminContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.pdfGenerator.generateSystemPDF({ systemId: 1 })
    ).rejects.toThrow();
  });
});
