ALTER TABLE `systems` ADD `file_url` varchar(500);--> statement-breakpoint
ALTER TABLE `systems` ADD `file_name` varchar(255);--> statement-breakpoint
ALTER TABLE `systems` ADD `file_size` int;--> statement-breakpoint
ALTER TABLE `systems` ADD `file_type` varchar(50);