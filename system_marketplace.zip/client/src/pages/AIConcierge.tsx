import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { Sparkles, ArrowLeft, Send, Bot, User, Loader2 } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

type Message = {
  role: "user" | "assistant";
  content: string;
};

export default function AIConcierge() {
  const { user, isAuthenticated } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [recommendedSystemIds, setRecommendedSystemIds] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const recommendMutation = trpc.aiConcierge.recommend.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.message }]);
      setRecommendedSystemIds(data.recommendedSystemIds);
    },
    onError: (error) => {
      toast.error("エラーが発生しました: " + error.message);
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = { role: "user", content: inputMessage };
    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");

    await recommendMutation.mutateAsync({
      userMessage: inputMessage,
      conversationHistory: messages,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">System Marketplace</span>
              </div>
            </div>
            <a href={getLoginUrl()}>
              <Button variant="default">ログイン / 新規登録</Button>
            </a>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center py-12">
          <Card className="max-w-md">
            <CardHeader>
              <CardTitle>ログインが必要です</CardTitle>
              <CardDescription>
                AIコンシェルジュを利用するには、ログインしてください。
              </CardDescription>
            </CardHeader>
            <CardContent>
              <a href={getLoginUrl()}>
                <Button variant="default" className="w-full">
                  ログイン / 新規登録
                </Button>
              </a>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Bot className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">AIコンシェルジュ</span>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/systems">
              <Button variant="ghost">システム一覧</Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">ダッシュボード</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col py-6">
        <div className="container mx-auto px-4 flex-1 flex flex-col max-w-4xl">
          {/* Welcome Message */}
          {messages.length === 0 && (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center max-w-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Bot className="w-10 h-10 text-primary-foreground" />
                </div>
                <h1 className="text-3xl font-bold mb-4 text-foreground">
                  🧠 AIコンシェルジュ
                </h1>
                <p className="text-lg text-muted-foreground mb-8">
                  あなたの業務内容や課題をお聞かせください。最適なシステムを提案いたします。
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-left">
                  <Card className="cursor-pointer hover:border-primary transition-all" onClick={() => setInputMessage("事務作業を効率化したいです")}>
                    <CardHeader>
                      <CardTitle className="text-base">事務作業を効率化したい</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card className="cursor-pointer hover:border-primary transition-all" onClick={() => setInputMessage("営業メールの作成を自動化したいです")}>
                    <CardHeader>
                      <CardTitle className="text-base">営業メールを自動化したい</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card className="cursor-pointer hover:border-primary transition-all" onClick={() => setInputMessage("顧客管理を改善したいです")}>
                    <CardHeader>
                      <CardTitle className="text-base">顧客管理を改善したい</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card className="cursor-pointer hover:border-primary transition-all" onClick={() => setInputMessage("SNSの投稿を自動化したいです")}>
                    <CardHeader>
                      <CardTitle className="text-base">SNS投稿を自動化したい</CardTitle>
                    </CardHeader>
                  </Card>
                </div>
              </div>
            </div>
          )}

          {/* Chat Messages */}
          {messages.length > 0 && (
            <div className="flex-1 overflow-y-auto mb-4 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-primary-foreground" />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-card border"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      <Streamdown>{message.content}</Streamdown>
                    ) : (
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    )}
                  </div>
                  {message.role === "user" && (
                    <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}
              {recommendMutation.isPending && (
                <div className="flex gap-3 justify-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div className="bg-card border rounded-2xl px-4 py-3">
                    <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Recommended Systems */}
          {recommendedSystemIds.length > 0 && (
            <div className="mb-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">推薦されたシステム</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {recommendedSystemIds.map((systemId) => (
                      <Link key={systemId} href={`/system/${systemId}`}>
                        <Button variant="outline" size="sm">
                          {systemId} →
                        </Button>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Input Area */}
          <div className="border-t pt-4">
            <div className="flex gap-2">
              <Input
                placeholder="業務内容や課題を入力してください..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={recommendMutation.isPending}
                className="flex-1"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || recommendMutation.isPending}
                size="icon"
              >
                {recommendMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
