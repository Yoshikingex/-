import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { getDb } from "./db";
import { systems } from "../drizzle/schema";

export const aiConciergeRouter = router({
  /**
   * ユーザーの業務内容をヒアリングし、最適なシステムを推薦
   */
  recommend: protectedProcedure
    .input(
      z.object({
        userMessage: z.string().min(1, "メッセージを入力してください"),
        conversationHistory: z.array(
          z.object({
            role: z.enum(["user", "assistant"]),
            content: z.string(),
          })
        ).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // 全システムを取得
      const allSystems = await db.select().from(systems);

      // システム情報をLLMに渡すためのコンテキスト
      const systemsContext = allSystems
        .map(
          (sys) =>
            `- ${sys.name}: ${sys.description} [カテゴリー: ${sys.category}]`
        )
        .join("\n");

      // 会話履歴を構築
      const messages: Array<{
        role: "system" | "user" | "assistant";
        content: string;
      }> = [
        {
          role: "system",
          content: `あなたは業務効率化システムの専門コンシェルジュです。ユーザーの業務内容や課題をヒアリングし、最適なシステムを推薦してください。

【利用可能なシステム一覧】
${systemsContext}

【推薦の方針】
1. ユーザーの業務内容を丁寧にヒアリングする
2. 具体的な課題を明確にする
3. 最適なシステムを3～5個推薦する
4. 各システムの具体的な活用方法を提案する
5. 個人事業主・中小企業向けに分かりやすく説明する

【対象ユーザー】
- 個人事業主
- 中小企業
- 主な課題: 事務作業の効率化、営業メール作成の自動化

フレンドリーで親しみやすいトーンで対応してください。`,
        },
        ...(input.conversationHistory || []),
        {
          role: "user",
          content: input.userMessage,
        },
      ];

      // LLMを呼び出し
      const response = await invokeLLM({
        messages: messages as any,
      });

      const assistantMessage = String(response.choices[0]?.message?.content || "申し訳ございません。エラーが発生しました。");

      // 推薦されたシステムを抽出（システム名が含まれているかチェック）
      const recommendedSystemIds: number[] = [];
      for (const sys of allSystems) {
        const sysName = String(sys.name || "");
        if (sysName && assistantMessage.indexOf(sysName) !== -1) {
          recommendedSystemIds.push(sys.id);
        }
      }

      return {
        message: assistantMessage,
        recommendedSystemIds,
      };
    }),

  /**
   * 会話履歴を保存
   */
  saveConversation: protectedProcedure
    .input(
      z.object({
        conversationHistory: z.array(
          z.object({
            role: z.enum(["user", "assistant"]),
            content: z.string(),
          })
        ),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // TODO: 会話履歴をデータベースに保存する実装
      // 現在はクライアント側でlocalStorageに保存
      return {
        success: true,
      };
    }),
});
