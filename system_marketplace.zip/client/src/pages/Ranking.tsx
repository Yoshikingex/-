import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Loader2, Trophy, TrendingUp, Download, Users, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Ranking() {
  const { data: popularSystems, isLoading: popularLoading } = trpc.ranking.getPopularSystems.useQuery({ limit: 10 });
  const { data: categoryRankings, isLoading: categoryLoading } = trpc.ranking.getCategoryRankings.useQuery();

  const isLoading = popularLoading || categoryLoading;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                ホームに戻る
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Trophy className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </div>
          <nav className="flex items-center gap-4 mt-4">
            <Link href="/systems">
              <Button variant="ghost">システム一覧</Button>
            </Link>
            <Link href="/pricing">
              <Button variant="ghost">料金プラン</Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="outline">ダッシュボード</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl mb-6">
              <Trophy className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              人気ランキング
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              最も人気のある業務効率化システムをチェックしましょう
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-12">
              {/* ダウンロード数ランキング */}
              <section>
                <div className="flex items-center gap-3 mb-6">
                  <Download className="w-6 h-6 text-primary" />
                  <h2 className="text-3xl font-bold text-foreground">ダウンロード数ランキング TOP10</h2>
                </div>
                <div className="grid gap-4">
                  {popularSystems?.map((item) => (
                    <Link key={item.system.id} href={`/system/${item.system.id}`}>
                      <Card className="hover:shadow-lg transition-all cursor-pointer border-2 hover:border-primary">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-6">
                            {/* ランク */}
                            <div className="flex-shrink-0">
                              {item.rank <= 3 ? (
                                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold ${
                                  item.rank === 1 ? 'bg-yellow-500 text-yellow-900' :
                                  item.rank === 2 ? 'bg-gray-400 text-gray-900' :
                                  'bg-orange-600 text-orange-100'
                                }`}>
                                  {item.rank}
                                </div>
                              ) : (
                                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-2xl font-bold text-muted-foreground">
                                  {item.rank}
                                </div>
                              )}
                            </div>

                            {/* システム情報 */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-xl font-bold text-foreground truncate">
                                  {item.system.name}
                                </h3>
                                <Badge variant="outline">{item.system.category}</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {item.system.description}
                              </p>
                            </div>

                            {/* ダウンロード数 */}
                            <div className="flex-shrink-0 text-right">
                              <div className="flex items-center gap-2 text-primary">
                                <Download className="w-5 h-5" />
                                <span className="text-2xl font-bold">{item.downloadCount}</span>
                              </div>
                              <p className="text-sm text-muted-foreground">ダウンロード</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </section>

              {/* カテゴリー別ランキング */}
              <section>
                <div className="flex items-center gap-3 mb-6">
                  <TrendingUp className="w-6 h-6 text-primary" />
                  <h2 className="text-3xl font-bold text-foreground">カテゴリー別ランキング</h2>
                </div>
                <div className="grid lg:grid-cols-2 gap-8">
                  {categoryRankings?.map((categoryData) => (
                    <Card key={categoryData.category}>
                      <CardHeader>
                        <CardTitle className="text-xl">{categoryData.category}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {categoryData.systems.map((item) => (
                            <Link key={item.system.id} href={`/system/${item.system.id}`}>
                              <div className="flex items-center gap-4 p-4 rounded-lg hover:bg-accent transition-colors cursor-pointer">
                                {/* ランク */}
                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                                  {item.rank}
                                </div>

                                {/* システム名 */}
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-semibold text-foreground truncate">
                                    {item.system.name}
                                  </h4>
                                </div>

                                {/* ダウンロード数 */}
                                <div className="flex-shrink-0 flex items-center gap-1 text-sm text-muted-foreground">
                                  <Download className="w-4 h-4" />
                                  <span>{item.downloadCount}</span>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
