CREATE TABLE `invoice_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoice_id` int NOT NULL,
	`item_name` varchar(255) NOT NULL,
	`description` text,
	`quantity` int NOT NULL,
	`unit_price` int NOT NULL,
	`amount` int NOT NULL,
	`sort_order` int NOT NULL DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `invoice_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`invoice_number` varchar(100) NOT NULL,
	`quotation_id` int,
	`customer_id` int,
	`customer_name` varchar(255) NOT NULL,
	`customer_email` varchar(320),
	`customer_address` text,
	`title` varchar(255) NOT NULL,
	`issue_date` timestamp NOT NULL,
	`due_date` timestamp NOT NULL,
	`subtotal` int NOT NULL,
	`tax_rate` int NOT NULL DEFAULT 10,
	`tax_amount` int NOT NULL,
	`total_amount` int NOT NULL,
	`payment_method` varchar(100),
	`bank_info` text,
	`notes` text,
	`status` enum('draft','sent','paid','overdue','canceled') NOT NULL DEFAULT 'draft',
	`paid_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_invoice_number_unique` UNIQUE(`invoice_number`)
);
--> statement-breakpoint
CREATE TABLE `quotation_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`quotation_id` int NOT NULL,
	`item_name` varchar(255) NOT NULL,
	`description` text,
	`quantity` int NOT NULL,
	`unit_price` int NOT NULL,
	`amount` int NOT NULL,
	`sort_order` int NOT NULL DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quotation_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quotations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`quotation_number` varchar(100) NOT NULL,
	`customer_id` int,
	`customer_name` varchar(255) NOT NULL,
	`customer_email` varchar(320),
	`customer_address` text,
	`title` varchar(255) NOT NULL,
	`issue_date` timestamp NOT NULL,
	`expiry_date` timestamp,
	`subtotal` int NOT NULL,
	`tax_rate` int NOT NULL DEFAULT 10,
	`tax_amount` int NOT NULL,
	`total_amount` int NOT NULL,
	`notes` text,
	`status` enum('draft','sent','accepted','rejected') NOT NULL DEFAULT 'draft',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `quotations_id` PRIMARY KEY(`id`),
	CONSTRAINT `quotations_quotation_number_unique` UNIQUE(`quotation_number`)
);
