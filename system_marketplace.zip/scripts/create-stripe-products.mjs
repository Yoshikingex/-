import Stripe from 'stripe';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables
dotenv.config({ path: join(__dirname, '..', '.env') });

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2025-12-15.clover',
});

async function createProducts() {
  console.log('🚀 Stripe商品作成スクリプトを開始します...\n');

  try {
    // スタータープラン
    console.log('📦 スタータープランを作成中...');
    const starterProduct = await stripe.products.create({
      name: 'スターター',
      description: '5個のシステムを利用可能な基本プラン',
      metadata: {
        plan_id: 'starter',
        system_limit: '5',
      },
    });
    console.log(`✅ 商品作成完了: ${starterProduct.id}`);

    const starterPrice = await stripe.prices.create({
      product: starterProduct.id,
      unit_amount: 2980000, // 29,800円（セント単位）
      currency: 'jpy',
      recurring: {
        interval: 'month',
      },
      metadata: {
        plan_id: 'starter',
      },
    });
    console.log(`✅ 価格作成完了: ${starterPrice.id}\n`);

    // ビジネスプラン
    console.log('📦 ビジネスプランを作成中...');
    const businessProduct = await stripe.products.create({
      name: 'ビジネス',
      description: '12個のシステムを利用可能な中規模企業向けプラン',
      metadata: {
        plan_id: 'business',
        system_limit: '12',
      },
    });
    console.log(`✅ 商品作成完了: ${businessProduct.id}`);

    const businessPrice = await stripe.prices.create({
      product: businessProduct.id,
      unit_amount: 5980000, // 59,800円（セント単位）
      currency: 'jpy',
      recurring: {
        interval: 'month',
      },
      metadata: {
        plan_id: 'business',
      },
    });
    console.log(`✅ 価格作成完了: ${businessPrice.id}\n`);

    // エンタープライズプラン
    console.log('📦 エンタープライズプランを作成中...');
    const enterpriseProduct = await stripe.products.create({
      name: 'エンタープライズ',
      description: '全20個のシステムを利用可能な大規模企業向けプラン',
      metadata: {
        plan_id: 'enterprise',
        system_limit: '20',
      },
    });
    console.log(`✅ 商品作成完了: ${enterpriseProduct.id}`);

    const enterprisePrice = await stripe.prices.create({
      product: enterpriseProduct.id,
      unit_amount: 9980000, // 99,800円（セント単位）
      currency: 'jpy',
      recurring: {
        interval: 'month',
      },
      metadata: {
        plan_id: 'enterprise',
      },
    });
    console.log(`✅ 価格作成完了: ${enterprisePrice.id}\n`);

    // 結果をまとめて表示
    console.log('=' .repeat(60));
    console.log('🎉 すべての商品と価格の作成が完了しました！\n');
    console.log('以下のPrice IDをserver/products.tsに設定してください：\n');
    console.log('export const STRIPE_PRODUCTS = {');
    console.log(`  starter: {`);
    console.log(`    productId: '${starterProduct.id}',`);
    console.log(`    priceId: '${starterPrice.id}',`);
    console.log(`  },`);
    console.log(`  business: {`);
    console.log(`    productId: '${businessProduct.id}',`);
    console.log(`    priceId: '${businessPrice.id}',`);
    console.log(`  },`);
    console.log(`  enterprise: {`);
    console.log(`    productId: '${enterpriseProduct.id}',`);
    console.log(`    priceId: '${enterprisePrice.id}',`);
    console.log(`  },`);
    console.log('};');
    console.log('=' .repeat(60));

    // ファイルに保存
    const fs = await import('fs');
    const outputPath = join(__dirname, 'stripe-product-ids.txt');
    const output = `Stripe Product IDs (作成日時: ${new Date().toLocaleString('ja-JP')})

スターター:
  Product ID: ${starterProduct.id}
  Price ID: ${starterPrice.id}

ビジネス:
  Product ID: ${businessProduct.id}
  Price ID: ${businessPrice.id}

エンタープライズ:
  Product ID: ${enterpriseProduct.id}
  Price ID: ${enterprisePrice.id}

server/products.tsに以下をコピーしてください：

export const STRIPE_PRODUCTS = {
  starter: {
    productId: '${starterProduct.id}',
    priceId: '${starterPrice.id}',
  },
  business: {
    productId: '${businessProduct.id}',
    priceId: '${businessPrice.id}',
  },
  enterprise: {
    productId: '${enterpriseProduct.id}',
    priceId: '${enterprisePrice.id}',
  },
};
`;

    fs.writeFileSync(outputPath, output, 'utf-8');
    console.log(`\n📄 Price IDを ${outputPath} に保存しました`);

  } catch (error) {
    console.error('❌ エラーが発生しました:', error);
    process.exit(1);
  }
}

createProducts();
