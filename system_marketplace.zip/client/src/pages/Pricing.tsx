import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { toast } from "sonner";
import { 
  Sparkles, 
  ArrowLeft,
  Check,
  Loader2,
} from "lucide-react";

export default function Pricing() {
  const { isAuthenticated } = useAuth();
  const { data: plans, isLoading } = trpc.plans.getAll.useQuery();
  const { data: currentPlan } = trpc.plans.getCurrent.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const createCheckoutSession = trpc.checkout.createSession.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        toast.success('決済ページに移動します...');
        window.open(data.url, '_blank');
      }
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const handleSubscribe = (planId: string) => {
    createCheckoutSession.mutate({ planId });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/systems">
                  <Button variant="ghost">システム一覧</Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="default">ダッシュボード</Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button variant="default">ログイン / 新規登録</Button>
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              シンプルで透明性の高い料金プラン
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              ビジネスの規模に合わせて最適なプランを選択できます。
              いつでもプランの変更・キャンセルが可能です。
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {plans?.map(plan => {
                const isCurrentPlan = currentPlan?.id === plan.id;
                const isPopular = plan.popular;

                return (
                  <Card 
                    key={plan.id} 
                    className={`relative border-2 transition-all ${
                      isPopular 
                        ? 'border-primary shadow-lg scale-105' 
                        : isCurrentPlan
                        ? 'border-accent'
                        : 'hover:border-primary/50'
                    }`}
                  >
                    {isPopular && (
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                        <Badge className="bg-primary text-primary-foreground text-sm px-4 py-1">
                          人気No.1
                        </Badge>
                      </div>
                    )}
                    {isCurrentPlan && (
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                        <Badge className="bg-accent text-accent-foreground text-sm px-4 py-1">
                          現在のプラン
                        </Badge>
                      </div>
                    )}
                    
                    <CardHeader className="text-center pb-8">
                      <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                      <div className="mb-4">
                        <span className="text-4xl font-bold text-foreground">
                          ¥{plan.price.toLocaleString()}
                        </span>
                        <span className="text-muted-foreground">/月</span>
                      </div>
                      <CardDescription className="text-base">
                        {plan.systemLimit}個のシステムを利用可能
                      </CardDescription>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <div className="w-5 h-5 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <Check className="w-3 h-3 text-accent" />
                          </div>
                          <span className="text-sm text-foreground">{feature}</span>
                        </div>
                      ))}
                    </CardContent>

                    <CardFooter>
                      {isAuthenticated ? (
                        isCurrentPlan ? (
                          <Button variant="outline" className="w-full" disabled>
                            現在のプラン
                          </Button>
                        ) : (
                          <Button 
                            variant={isPopular ? "default" : "outline"} 
                            className="w-full"
                            onClick={() => handleSubscribe(plan.id)}
                            disabled={createCheckoutSession.isPending}
                          >
                            {createCheckoutSession.isPending ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                処理中...
                              </>
                            ) : (
                              'このプランに変更'
                            )}
                          </Button>
                        )
                      ) : (
                        <a href={getLoginUrl()} className="w-full">
                          <Button 
                            variant={isPopular ? "default" : "outline"} 
                            className="w-full"
                          >
                            始める
                          </Button>
                        </a>
                      )}
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          )}

          {/* FAQ Section */}
          <div className="mt-20 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center text-foreground">
              よくある質問
            </h2>
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">プランの変更はいつでもできますか？</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    はい、いつでもプランの変更が可能です。アップグレードは即座に反映され、
                    ダウングレードは次回の請求サイクルから適用されます。
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">キャンセルポリシーについて教えてください</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    いつでもキャンセル可能です。キャンセル後も、現在の請求期間が終了するまで
                    サービスをご利用いただけます。
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">支払い方法は何がありますか？</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    クレジットカード（Visa、Mastercard、American Express、JCB）での
                    お支払いが可能です。安全な決済はStripeを通じて処理されます。
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">無料トライアルはありますか？</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    現在、無料トライアルは提供しておりませんが、スタータープランで
                    まずはお試しいただくことをお勧めします。
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* CTA Section */}
          {!isAuthenticated && (
            <div className="mt-16 text-center py-12 bg-gradient-to-br from-primary to-accent rounded-2xl text-primary-foreground">
              <h2 className="text-3xl font-bold mb-4">
                まだ迷っていますか？
              </h2>
              <p className="text-lg mb-6 opacity-90">
                まずは登録して、システム一覧をご覧ください
              </p>
              <a href={getLoginUrl()}>
                <Button size="lg" variant="secondary" className="text-lg px-8">
                  無料で始める
                </Button>
              </a>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
