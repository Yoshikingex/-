import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Systems from "./pages/Systems";
import Pricing from "./pages/Pricing";
import Dashboard from "./pages/Dashboard";
import Admin from "./pages/Admin";
import AdminSystems from "./pages/AdminSystems";
import AIConcierge from "./pages/AIConcierge";
import SystemDetail from "./pages/SystemDetail";
import SystemUse from "./pages/SystemUse";
import Ranking from "./pages/Ranking";
import CRM from "./pages/CRM";
import SalesEmail from "./pages/SalesEmail";
import QuotationInvoice from "./pages/QuotationInvoice";
import CompanyProfile from "./pages/CompanyProfile";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path="/systems" component={Systems} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/admin" component={Admin} />
      <Route path="/admin/systems" component={AdminSystems} />
      <Route path="/ai-concierge" component={AIConcierge} />
      <Route path="/system/:id" component={SystemDetail} />
      <Route path="/system/:id/use" component={SystemUse} />
      <Route path="/ranking" component={Ranking} />
      <Route path="/crm" component={CRM} />
      <Route path="/sales-email" component={SalesEmail} />
      <Route path="/quotation-invoice" component={QuotationInvoice} />
      <Route path="/company-profile" component={CompanyProfile} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
