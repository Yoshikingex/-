import { useState } from "react";
import { useParams, useLocation, Link } from "wouter";
import { getSystemRoute } from "@/../../shared/system-routes";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  Download, 
  Star, 
  Play,
  FileText,
  Loader2,
  User
} from "lucide-react";
import { Streamdown } from "streamdown";

export default function SystemDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const systemId = parseInt(id || "0");

  const { data: system, isLoading } = trpc.systemDetail.getDetail.useQuery({ systemId });
  const { data: reviews, refetch: refetchReviews } = trpc.systemDetail.getReviews.useQuery({ systemId });
  const { data: averageRating } = trpc.systemDetail.getAverageRating.useQuery({ systemId });
  const submitReviewMutation = trpc.systemDetail.submitReview.useMutation();

  const handleSubmitReview = async () => {
    if (!isAuthenticated) {
      toast.error("レビューを投稿するにはログインが必要です");
      return;
    }

    try {
      await submitReviewMutation.mutateAsync({
        systemId,
        rating,
        comment: comment.trim() || undefined,
      });
      toast.success("レビューを投稿しました");
      setComment("");
      refetchReviews();
    } catch (error: any) {
      toast.error(error.message || "レビューの投稿に失敗しました");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!system) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">システムが見つかりません</h1>
        <Button onClick={() => setLocation("/systems")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          システム一覧に戻る
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* ヘッダー */}
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" onClick={() => setLocation("/systems")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            システム一覧に戻る
          </Button>
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">SM</span>
              </div>
              <span className="font-bold text-xl">System Marketplace</span>
            </div>
          </Link>
          <div className="w-32" />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* システム概要 */}
        <div className="mb-8">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg">
              <FileText className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-bold">{system.name}</h1>
                <Badge variant="secondary">{system.category}</Badge>
              </div>

              <p className="text-lg">{system.description}</p>
              
              {/* 評価 */}
              {averageRating && (
                <div className="flex items-center gap-2 mt-4">
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${
                          star <= Math.round(averageRating.averageRating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {averageRating.averageRating.toFixed(1)} ({averageRating.totalReviews}件のレビュー)
                  </span>
                </div>
              )}

              {/* 利用するボタン */}
              <Button className="mt-4" size="lg" onClick={() => setLocation(getSystemRoute(systemId))}>
                <Play className="w-4 h-4 mr-2" />
                システムを利用する
              </Button>
            </div>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-8">
            {/* スクリーンショット */}
            {system.screenshots && system.screenshots.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>スクリーンショット</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    {system.screenshots.map((screenshot: string, index: number) => (
                      <img
                        key={index}
                        src={screenshot}
                        alt={`${system.name} スクリーンショット ${index + 1}`}
                        className="w-full rounded-lg border shadow-sm hover:shadow-md transition-shadow"
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* デモ動画 */}
            {system.demoVideoUrl && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Play className="w-5 h-5" />
                    デモ動画
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                      src={system.demoVideoUrl}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* チュートリアル */}
            {system.tutorial && (
              <Card>
                <CardHeader>
                  <CardTitle>利用チュートリアル</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-sm max-w-none">
                  <Streamdown>{system.tutorial}</Streamdown>
                </CardContent>
              </Card>
            )}

            {/* レビュー投稿 */}
            {isAuthenticated && (
              <Card>
                <CardHeader>
                  <CardTitle>レビューを投稿</CardTitle>
                  <CardDescription>このシステムの評価とコメントを投稿してください</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">評価</label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-8 h-8 cursor-pointer transition-colors ${
                            star <= rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300 hover:text-yellow-200"
                          }`}
                          onClick={() => setRating(star)}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">コメント（任意）</label>
                    <Textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="このシステムについての感想を教えてください"
                      rows={4}
                    />
                  </div>
                  <Button onClick={handleSubmitReview} disabled={submitReviewMutation.isPending}>
                    {submitReviewMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        投稿中...
                      </>
                    ) : (
                      "レビューを投稿"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* レビュー一覧 */}
            <Card>
              <CardHeader>
                <CardTitle>ユーザーレビュー</CardTitle>
                <CardDescription>{reviews?.length || 0}件のレビュー</CardDescription>
              </CardHeader>
              <CardContent>
                {reviews && reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviews.map((review) => (
                      <div key={review.id} className="border-b last:border-0 pb-6 last:pb-0">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                            <User className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">{review.userName || "匿名ユーザー"}</span>
                              <span className="text-sm text-muted-foreground">
                                {new Date(review.createdAt).toLocaleDateString("ja-JP")}
                              </span>
                            </div>
                            <div className="flex items-center mb-2">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`w-4 h-4 ${
                                    star <= review.rating
                                      ? "fill-yellow-400 text-yellow-400"
                                      : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                            {review.comment && (
                              <p className="text-sm text-muted-foreground">{review.comment}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    まだレビューがありません。最初のレビューを投稿しましょう！
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* サイドバー */}
          <div className="space-y-6">


            {/* システム情報 */}
            <Card>
              <CardHeader>
                <CardTitle>システム情報</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <span className="font-medium">カテゴリー:</span>
                  <span className="ml-2 text-muted-foreground">{system.category}</span>
                </div>

                <div>
                  <span className="font-medium">最終更新:</span>
                  <span className="ml-2 text-muted-foreground">
                    {new Date(system.updatedAt).toLocaleDateString("ja-JP")}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
