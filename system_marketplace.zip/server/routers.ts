import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { PLANS } from "../shared/systems";
import { TRPCError } from "@trpc/server";
import * as stripeService from "./stripe";
import { systemManagementRouter } from "./system-management";
import { aiConciergeRouter } from "./ai-concierge";
import { rankingRouter } from "./ranking";
import { pdfGeneratorRouter } from "./pdf-generator";
import { systemDetailRouter } from "./system-detail";
import { aiSystemsRouter } from "./ai-systems";
import { aiUsageRouter } from "./ai-usage";
import { crmRouter } from "./crm";
import { salesEmailRouter } from "./sales-email";
import { quotationInvoiceRouter } from "./routes/quotation-invoice";
import { companyProfileRouter } from "./routes/company-profile";
import { quotationInvoiceAIRouter } from "./routes/quotation-invoice-ai";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  systemManagement: systemManagementRouter,
  aiConcierge: aiConciergeRouter,
  ranking: rankingRouter,
  pdfGenerator: pdfGeneratorRouter,
  systemDetail: systemDetailRouter,
  aiSystems: aiSystemsRouter,
  aiUsage: aiUsageRouter,
  crm: crmRouter,
  salesEmail: salesEmailRouter,
  quotationInvoice: quotationInvoiceRouter,
  companyProfile: companyProfileRouter,
  quotationInvoiceAI: quotationInvoiceAIRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // システム管理
  systems: router({
    getAll: publicProcedure.query(async () => {
      return await db.getAllSystems();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const systems = await db.getAllSystems();
        const system = systems.find(s => s.id === input.id);
        if (!system) {
          throw new TRPCError({ code: "NOT_FOUND", message: "System not found" });
        }
        return system;
      }),

    getUserSystems: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserSystems(ctx.user.id);
    }),

    addSystem: protectedProcedure
      .input(z.object({ systemId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const user = await db.getUserById(ctx.user.id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }

        const userSystems = await db.getUserSystems(ctx.user.id);
        const plan = PLANS.find(p => p.id === user.currentPlan);
        
        if (!plan) {
          throw new TRPCError({ 
            code: "FORBIDDEN", 
            message: "プランに加入していません" 
          });
        }

        if (userSystems.length >= plan.systemLimit) {
          throw new TRPCError({ 
            code: "FORBIDDEN", 
            message: `現在のプラン（${plan.name}）では${plan.systemLimit}個までしか追加できません` 
          });
        }

        await db.addUserSystem({
          userId: ctx.user.id,
          systemId: input.systemId,
        });

        return { success: true };
      }),

    removeSystem: protectedProcedure
      .input(z.object({ systemId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.removeUserSystem(ctx.user.id, input.systemId);
        return { success: true };
      }),
  }),

  // プラン管理
  plans: router({
    getAll: publicProcedure.query(() => {
      return PLANS;
    }),

    getCurrent: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      if (!user || !user.currentPlan) {
        return null;
      }
      return PLANS.find(p => p.id === user.currentPlan) || null;
    }),
  }),

  // サブスクリプション管理
  subscription: router({
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return await db.getSubscriptionHistory(ctx.user.id);
    }),

    getStatus: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      if (!user) {
        throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
      }

      return {
        currentPlan: user.currentPlan,
        subscriptionStatus: user.subscriptionStatus,
        subscriptionStartDate: user.subscriptionStartDate,
        subscriptionEndDate: user.subscriptionEndDate,
        stripeSubscriptionId: user.stripeSubscriptionId,
      };
    }),
  }),

  // 管理者機能
  admin: router({
    getAllUsers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
      }
      return await db.getAllUsers();
    }),

    getAllSubscriptionHistory: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
      }
      return await db.getAllSubscriptionHistory();
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
      }

      const users = await db.getAllUsers();
      const history = await db.getAllSubscriptionHistory();

      const totalUsers = users.length;
      const activeSubscriptions = users.filter(u => u.subscriptionStatus === 'active').length;
      
      const planCounts = {
        starter: users.filter(u => u.currentPlan === 'starter').length,
        business: users.filter(u => u.currentPlan === 'business').length,
        enterprise: users.filter(u => u.currentPlan === 'enterprise').length,
      };

      const totalRevenue = history
        .filter(h => h.action === 'created' || h.action === 'renewed')
        .reduce((sum, h) => sum + (h.amount || 0), 0);

      return {
        totalUsers,
        activeSubscriptions,
        planCounts,
        totalRevenue,
      };
    }),
  }),

  // Stripe決済
  checkout: router({
    createSession: protectedProcedure
      .input(z.object({ planId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const origin = ctx.req.headers.origin || 'http://localhost:3000';
        
        const session = await stripeService.createCheckoutSession({
          planId: input.planId,
          userId: ctx.user.id,
          userEmail: ctx.user.email || '',
          userName: ctx.user.name || '',
          successUrl: `${origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${origin}/pricing`,
        });

        return session;
      }),

    createPortalSession: protectedProcedure.mutation(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      if (!user || !user.stripeCustomerId) {
        throw new TRPCError({ 
          code: "NOT_FOUND", 
          message: "Stripe customer not found" 
        });
      }

      const origin = ctx.req.headers.origin || 'http://localhost:3000';
      
      const session = await stripeService.createCustomerPortalSession({
        customerId: user.stripeCustomerId,
        returnUrl: `${origin}/dashboard`,
      });

      return session;
    }),
  }),
});

export type AppRouter = typeof appRouter;
