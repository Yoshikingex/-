import { Request, Response } from 'express';
import Stripe from 'stripe';
import * as db from './db';
import { getPlanTypeFromPriceId } from './products';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2025-12-15.clover',
});

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || '';

export async function handleStripeWebhook(req: Request, res: Response) {
  const sig = req.headers['stripe-signature'];

  if (!sig) {
    console.error('[Webhook] No signature found');
    return res.status(400).json({ error: 'No signature' });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      webhookSecret
    );
  } catch (err: any) {
    console.error('[Webhook] Signature verification failed:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  // Test eventの検出と処理
  if (event.id.startsWith('evt_test_')) {
    console.log('[Webhook] Test event detected, returning verification response');
    return res.json({ 
      verified: true,
    });
  }

  console.log('[Webhook] Event received:', event.type);

  try {
    // イベントタイプに応じた処理
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutSessionCompleted(session);
        break;
      }

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(subscription);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(subscription);
        break;
      }

      case 'invoice.paid': {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaid(invoice);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaymentFailed(invoice);
        break;
      }

      default:
        console.log('[Webhook] Unhandled event type:', event.type);
    }

    // 常に200とverified: trueを返す
    return res.json({ verified: true });
  } catch (error) {
    console.error('[Webhook] Error processing event:', error);
    // エラーが発生しても200を返す
    return res.json({ verified: true });
  }
}

async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session) {
  console.log('[Webhook] Checkout session completed:', session.id);

  const userId = session.metadata?.user_id;
  const customerEmail = session.customer_email || session.metadata?.customer_email;

  if (!userId) {
    console.error('[Webhook] No user_id in metadata');
    return;
  }

  const customerId = session.customer as string;
  const subscriptionId = session.subscription as string;

  // ユーザー情報を更新
  await db.updateUserSubscription(parseInt(userId), {
    stripeCustomerId: customerId,
    stripeSubscriptionId: subscriptionId,
  });

  console.log('[Webhook] User subscription initialized:', {
    userId,
    customerId,
    subscriptionId,
  });
}

async function handleSubscriptionUpdate(subscription: any) {
  console.log('[Webhook] Subscription updated:', subscription.id);

  const customerId = subscription.customer as string;

  // Customer IDからユーザーを検索
  const users = await db.getAllUsers();
  const user = users.find(u => u.stripeCustomerId === customerId);

  if (!user) {
    console.error('[Webhook] User not found for customer:', customerId);
    return;
  }

  // プランタイプを取得
  const priceId = subscription.items.data[0]?.price.id;
  const planType = priceId ? getPlanTypeFromPriceId(priceId) : null;

  if (!planType) {
    console.error('[Webhook] Unknown price ID:', priceId);
    return;
  }

  // サブスクリプション状態を更新
  const status = subscription.status as "active" | "canceled" | "past_due" | "incomplete" | "trialing";
  
  await db.updateUserSubscription(user.id, {
    currentPlan: planType,
    subscriptionStatus: status,
    stripeSubscriptionId: subscription.id,
    subscriptionStartDate: subscription.current_period_start ? new Date(subscription.current_period_start * 1000) : undefined,
    subscriptionEndDate: subscription.current_period_end ? new Date(subscription.current_period_end * 1000) : undefined,
  });

  // 履歴を記録
  await db.addSubscriptionHistory({
    userId: user.id,
    planType,
    action: subscription.status === 'active' ? 'created' : 'renewed',
    stripeSubscriptionId: subscription.id,
    amount: subscription.items.data[0]?.price.unit_amount || 0,
  });

  console.log('[Webhook] Subscription updated for user:', user.id);
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log('[Webhook] Subscription deleted:', subscription.id);

  const customerId = subscription.customer as string;

  const users = await db.getAllUsers();
  const user = users.find(u => u.stripeCustomerId === customerId);

  if (!user) {
    console.error('[Webhook] User not found for customer:', customerId);
    return;
  }

  // サブスクリプションをキャンセル状態に更新
  await db.updateUserSubscription(user.id, {
    subscriptionStatus: 'canceled',
    subscriptionEndDate: new Date(subscription.canceled_at! * 1000),
  });

  // 履歴を記録
  if (user.currentPlan) {
    await db.addSubscriptionHistory({
      userId: user.id,
      planType: user.currentPlan,
      action: 'canceled',
      stripeSubscriptionId: subscription.id,
    });
  }

  console.log('[Webhook] Subscription canceled for user:', user.id);
}

async function handleInvoicePaid(invoice: any) {
  console.log('[Webhook] Invoice paid:', invoice.id);

  const customerId = invoice.customer as string;
  const subscriptionId = (invoice.subscription as string) || '';

  const users = await db.getAllUsers();
  const user = users.find(u => u.stripeCustomerId === customerId);

  if (!user || !user.currentPlan) {
    return;
  }

  // 支払い履歴を記録
  await db.addSubscriptionHistory({
    userId: user.id,
    planType: user.currentPlan,
    action: 'renewed',
    stripeSubscriptionId: subscriptionId,
    stripeInvoiceId: invoice.id,
    amount: invoice.amount_paid,
  });

  console.log('[Webhook] Invoice payment recorded for user:', user.id);
}

async function handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
  console.log('[Webhook] Invoice payment failed:', invoice.id);

  const customerId = invoice.customer as string;

  const users = await db.getAllUsers();
  const user = users.find(u => u.stripeCustomerId === customerId);

  if (!user) {
    return;
  }

  // サブスクリプション状態を更新
  await db.updateUserSubscription(user.id, {
    subscriptionStatus: 'past_due',
  });

  console.log('[Webhook] Payment failed for user:', user.id);
}
