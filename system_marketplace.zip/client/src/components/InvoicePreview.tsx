import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Printer } from "lucide-react";

type InvoiceItem = {
  id: number;
  itemName: string;
  description: string | null;
  quantity: number;
  unitPrice: number;
};

type Invoice = {
  id: number;
  invoiceNumber: string;
  customerName: string;
  customerEmail: string | null;
  customerAddress: string | null;
  title: string;
  issueDate: Date;
  dueDate: Date;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  paymentMethod: string | null;
  bankInfo: string | null;
  notes: string | null;
  status: string;
  paidAt: Date | null;
};

type InvoicePreviewProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  invoice: Invoice;
  items: InvoiceItem[];
};

export function InvoicePreview({ open, onOpenChange, invoice, items }: InvoicePreviewProps) {
  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; color: string }> = {
      draft: { label: "下書き", color: "bg-gray-100 text-gray-800" },
      sent: { label: "送信済み", color: "bg-blue-100 text-blue-800" },
      paid: { label: "支払済み", color: "bg-green-100 text-green-800" },
      overdue: { label: "期限超過", color: "bg-red-100 text-red-800" },
      canceled: { label: "キャンセル", color: "bg-gray-100 text-gray-800" },
    };
    const statusInfo = statusMap[status] || { label: status, color: "bg-gray-100 text-gray-800" };
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${statusInfo.color}`}>
        {statusInfo.label}
      </span>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto print:max-w-full print:max-h-full">
        <DialogHeader className="print:hidden">
          <div className="flex justify-between items-center">
            <DialogTitle>請求書プレビュー</DialogTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-2" />
                印刷
              </Button>
              <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* PDF風のプレビュー */}
        <div className="bg-white p-12 shadow-lg print:shadow-none print:p-0" style={{ minHeight: "297mm" }}>
          {/* ヘッダー */}
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">請求書</h1>
              <p className="text-sm text-gray-600">Invoice</p>
            </div>
            <div className="print:hidden">
              {getStatusBadge(invoice.status)}
            </div>
          </div>

          {/* 請求書番号と日付 */}
          <div className="flex justify-between mb-8">
            <div>
              <p className="text-sm text-gray-600">請求書番号</p>
              <p className="text-lg font-semibold">{invoice.invoiceNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">発行日</p>
              <p className="text-lg">{new Date(invoice.issueDate).toLocaleDateString('ja-JP')}</p>
              <p className="text-sm text-gray-600 mt-2">支払期限</p>
              <p className="text-lg font-semibold text-red-600">
                {new Date(invoice.dueDate).toLocaleDateString('ja-JP')}
              </p>
            </div>
          </div>

          {/* 顧客情報 */}
          <div className="mb-8 p-4 bg-gray-50 rounded">
            <p className="text-sm text-gray-600 mb-1">請求先</p>
            <p className="text-xl font-semibold mb-2">{invoice.customerName} 御中</p>
            {invoice.customerAddress && (
              <p className="text-sm text-gray-700 mb-1">{invoice.customerAddress}</p>
            )}
            {invoice.customerEmail && (
              <p className="text-sm text-gray-700">{invoice.customerEmail}</p>
            )}
          </div>

          {/* 件名 */}
          <div className="mb-8">
            <p className="text-sm text-gray-600 mb-1">件名</p>
            <p className="text-lg font-semibold">{invoice.title}</p>
          </div>

          {/* 請求金額（目立つように） */}
          <div className="mb-8 p-6 bg-red-50 border-2 border-red-200 rounded">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">ご請求金額</span>
              <span className="text-3xl font-bold text-red-600">
                ¥{invoice.totalAmount.toLocaleString()}
              </span>
            </div>
            <p className="text-sm text-gray-600 text-right mt-1">（税込）</p>
          </div>

          {/* 明細テーブル */}
          <div className="mb-8">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100 border-b-2 border-gray-300">
                  <th className="text-left p-3 text-sm font-semibold">品目</th>
                  <th className="text-left p-3 text-sm font-semibold">説明</th>
                  <th className="text-right p-3 text-sm font-semibold">数量</th>
                  <th className="text-right p-3 text-sm font-semibold">単価</th>
                  <th className="text-right p-3 text-sm font-semibold">金額</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="p-3 border-b border-gray-200">{item.itemName}</td>
                    <td className="p-3 border-b border-gray-200 text-sm text-gray-600">
                      {item.description || "-"}
                    </td>
                    <td className="p-3 border-b border-gray-200 text-right">{item.quantity}</td>
                    <td className="p-3 border-b border-gray-200 text-right">
                      ¥{item.unitPrice.toLocaleString()}
                    </td>
                    <td className="p-3 border-b border-gray-200 text-right font-semibold">
                      ¥{(item.quantity * item.unitPrice).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 金額サマリー */}
          <div className="flex justify-end mb-8">
            <div className="w-80">
              <div className="flex justify-between py-2 border-b border-gray-200">
                <span className="text-gray-700">小計</span>
                <span className="font-semibold">¥{invoice.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-200">
                <span className="text-gray-700">消費税 ({invoice.taxRate}%)</span>
                <span className="font-semibold">¥{invoice.taxAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-3 border-t-2 border-gray-800">
                <span className="text-lg font-bold">合計</span>
                <span className="text-2xl font-bold text-red-600">
                  ¥{invoice.totalAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* 支払情報 */}
          {(invoice.paymentMethod || invoice.bankInfo) && (
            <div className="mb-8 p-4 bg-yellow-50 border border-yellow-200 rounded">
              <p className="text-sm font-semibold mb-3 text-gray-800">お支払い方法</p>
              {invoice.paymentMethod && (
                <p className="text-sm text-gray-700 mb-2">
                  <span className="font-semibold">支払方法:</span> {invoice.paymentMethod}
                </p>
              )}
              {invoice.bankInfo && (
                <p className="text-sm text-gray-700">
                  <span className="font-semibold">振込先:</span> {invoice.bankInfo}
                </p>
              )}
            </div>
          )}

          {/* 備考 */}
          {invoice.notes && (
            <div className="mb-8 p-4 bg-gray-50 rounded">
              <p className="text-sm text-gray-600 mb-2 font-semibold">備考</p>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">{invoice.notes}</p>
            </div>
          )}

          {/* 支払済み情報 */}
          {invoice.status === "paid" && invoice.paidAt && (
            <div className="mb-8 p-4 bg-green-50 border-2 border-green-200 rounded text-center">
              <p className="text-lg font-bold text-green-700">お支払い済み</p>
              <p className="text-sm text-gray-600 mt-1">
                支払日: {new Date(invoice.paidAt).toLocaleDateString('ja-JP')}
              </p>
            </div>
          )}

          {/* フッター */}
          <div className="mt-12 pt-8 border-t border-gray-300 text-center text-sm text-gray-600">
            <p>この請求書は{new Date(invoice.issueDate).toLocaleDateString('ja-JP')}に発行されました。</p>
            <p className="mt-1 font-semibold text-red-600">
              お支払期限: {new Date(invoice.dueDate).toLocaleDateString('ja-JP')}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
