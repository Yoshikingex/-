CREATE TABLE `user_ai_usage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`month` varchar(7) NOT NULL,
	`image_count` int NOT NULL DEFAULT 0,
	`video_count` int NOT NULL DEFAULT 0,
	`bgm_count` int NOT NULL DEFAULT 0,
	`prompt_count` int NOT NULL DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_ai_usage_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_ai_usage_user_id_month_unique` UNIQUE(`user_id`,`month`)
);
