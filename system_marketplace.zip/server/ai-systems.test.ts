import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/trpc";

describe("AI Systems Router", () => {
  let testUserId: number;
  let testContext: TrpcContext;

  beforeAll(async () => {
    // テストユーザーを作成
    const openId = `test-ai-${Date.now()}`;
    await db.upsertUser({
      openId,
      name: "AI Test User",
      email: `ai-test-${Date.now()}@example.com`,
      role: "user",
    });
    const testUser = await db.getUserByOpenId(openId);
    if (!testUser) {
      throw new Error("Failed to create test user");
    }
    testUserId = testUser.id;

    // テストコンテキストを作成
    testContext = {
      user: testUser,
      req: {} as any,
      res: {} as any,
    };
  });

  describe("generateImage", () => {
    it("should generate an image from a prompt", async () => {
      const caller = appRouter.createCaller(testContext);
      
      const result = await caller.aiSystems.generateImage({
        prompt: "A beautiful sunset over mountains",
      });

      expect(result).toBeDefined();
      expect(result.imageUrl).toBeDefined();
      expect(typeof result.imageUrl).toBe("string");
      expect(result.imageUrl).toMatch(/^https?:\/\//);
    }, 30000); // 画像生成は時間がかかるため30秒のタイムアウト
  });

  describe("generatePrompt", () => {
    it("should generate a prompt from a topic", async () => {
      const caller = appRouter.createCaller(testContext);
      
      const result = await caller.aiSystems.generatePrompt({
        topic: "マーケティング戦略",
      });

      expect(result).toBeDefined();
      expect(result.prompt).toBeDefined();
      expect(typeof result.prompt).toBe("string");
      expect(result.prompt.length).toBeGreaterThan(0);
    }, 30000); // LLM生成は時間がかかるため30秒のタイムアウト
  });

  describe("generateVideo", () => {
    it("should throw an error when Runway API key is not configured", async () => {
      const caller = appRouter.createCaller(testContext);
      
      await expect(
        caller.aiSystems.generateVideo({
          prompt: "A cat playing with a ball",
        })
      ).rejects.toThrow("動画生成機能は準備中です");
    });
  });

  describe("generateBGM", () => {
    it("should throw an error when Mubert API key is not configured", async () => {
      const caller = appRouter.createCaller(testContext);
      
      await expect(
        caller.aiSystems.generateBGM({
          prompt: "Relaxing ambient music",
          duration: 60,
        })
      ).rejects.toThrow("BGM生成機能は準備中です");
    });
  });
});
