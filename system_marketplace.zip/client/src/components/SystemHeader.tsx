import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Home, ArrowLeft, Sparkles } from "lucide-react";

export function SystemHeader() {
  const { user, isAuthenticated } = useAuth();

  return (
    <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon" title="ホームに戻る">
              <Home className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/systems">
            <Button variant="ghost" size="icon" title="システム一覧に戻る">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </Link>
        </div>
        <nav className="flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <Link href="/dashboard">
                <Button variant="ghost">ダッシュボード</Button>
              </Link>
              {user?.role === 'admin' && (
                <Link href="/admin">
                  <Button variant="outline">管理画面</Button>
                </Link>
              )}
            </>
          ) : (
            <a href={getLoginUrl()}>
              <Button variant="default">ログイン / 新規登録</Button>
            </a>
          )}
        </nav>
      </div>
    </header>
  );
}
