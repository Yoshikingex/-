import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { 
  Sparkles, 
  ArrowLeft,
  Package,
  CreditCard,
  History,
  Settings,
  Loader2,
  ExternalLink,
  Plus,
  X,
} from "lucide-react";
import { useEffect } from "react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  // クエリパラメータからsession_idを取得
  const searchParams = new URLSearchParams(window.location.search);
  const sessionId = searchParams.get('session_id');

  // 決済成功時の処理
  useEffect(() => {
    if (sessionId) {
      toast.success('決済が完了しました！プランが有効化されるまでお待ちください。');
      // URLからsession_idを削除
      window.history.replaceState({}, '', '/dashboard');
      // データを再取得
      utils.subscription.getStatus.invalidate();
      utils.plans.getCurrent.invalidate();
      utils.systems.getUserSystems.invalidate();
    }
  }, [sessionId, utils]);

  const { data: currentPlan, isLoading: planLoading } = trpc.plans.getCurrent.useQuery();
  const { data: subscriptionStatus, isLoading: statusLoading } = trpc.subscription.getStatus.useQuery();
  const { data: userSystems, isLoading: systemsLoading } = trpc.systems.getUserSystems.useQuery();
  const { data: allSystems } = trpc.systems.getAll.useQuery();
  const { data: history, isLoading: historyLoading } = trpc.subscription.getHistory.useQuery();
  const { data: aiUsage } = trpc.aiUsage.getCurrentUsage.useQuery();
  const { data: planLimits } = trpc.aiUsage.getPlanLimits.useQuery();

  const addSystemMutation = trpc.systems.addSystem.useMutation({
    onSuccess: () => {
      toast.success('システムを追加しました');
      utils.systems.getUserSystems.invalidate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const removeSystemMutation = trpc.systems.removeSystem.useMutation({
    onSuccess: () => {
      toast.success('システムを削除しました');
      utils.systems.getUserSystems.invalidate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const createPortalSession = trpc.checkout.createPortalSession.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        toast.success('Stripeポータルに移動します...');
        window.open(data.url, '_blank');
      }
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const handleLogout = async () => {
    await logout();
    setLocation('/');
  };

  const userSystemIds = new Set(userSystems?.map(us => us.systemId) || []);
  const availableSystems = allSystems?.filter(s => !userSystemIds.has(s.id)) || [];

  const isLoading = planLoading || statusLoading || systemsLoading;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/systems">
              <Button variant="ghost">システム一覧</Button>
            </Link>
            {user?.role === 'admin' && (
              <Link href="/admin">
                <Button variant="outline">管理画面</Button>
              </Link>
            )}
            <Button variant="ghost" onClick={handleLogout}>
              ログアウト
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              ダッシュボード
            </h1>
            <p className="text-xl text-muted-foreground">
              ようこそ、{user?.name || 'ゲスト'}さん
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-2 space-y-8">
                {/* Current Plan */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Package className="w-6 h-6 text-primary" />
                        <CardTitle>現在のプラン</CardTitle>
                      </div>
                      {currentPlan && (
                        <Badge className="bg-primary text-primary-foreground">
                          {currentPlan.name}
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {currentPlan ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">月額料金</span>
                          <span className="text-2xl font-bold text-foreground">
                            ¥{currentPlan.price.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">利用可能システム数</span>
                          <span className="text-lg font-semibold text-foreground">
                            {userSystemIds.size} / {currentPlan.systemLimit}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">ステータス</span>
                          <Badge variant={subscriptionStatus?.subscriptionStatus === 'active' ? 'default' : 'secondary'}>
                            {subscriptionStatus?.subscriptionStatus === 'active' ? 'アクティブ' : subscriptionStatus?.subscriptionStatus || '未登録'}
                          </Badge>
                        </div>
                        <div className="pt-4 flex gap-3">
                          <Link href="/pricing" className="flex-1">
                            <Button variant="outline" className="w-full">
                              プランを変更
                            </Button>
                          </Link>
                          <Button 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => createPortalSession.mutate()}
                            disabled={createPortalSession.isPending || !subscriptionStatus?.stripeSubscriptionId}
                          >
                            {createPortalSession.isPending ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                処理中...
                              </>
                            ) : (
                              <>
                                <Settings className="w-4 h-4 mr-2" />
                                請求管理
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">まだプランに加入していません</p>
                        <Link href="/pricing">
                          <Button>プランを選択</Button>
                        </Link>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* User Systems */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Package className="w-6 h-6 text-primary" />
                        <CardTitle>利用中のシステム</CardTitle>
                      </div>
                      {currentPlan && userSystemIds.size < currentPlan.systemLimit && (
                        <Badge variant="secondary">
                          あと{currentPlan.systemLimit - userSystemIds.size}個追加可能
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {userSystems && userSystems.length > 0 ? (
                      <div className="grid md:grid-cols-2 gap-4">
                        {userSystems.map(userSystem => (
                          <Card key={userSystem.id} className="border-2">
                            <CardHeader className="pb-3">
                              <div className="flex items-start justify-between">
                                <CardTitle className="text-base">{userSystem.system?.name || 'システム'}</CardTitle>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => removeSystemMutation.mutate({ systemId: userSystem.systemId })}
                                  disabled={removeSystemMutation.isPending}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            </CardHeader>
                            <CardContent className="pb-3">
                              <CardDescription className="text-sm line-clamp-2">
                                {userSystem.system?.description || ''}
                              </CardDescription>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">まだシステムを追加していません</p>
                        <Link href="/systems">
                          <Button variant="outline">システムを見る</Button>
                        </Link>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Available Systems */}
                {currentPlan && userSystemIds.size < currentPlan.systemLimit && availableSystems.length > 0 && (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <Plus className="w-6 h-6 text-accent" />
                        <CardTitle>追加可能なシステム</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4">
                        {availableSystems.slice(0, 6).map(system => (
                          <Card key={system.id} className="border-2 hover:border-primary transition-colors">
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base">{system.name}</CardTitle>
                            </CardHeader>
                            <CardContent className="pb-3 space-y-3">
                              <CardDescription className="text-sm line-clamp-2">
                                {system.description}
                              </CardDescription>
                              <Button
                                size="sm"
                                className="w-full"
                                onClick={() => addSystemMutation.mutate({ systemId: system.id })}
                                disabled={addSystemMutation.isPending}
                              >
                                {addSystemMutation.isPending ? (
                                  <>
                                    <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                                    追加中...
                                  </>
                                ) : (
                                  <>
                                    <Plus className="w-3 h-3 mr-2" />
                                    追加
                                  </>
                                )}
                              </Button>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                      <div className="mt-4 text-center">
                        <Link href="/systems">
                          <Button variant="outline">すべてのシステムを見る</Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Right Column - Sidebar */}
              <div className="space-y-8">
                {/* AI使用状況 */}
                {aiUsage && planLimits && (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <Sparkles className="w-6 h-6 text-primary" />
                        <CardTitle>AI使用状況（今月）</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">画像生成</span>
                          <span className="text-sm font-semibold text-foreground">
                            {aiUsage.imageCount} / {planLimits.image}回
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${Math.min((aiUsage.imageCount / planLimits.image) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">動画生成</span>
                          <span className="text-sm font-semibold text-foreground">
                            {aiUsage.videoCount} / {planLimits.video}回
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${planLimits.video > 0 ? Math.min((aiUsage.videoCount / planLimits.video) * 100, 100) : 0}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">BGM生成</span>
                          <span className="text-sm font-semibold text-foreground">
                            {aiUsage.bgmCount} / {planLimits.bgm}回
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${planLimits.bgm > 0 ? Math.min((aiUsage.bgmCount / planLimits.bgm) * 100, 100) : 0}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">プロンプト生成</span>
                          <span className="text-sm font-semibold text-foreground">
                            {aiUsage.promptCount} / {planLimits.prompt}回
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${Math.min((aiUsage.promptCount / planLimits.prompt) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Payment History */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <History className="w-6 h-6 text-primary" />
                      <CardTitle>支払い履歴</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {historyLoading ? (
                      <div className="flex justify-center py-4">
                        <Loader2 className="w-6 h-6 animate-spin text-primary" />
                      </div>
                    ) : history && history.length > 0 ? (
                      <div className="space-y-3">
                        {history.slice(0, 5).map(item => (
                          <div key={item.id} className="flex justify-between items-center py-2 border-b last:border-0">
                            <div>
                              <p className="text-sm font-medium text-foreground">
                                {item.action === 'created' ? '新規登録' : 
                                 item.action === 'renewed' ? '更新' : 
                                 item.action === 'upgraded' ? 'アップグレード' :
                                 item.action === 'downgraded' ? 'ダウングレード' : 'キャンセル'}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(item.createdAt).toLocaleDateString('ja-JP')}
                              </p>
                            </div>
                            {item.amount && (
                              <span className="text-sm font-semibold text-foreground">
                                ¥{(item.amount / 100).toLocaleString()}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        履歴がありません
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>クイックアクション</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Link href="/systems">
                      <Button variant="outline" className="w-full justify-start">
                        <Package className="w-4 h-4 mr-2" />
                        システム一覧
                      </Button>
                    </Link>
                    <Link href="/pricing">
                      <Button variant="outline" className="w-full justify-start">
                        <CreditCard className="w-4 h-4 mr-2" />
                        料金プラン
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
