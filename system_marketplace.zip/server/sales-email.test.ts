import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { users } from "../drizzle/schema";

describe("営業メール自動生成機能", () => {
  let testUserId: number;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) {
      throw new Error("データベースに接続できません");
    }

    // テストユーザーを作成
    const result = await db.insert(users).values({
      openId: `test-sales-email-${Date.now()}`,
      name: "営業メールテストユーザー",
      email: "sales-email-test@example.com",
      role: "user",
    }).$returningId();

    testUserId = result[0].id;

    // tRPC callerを作成
    caller = appRouter.createCaller({
      user: {
        id: testUserId,
        openId: `test-sales-email-${Date.now()}`,
        name: "営業メールテストユーザー",
        email: "sales-email-test@example.com",
        role: "user",
      },
      req: {} as any,
      res: {} as any,
    });
  });

  it("メールテンプレートを作成できる", async () => {
    const result = await caller.salesEmail.createTemplate({
      name: "初回営業テンプレート",
      category: "初回営業",
      subject: "【{{companyName}}様】業務効率化のご提案",
      body: "{{contactName}}様\n\nお世話になっております。",
      isDefault: true,
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeGreaterThan(0);
  });

  it("メールテンプレート一覧を取得できる", async () => {
    const templates = await caller.salesEmail.getTemplates({});

    expect(Array.isArray(templates)).toBe(true);
    expect(templates.length).toBeGreaterThan(0);
  });

  it("AIで営業メールを生成できる", async () => {
    const result = await caller.salesEmail.generateEmail({
      category: "初回営業",
      companyName: "株式会社テスト",
      contactName: "山田太郎",
      productService: "業務効率化システム",
      additionalInfo: "中小企業向けのソリューション",
    });

    expect(result.success).toBe(true);
    expect(result.subject).toBeTruthy();
    expect(result.body).toBeTruthy();
    expect(result.subject.length).toBeGreaterThan(0);
    expect(result.body.length).toBeGreaterThan(0);
  }, 30000); // AI生成は時間がかかるので30秒のタイムアウト

  it("メールを下書き保存できる", async () => {
    const result = await caller.salesEmail.saveEmail({
      subject: "テストメール",
      body: "これはテストメールです。",
      recipient: "test@example.com",
      status: "draft",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeGreaterThan(0);
  });

  it("メール送信履歴を取得できる", async () => {
    const history = await caller.salesEmail.getHistory({});

    expect(Array.isArray(history)).toBe(true);
    expect(history.length).toBeGreaterThan(0);
  });

  it("送信済みメールのみを取得できる", async () => {
    // 送信済みメールを保存
    await caller.salesEmail.saveEmail({
      subject: "送信済みテストメール",
      body: "これは送信済みメールです。",
      recipient: "sent@example.com",
      status: "sent",
    });

    const history = await caller.salesEmail.getHistory({
      status: "sent",
    });

    expect(Array.isArray(history)).toBe(true);
    expect(history.every((item) => item.status === "sent")).toBe(true);
  });
});
