import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Download, Loader2 } from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "wouter";
import { toast } from "sonner";

export default function SystemUse() {
  const { id } = useParams();
  const { user, loading: authLoading } = useAuth();
  const [prompt, setPrompt] = useState("");
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const { data: system, isLoading: systemLoading } = trpc.systems.getById.useQuery(
    { id: parseInt(id!) },
    { enabled: !!id }
  );

  const { data: userSystems } = trpc.systems.getUserSystems.useQuery(undefined, {
    enabled: !!user,
  });

  const generateImageMutation = trpc.aiSystems.generateImage.useMutation();
  const generatePromptMutation = trpc.aiSystems.generatePrompt.useMutation();

  if (authLoading || systemLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>ログインが必要です</CardTitle>
            <CardDescription>
              このシステムを利用するには、ログインしてください。
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <a href={`${import.meta.env.VITE_OAUTH_PORTAL_URL}?app_id=${import.meta.env.VITE_APP_ID}`}>
                ログイン
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!system) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>システムが見つかりません</CardTitle>
            <CardDescription>
              指定されたシステムは存在しません。
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/systems">
              <Button variant="outline" className="w-full">
                <ArrowLeft className="w-4 h-4 mr-2" />
                システム一覧に戻る
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isSelected = userSystems?.some((us) => us.systemId === system.id);

  if (!isSelected) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>アクセス権限がありません</CardTitle>
            <CardDescription>
              このシステムを利用するには、プランに追加する必要があります。
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href="/dashboard">
              <Button className="w-full">
                マイページでシステムを追加
              </Button>
            </Link>
            <Link href="/systems">
              <Button variant="outline" className="w-full">
                <ArrowLeft className="w-4 h-4 mr-2" />
                システム一覧に戻る
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error("プロンプトを入力してください");
      return;
    }

    setGenerating(true);
    setResult(null);

    try {
      if (system.name === "画像生成AI") {
        const response = await generateImageMutation.mutateAsync({ prompt });
        setResult(response.imageUrl || "");
        toast.success("画像を生成しました");
      } else if (system.name === "プロンプト生成AI") {
        const response = await generatePromptMutation.mutateAsync({ topic: prompt });
        setResult(response.prompt || "");
        toast.success("プロンプトを生成しました");
      } else {
        toast.error("このシステムはまだ実装されていません");
      }
    } catch (error: any) {
      toast.error(error.message || "生成に失敗しました");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto py-8">
        <Link href="/systems">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            システム一覧に戻る
          </Button>
        </Link>

        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-3xl">{system.name}</CardTitle>
            <CardDescription className="text-lg">{system.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="prompt" className="text-lg">
                  {system.name === "画像生成AI" && "画像の説明を入力"}
                  {system.name === "プロンプト生成AI" && "トピックを入力"}
                  {!["画像生成AI", "プロンプト生成AI"].includes(system.name) && "入力"}
                </Label>
                <Textarea
                  id="prompt"
                  placeholder={
                    system.name === "画像生成AI"
                      ? "例：夕暮れの富士山と桜の風景"
                      : system.name === "プロンプト生成AI"
                      ? "例：マーケティング戦略"
                      : "入力してください"
                  }
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="mt-2"
                />
              </div>

              <Button
                onClick={handleGenerate}
                disabled={generating || !prompt.trim()}
                className="w-full"
                size="lg"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    生成中...
                  </>
                ) : (
                  "生成する"
                )}
              </Button>
            </div>

            {result && (
              <div className="space-y-4 pt-6 border-t">
                <h3 className="text-xl font-semibold">生成結果</h3>
                {system.name === "画像生成AI" ? (
                  <div className="space-y-4">
                    <img
                      src={result}
                      alt="Generated"
                      className="w-full rounded-lg shadow-lg"
                    />
                    <a href={result} download target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" className="w-full">
                        <Download className="w-4 h-4 mr-2" />
                        画像をダウンロード
                      </Button>
                    </a>
                  </div>
                ) : (
                  <div className="bg-muted p-6 rounded-lg">
                    <p className="whitespace-pre-wrap">{result}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
