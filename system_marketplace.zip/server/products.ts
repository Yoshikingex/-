/**
 * Stripe Product and Price Configuration
 * 
 * This file centralizes Stripe product and price IDs for subscription plans.
 * These are actual Stripe test mode IDs created via the setup script.
 * For production, create new products in live mode and update these IDs.
 */

export interface StripeProduct {
  productId: string;
  priceId: string;
  name: string;
  amount: number; // in cents (JPY)
  currency: string;
  interval: 'month' | 'year';
}

/**
 * Subscription Plans
 * Note: These are placeholder IDs. In production:
 * 1. Create products in Stripe Dashboard
 * 2. Create recurring prices for each product
 * 3. Replace these IDs with actual Stripe IDs
 */
export const STRIPE_PRODUCTS: Record<string, StripeProduct> = {
  starter: {
    productId: 'prod_TozBa4URTi2NyK',
    priceId: 'price_1SrLCtBjH4e1QWpBFaQz1i5j',
    name: 'スタータープラン',
    amount: 2980000, // ¥29,800 in cents
    currency: 'jpy',
    interval: 'month',
  },
  business: {
    productId: 'prod_TozBFrNMoekdNV',
    priceId: 'price_1SrLCvBjH4e1QWpBGQzGffcL',
    name: 'ビジネスプラン',
    amount: 5980000, // ¥59,800 in cents
    currency: 'jpy',
    interval: 'month',
  },
  enterprise: {
    productId: 'prod_TozBuLQxzTTA5T',
    priceId: 'price_1SrLCxBjH4e1QWpBAUl6XU8R',
    name: 'エンタープライズプラン',
    amount: 9980000, // ¥99,800 in cents
    currency: 'jpy',
    interval: 'month',
  },
};

/**
 * Get Stripe Price ID by plan type
 */
export function getStripePriceId(planType: 'starter' | 'business' | 'enterprise'): string {
  return STRIPE_PRODUCTS[planType]?.priceId || '';
}

/**
 * Get plan type from Stripe Price ID
 */
export function getPlanTypeFromPriceId(priceId: string): 'starter' | 'business' | 'enterprise' | null {
  for (const [planType, product] of Object.entries(STRIPE_PRODUCTS)) {
    if (product.priceId === priceId) {
      return planType as 'starter' | 'business' | 'enterprise';
    }
  }
  return null;
}
