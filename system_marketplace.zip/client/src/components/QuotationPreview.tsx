import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Printer } from "lucide-react";

type QuotationItem = {
  id: number;
  itemName: string;
  description: string | null;
  quantity: number;
  unitPrice: number;
};

type Quotation = {
  id: number;
  quotationNumber: string;
  customerName: string;
  customerEmail: string | null;
  customerAddress: string | null;
  title: string;
  issueDate: Date;
  expiryDate: Date | null;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  notes: string | null;
  status: string;
};

type QuotationPreviewProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  quotation: Quotation;
  items: QuotationItem[];
};

export function QuotationPreview({ open, onOpenChange, quotation, items }: QuotationPreviewProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto print:max-w-full print:max-h-full">
        <DialogHeader className="print:hidden">
          <div className="flex justify-between items-center">
            <DialogTitle>見積書プレビュー</DialogTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-2" />
                印刷
              </Button>
              <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* PDF風のプレビュー */}
        <div className="bg-white p-12 shadow-lg print:shadow-none print:p-0" style={{ minHeight: "297mm" }}>
          {/* ヘッダー */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">見積書</h1>
            <p className="text-sm text-gray-600">Quotation</p>
          </div>

          {/* 見積書番号と日付 */}
          <div className="flex justify-between mb-8">
            <div>
              <p className="text-sm text-gray-600">見積書番号</p>
              <p className="text-lg font-semibold">{quotation.quotationNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">発行日</p>
              <p className="text-lg">{new Date(quotation.issueDate).toLocaleDateString('ja-JP')}</p>
              {quotation.expiryDate && (
                <>
                  <p className="text-sm text-gray-600 mt-2">有効期限</p>
                  <p className="text-lg">{new Date(quotation.expiryDate).toLocaleDateString('ja-JP')}</p>
                </>
              )}
            </div>
          </div>

          {/* 顧客情報 */}
          <div className="mb-8 p-4 bg-gray-50 rounded">
            <p className="text-sm text-gray-600 mb-1">お客様</p>
            <p className="text-xl font-semibold mb-2">{quotation.customerName} 御中</p>
            {quotation.customerAddress && (
              <p className="text-sm text-gray-700 mb-1">{quotation.customerAddress}</p>
            )}
            {quotation.customerEmail && (
              <p className="text-sm text-gray-700">{quotation.customerEmail}</p>
            )}
          </div>

          {/* 件名 */}
          <div className="mb-8">
            <p className="text-sm text-gray-600 mb-1">件名</p>
            <p className="text-lg font-semibold">{quotation.title}</p>
          </div>

          {/* 合計金額（目立つように） */}
          <div className="mb-8 p-6 bg-blue-50 border-2 border-blue-200 rounded">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">お見積金額</span>
              <span className="text-3xl font-bold text-blue-600">
                ¥{quotation.totalAmount.toLocaleString()}
              </span>
            </div>
            <p className="text-sm text-gray-600 text-right mt-1">（税込）</p>
          </div>

          {/* 明細テーブル */}
          <div className="mb-8">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100 border-b-2 border-gray-300">
                  <th className="text-left p-3 text-sm font-semibold">品目</th>
                  <th className="text-left p-3 text-sm font-semibold">説明</th>
                  <th className="text-right p-3 text-sm font-semibold">数量</th>
                  <th className="text-right p-3 text-sm font-semibold">単価</th>
                  <th className="text-right p-3 text-sm font-semibold">金額</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="p-3 border-b border-gray-200">{item.itemName}</td>
                    <td className="p-3 border-b border-gray-200 text-sm text-gray-600">
                      {item.description || "-"}
                    </td>
                    <td className="p-3 border-b border-gray-200 text-right">{item.quantity}</td>
                    <td className="p-3 border-b border-gray-200 text-right">
                      ¥{item.unitPrice.toLocaleString()}
                    </td>
                    <td className="p-3 border-b border-gray-200 text-right font-semibold">
                      ¥{(item.quantity * item.unitPrice).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 金額サマリー */}
          <div className="flex justify-end mb-8">
            <div className="w-80">
              <div className="flex justify-between py-2 border-b border-gray-200">
                <span className="text-gray-700">小計</span>
                <span className="font-semibold">¥{quotation.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-200">
                <span className="text-gray-700">消費税 ({quotation.taxRate}%)</span>
                <span className="font-semibold">¥{quotation.taxAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-3 border-t-2 border-gray-800">
                <span className="text-lg font-bold">合計</span>
                <span className="text-2xl font-bold text-blue-600">
                  ¥{quotation.totalAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* 備考 */}
          {quotation.notes && (
            <div className="mb-8 p-4 bg-gray-50 rounded">
              <p className="text-sm text-gray-600 mb-2 font-semibold">備考</p>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">{quotation.notes}</p>
            </div>
          )}

          {/* フッター */}
          <div className="mt-12 pt-8 border-t border-gray-300 text-center text-sm text-gray-600">
            <p>この見積書は{new Date(quotation.issueDate).toLocaleDateString('ja-JP')}に発行されました。</p>
            {quotation.expiryDate && (
              <p className="mt-1">
                有効期限: {new Date(quotation.expiryDate).toLocaleDateString('ja-JP')}
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
