CREATE TABLE `subscription_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`plan_type` enum('starter','business','enterprise') NOT NULL,
	`action` enum('created','upgraded','downgraded','canceled','renewed') NOT NULL,
	`stripe_subscription_id` varchar(255),
	`stripe_invoice_id` varchar(255),
	`amount` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subscription_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `systems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`system_id` varchar(100) NOT NULL,
	`name` varchar(255) NOT NULL,
	`name_en` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`category` enum('ai','management','automation','marketing') NOT NULL,
	`icon` varchar(50) NOT NULL,
	`color` varchar(100) NOT NULL,
	`is_active` boolean NOT NULL DEFAULT true,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `systems_id` PRIMARY KEY(`id`),
	CONSTRAINT `systems_system_id_unique` UNIQUE(`system_id`)
);
--> statement-breakpoint
CREATE TABLE `user_systems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`system_id` int NOT NULL,
	`added_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_systems_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_systems_user_id_system_id_unique` UNIQUE(`user_id`,`system_id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `stripe_customer_id` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `current_plan` enum('starter','business','enterprise');--> statement-breakpoint
ALTER TABLE `users` ADD `stripe_subscription_id` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `subscription_status` enum('active','canceled','past_due','incomplete','trialing');--> statement-breakpoint
ALTER TABLE `users` ADD `subscription_start_date` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `subscription_end_date` timestamp;