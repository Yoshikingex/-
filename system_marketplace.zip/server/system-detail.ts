import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq, and, desc, sql } from "drizzle-orm";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { systems, systemReviews, users } from "../drizzle/schema";

export const systemDetailRouter = router({
  /**
   * システム詳細情報を取得
   */
  getDetail: publicProcedure
    .input(z.object({ systemId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const system = await db.select().from(systems).where(eq(systems.id, input.systemId)).limit(1);
      if (!system || system.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "System not found" });
      }

      const systemData = system[0];

      // Parse JSON fields
      const screenshots = systemData.screenshots ? JSON.parse(systemData.screenshots as string) : [];

      return {
        ...systemData,
        screenshots,
      };
    }),

  /**
   * システムのレビュー一覧を取得
   */
  getReviews: publicProcedure
    .input(z.object({ systemId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const reviews = await db
        .select({
          id: systemReviews.id,
          rating: systemReviews.rating,
          comment: systemReviews.comment,
          createdAt: systemReviews.createdAt,
          updatedAt: systemReviews.updatedAt,
          userName: users.name,
          userEmail: users.email,
        })
        .from(systemReviews)
        .leftJoin(users, eq(systemReviews.userId, users.id))
        .where(eq(systemReviews.systemId, input.systemId))
        .orderBy(desc(systemReviews.createdAt));

      return reviews;
    }),

  /**
   * レビューを投稿
   */
  submitReview: protectedProcedure
    .input(
      z.object({
        systemId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      // Check if system exists
      const system = await db.select().from(systems).where(eq(systems.id, input.systemId)).limit(1);
      if (!system || system.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "System not found" });
      }

      // Check if user already reviewed this system
      const existingReview = await db
        .select()
        .from(systemReviews)
        .where(and(eq(systemReviews.userId, ctx.user.id), eq(systemReviews.systemId, input.systemId)))
        .limit(1);

      if (existingReview && existingReview.length > 0) {
        // Update existing review
        await db
          .update(systemReviews)
          .set({
            rating: input.rating,
            comment: input.comment || null,
            updatedAt: new Date(),
          })
          .where(eq(systemReviews.id, existingReview[0]!.id));

        return { success: true, message: "レビューを更新しました" };
      } else {
        // Insert new review
        await db.insert(systemReviews).values({
          userId: ctx.user.id,
          systemId: input.systemId,
          rating: input.rating,
          comment: input.comment || null,
        });

        return { success: true, message: "レビューを投稿しました" };
      }
    }),

  /**
   * レビューの平均評価を取得
   */
  getAverageRating: publicProcedure
    .input(z.object({ systemId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const result = await db
        .select({
          averageRating: sql<number>`AVG(${systemReviews.rating})`,
          totalReviews: sql<number>`COUNT(*)`,
        })
        .from(systemReviews)
        .where(eq(systemReviews.systemId, input.systemId));

      return {
        averageRating: result[0]?.averageRating || 0,
        totalReviews: result[0]?.totalReviews || 0,
      };
    }),
});
