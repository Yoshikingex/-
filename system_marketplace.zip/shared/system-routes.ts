/**
 * システムIDと対応するURLのマッピング
 */
export const SYSTEM_ROUTES: Record<number, string> = {
  1: "/crm", // 顧客管理CRM
  2: "/sales-email", // 営業メール自動生成
  3: "/quotation-invoice", // 見積書・請求書作成
  4: "/business-card", // 名刺管理システム
  5: "/meeting-minutes", // 商談議事録AI
  6: "/sns-post", // SNS投稿文自動生成
  7: "/system/7/use", // 画像生成AI
  8: "/seo-article", // SEO記事作成AI
  9: "/catchcopy", // キャッチコピー生成AI
  10: "/attendance", // 勤怠管理システム
  11: "/expense", // 経費精算システム
  12: "/inventory", // 在庫管理システム
  13: "/task-management", // タスク管理・プロジェクト管理
  14: "/contract", // 契約書管理システム
  15: "/daily-report", // 日報・週報自動生成
  16: "/chatbot", // AIチャットボット
  17: "/email-classifier", // メール自動分類・要約AI
  18: "/data-entry", // データ入力自動化
  19: "/translation", // 翻訳AI
  20: "/system/20/use", // プロンプト生成AI
};

/**
 * システムIDからURLを取得
 */
export function getSystemRoute(systemId: number): string {
  return SYSTEM_ROUTES[systemId] || `/system/${systemId}/use`;
}
