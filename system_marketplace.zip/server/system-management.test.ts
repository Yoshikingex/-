import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

function createUserContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("systemManagement", () => {
  it("管理者はシステム一覧を取得できる", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const systems = await caller.systemManagement.listAll();

    expect(systems).toBeDefined();
    expect(Array.isArray(systems)).toBe(true);
  });

  it("一般ユーザーはシステム一覧を取得できない", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.systemManagement.listAll()).rejects.toThrow("管理者権限が必要です");
  });

  it("管理者はシステムを作成できる", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.systemManagement.create({
      systemId: "test-system",
      name: "テストシステム",
      nameEn: "Test System",
      description: "これはテスト用のシステムです",
      category: "ai",
      icon: "Sparkles",
      color: "from-blue-500 to-cyan-500",
    });

    expect(result.success).toBe(true);
  });

  it("一般ユーザーはシステムを作成できない", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.systemManagement.create({
        systemId: "test-system-2",
        name: "テストシステム2",
        nameEn: "Test System 2",
        description: "これはテスト用のシステムです",
        category: "management",
        icon: "Users",
        color: "from-purple-500 to-pink-500",
      })
    ).rejects.toThrow("管理者権限が必要です");
  });
});
