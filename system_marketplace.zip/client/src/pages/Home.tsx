import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { 
  Sparkles, 
  Zap, 
  Shield, 
  TrendingUp, 
  Users, 
  ArrowRight,
  Bot,
} from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">System Marketplace</span>
          </div>
          <nav className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/systems">
                  <Button variant="ghost">システム一覧</Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="default">ダッシュボード</Button>
                </Link>
              </>
            ) : (
              <>
                <Link href="/pricing">
                  <Button variant="ghost">料金プラン</Button>
                </Link>
                <a href={getLoginUrl()}>
                  <Button variant="default">ログイン / 新規登録</Button>
                </a>
              </>
            )}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-background to-secondary/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-accent text-accent-foreground">
              20種類以上の業務効率化システム
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              ビジネスを加速する
              <br />
              オールインワンプラットフォーム
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              AI技術と業務管理システムを統合。月額定額で必要なシステムを自由に選択し、
              ビジネスの成長を支援します。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <>
                  <Link href="/ai-concierge">
                    <Button size="lg" className="text-lg px-8">
                      <Bot className="mr-2 w-5 h-5" />
                      AIコンシェルジュ
                    </Button>
                  </Link>
                  <Link href="/systems">
                    <Button size="lg" variant="outline" className="text-lg px-8">
                      システムを見る
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <a href={getLoginUrl()}>
                    <Button size="lg" className="text-lg px-8">
                      無料で始める
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </a>
                  <Link href="/pricing">
                    <Button size="lg" variant="outline" className="text-lg px-8">
                      料金プランを見る
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              なぜSystem Marketplaceなのか
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              従来の個別システム導入と比較して、圧倒的なコストパフォーマンスと利便性を実現
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-2 hover:border-primary transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>即座に利用開始</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  複雑な導入作業は不要。登録後すぐに全システムにアクセス可能です。
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>コスト削減</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  個別契約と比較して最大70%のコスト削減。必要なシステムだけを選択可能。
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>安全性</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  エンタープライズグレードのセキュリティで、大切なデータを保護します。
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>専任サポート</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  プランに応じた手厚いサポート体制で、導入から運用まで安心。
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* System Categories */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              4つのカテゴリー、20種類のシステム
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              AI技術から業務管理まで、ビジネスに必要な全てを網羅
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "AI技術",
                icon: "🤖",
                description: "BGM生成、画像生成、動画生成、チャットボットなど最新AI技術",
                count: "6システム",
                gradient: "from-purple-500 to-pink-500"
              },
              {
                title: "業務管理",
                icon: "📊",
                description: "顧客管理、勤務管理、プロジェクト管理など基幹システム",
                count: "9システム",
                gradient: "from-blue-500 to-cyan-500"
              },
              {
                title: "マーケティング",
                icon: "📈",
                description: "SNS自動投稿、SEO最適化、アフィリエイト管理など",
                count: "4システム",
                gradient: "from-green-500 to-emerald-500"
              },
              {
                title: "自動化",
                icon: "⚡",
                description: "ワークフロー自動化で定型業務を効率化",
                count: "1システム",
                gradient: "from-orange-500 to-red-500"
              }
            ].map((category, index) => (
              <Card key={index} className="border-2 hover:shadow-lg transition-all">
                <CardHeader>
                  <div className={`w-16 h-16 bg-gradient-to-br ${category.gradient} rounded-xl flex items-center justify-center text-3xl mb-4`}>
                    {category.icon}
                  </div>
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                  <Badge variant="secondary" className="w-fit">{category.count}</Badge>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {category.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-accent text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            今すぐビジネスを加速させましょう
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            月額29,800円から始められる、業務効率化の決定版
          </p>
          {isAuthenticated ? (
            <Link href="/systems">
              <Button size="lg" variant="secondary" className="text-lg px-8">
                システムを見る
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="text-lg px-8">
                無料で始める
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-card border-t">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="font-bold text-foreground">System Marketplace</span>
              </div>
              <p className="text-sm text-muted-foreground">
                業務効率化システムの総合プラットフォーム
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-foreground">製品</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/systems" className="hover:text-primary">システム一覧</Link></li>
                <li><Link href="/pricing" className="hover:text-primary">料金プラン</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-foreground">サポート</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">ヘルプセンター</a></li>
                <li><a href="#" className="hover:text-primary">お問い合わせ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-foreground">会社情報</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">会社概要</a></li>
                <li><a href="#" className="hover:text-primary">利用規約</a></li>
                <li><a href="#" className="hover:text-primary">プライバシーポリシー</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2026 System Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
