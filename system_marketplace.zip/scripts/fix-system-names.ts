import { getDb } from "../server/db";
import { systems } from "../drizzle/schema";
import { eq } from "drizzle-orm";

async function fixSystemNames() {
  console.log("システム名を修正中...");

  const db = await getDb();
  if (!db) {
    console.error("データベースに接続できません");
    process.exit(1);
  }

  // システムID 2の名前を修正
  await db
    .update(systems)
    .set({ name: "営業メール自動生成" })
    .where(eq(systems.id, 2));

  console.log("✅ システム名を修正しました");
  process.exit(0);
}

fixSystemNames().catch((error) => {
  console.error("エラー:", error);
  process.exit(1);
});
