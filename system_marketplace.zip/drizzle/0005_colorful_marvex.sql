ALTER TABLE `systems` DROP INDEX `systems_system_id_unique`;--> statement-breakpoint
ALTER TABLE `systems` MODIFY COLUMN `category` varchar(100) NOT NULL;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `system_id`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `name_en`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `color`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `file_url`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `file_name`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `file_size`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `file_type`;--> statement-breakpoint
ALTER TABLE `systems` DROP COLUMN `features`;