CREATE TABLE `system_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`system_id` int NOT NULL,
	`rating` int NOT NULL,
	`comment` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `system_reviews_id` PRIMARY KEY(`id`),
	CONSTRAINT `system_reviews_user_id_system_id_unique` UNIQUE(`user_id`,`system_id`)
);
--> statement-breakpoint
ALTER TABLE `systems` ADD `screenshots` text;--> statement-breakpoint
ALTER TABLE `systems` ADD `demo_video_url` varchar(500);--> statement-breakpoint
ALTER TABLE `systems` ADD `tutorial` text;--> statement-breakpoint
ALTER TABLE `systems` ADD `features` text;