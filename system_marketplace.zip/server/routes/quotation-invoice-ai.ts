import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { getDb } from "../db";
import { quotations, quotationItems, invoices, invoiceItems } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const quotationInvoiceAIRouter = router({
  // AI文章生成：件名を生成
  generateTitle: protectedProcedure
    .input(
      z.object({
        customerName: z.string(),
        items: z.array(
          z.object({
            itemName: z.string(),
            description: z.string().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const itemsList = input.items.map((item) => item.itemName).join("、");
      
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "あなたはビジネス文書作成のプロフェッショナルです。見積書や請求書の件名を簡潔かつ適切に生成してください。",
          },
          {
            role: "user",
            content: `顧客名: ${input.customerName}\n提供サービス・商品: ${itemsList}\n\n上記の情報から、見積書または請求書に適した件名を1つ生成してください。件名のみを出力してください。`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const title = typeof content === 'string' ? content.trim() : "";
      return { title };
    }),

  // AI文章生成：備考を生成
  generateNotes: protectedProcedure
    .input(
      z.object({
        customerName: z.string(),
        items: z.array(
          z.object({
            itemName: z.string(),
            description: z.string().optional(),
          })
        ),
        type: z.enum(["quotation", "invoice"]),
      })
    )
    .mutation(async ({ input }) => {
      const itemsList = input.items.map((item) => item.itemName).join("、");
      const documentType = input.type === "quotation" ? "見積書" : "請求書";
      
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "あなたはビジネス文書作成のプロフェッショナルです。見積書や請求書の備考欄に記載する適切な文章を生成してください。",
          },
          {
            role: "user",
            content: `顧客名: ${input.customerName}\n提供サービス・商品: ${itemsList}\n文書種類: ${documentType}\n\n上記の情報から、${documentType}の備考欄に記載する適切な文章を生成してください。支払い条件、納期、その他の注意事項などを含めてください。`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const notes = typeof content === 'string' ? content.trim() : "";
      return { notes };
    }),

  // AI明細提案：過去のデータから類似案件の明細を提案
  suggestItems: protectedProcedure
    .input(
      z.object({
        customerName: z.string().optional(),
        keyword: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });

      // 過去の見積書から明細を取得
      const pastQuotations = await db
        .select()
        .from(quotations)
        .where(eq(quotations.userId, ctx.user.id))
        .orderBy(desc(quotations.createdAt))
        .limit(10);

      if (pastQuotations.length === 0) {
        return { items: [], message: "過去のデータがありません" };
      }

      // 過去の明細を取得
      const quotationIds = pastQuotations.map((q) => q.id);
      const pastItems = await db
        .select()
        .from(quotationItems)
        .where(eq(quotationItems.quotationId, quotationIds[0])); // 最新の見積書の明細を取得

      // AIに類似案件の明細を提案してもらう
      const pastItemsList = pastItems
        .map((item) => `${item.itemName} (${item.quantity}個 × ¥${item.unitPrice})`)
        .join("\n");

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "あなたはビジネスコンサルタントです。過去の取引データから、新しい見積書に適した明細を提案してください。",
          },
          {
            role: "user",
            content: `顧客名: ${input.customerName || "未定"}\nキーワード: ${input.keyword || "なし"}\n\n過去の明細例:\n${pastItemsList}\n\n上記の情報から、新しい見積書に適した明細を3〜5個提案してください。各明細は「品目名 (数量 × 単価)」の形式で出力してください。`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const suggestions = typeof content === 'string' ? content.trim() : "";
      
      // 過去の明細をそのまま返す（AIの提案は参考情報として）
      const suggestedItems = pastItems.map((item) => ({
        itemName: item.itemName,
        description: item.description || "",
        quantity: item.quantity,
        unitPrice: item.unitPrice,
      }));

      return {
        items: suggestedItems,
        aiSuggestion: suggestions,
        message: "過去のデータから明細を提案しました",
      };
    }),

  // AI金額最適化：市場価格との比較、適正価格の提案
  optimizePrice: protectedProcedure
    .input(
      z.object({
        items: z.array(
          z.object({
            itemName: z.string(),
            quantity: z.number(),
            unitPrice: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const itemsList = input.items
        .map((item) => `${item.itemName}: ${item.quantity}個 × ¥${item.unitPrice} = ¥${item.quantity * item.unitPrice}`)
        .join("\n");

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "あなたは価格設定のプロフェッショナルです。提示された明細の価格が適正かどうかを分析し、最適化の提案を行ってください。",
          },
          {
            role: "user",
            content: `以下の明細の価格を分析してください:\n\n${itemsList}\n\n各項目について、価格が適正かどうか、調整の余地があるかどうかを分析し、最適化の提案を行ってください。`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const analysis = typeof content === 'string' ? content.trim() : "";
      
      return {
        analysis,
        message: "価格分析が完了しました",
      };
    }),

  // AIによる顧客情報補完：メールアドレスから会社情報を推測
  enrichCustomerInfo: protectedProcedure
    .input(
      z.object({
        email: z.string().email().optional(),
        companyName: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      if (!input.email && !input.companyName) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "メールアドレスまたは会社名を指定してください",
        });
      }

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "あなたは企業情報のデータベースです。メールアドレスや会社名から、その企業の基本情報を推測してください。",
          },
          {
            role: "user",
            content: `以下の情報から、企業の基本情報（会社名、住所、業種など）を推測してください:\n\nメールアドレス: ${input.email || "なし"}\n会社名: ${input.companyName || "なし"}\n\nJSON形式で出力してください: { "companyName": "...", "address": "...", "industry": "..." }`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const enrichedInfo = typeof content === 'string' ? content.trim() : "{}";
      
      try {
        const parsed = JSON.parse(enrichedInfo);
        return {
          companyName: parsed.companyName || input.companyName || "",
          address: parsed.address || "",
          industry: parsed.industry || "",
          message: "顧客情報を補完しました",
        };
      } catch (error) {
        return {
          companyName: input.companyName || "",
          address: "",
          industry: "",
          message: "顧客情報の補完に失敗しました",
        };
      }
    }),
});
