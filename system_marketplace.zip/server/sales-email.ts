import { z } from "zod";
import { router, protectedProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { emailTemplates, emailHistory, customers } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";

export const salesEmailRouter = router({
  /**
   * メールテンプレート一覧を取得
   */
  getTemplates: protectedProcedure
    .input(z.object({
      category: z.string().optional(),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const conditions = [eq(emailTemplates.userId, ctx.user.id)];

      if (input.category) {
        conditions.push(eq(emailTemplates.category, input.category));
      }

      const templates = await db
        .select()
        .from(emailTemplates)
        .where(and(...conditions))
        .orderBy(desc(emailTemplates.createdAt));
      return templates;
    }),

  /**
   * メールテンプレートを作成
   */
  createTemplate: protectedProcedure
    .input(z.object({
      name: z.string(),
      category: z.string(),
      subject: z.string(),
      body: z.string(),
      variables: z.string().optional(),
      isDefault: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const result = await db.insert(emailTemplates).values({
        userId: ctx.user.id,
        name: input.name,
        category: input.category,
        subject: input.subject,
        body: input.body,
        variables: input.variables || null,
        isDefault: input.isDefault || false,
      }).$returningId();

      return { id: result[0].id, success: true };
    }),

  /**
   * メールテンプレートを更新
   */
  updateTemplate: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      category: z.string().optional(),
      subject: z.string().optional(),
      body: z.string().optional(),
      variables: z.string().optional(),
      isDefault: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const { id, ...updates } = input;
      await db
        .update(emailTemplates)
        .set(updates)
        .where(and(
          eq(emailTemplates.id, id),
          eq(emailTemplates.userId, ctx.user.id)
        ));

      return { success: true };
    }),

  /**
   * メールテンプレートを削除
   */
  deleteTemplate: protectedProcedure
    .input(z.object({
      id: z.number(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      await db
        .delete(emailTemplates)
        .where(and(
          eq(emailTemplates.id, input.id),
          eq(emailTemplates.userId, ctx.user.id)
        ));

      return { success: true };
    }),

  /**
   * AIで営業メールを自動生成
   */
  generateEmail: protectedProcedure
    .input(z.object({
      customerId: z.number().optional(),
      category: z.string(), // 初回営業、フォローアップ、お礼など
      companyName: z.string().optional(),
      contactName: z.string().optional(),
      productService: z.string().optional(),
      additionalInfo: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // 顧客情報を取得（customerId指定時）
      let customerInfo = "";
      if (input.customerId) {
        const customer = await db
          .select()
          .from(customers)
          .where(and(
            eq(customers.id, input.customerId),
            eq(customers.userId, ctx.user.id)
          ))
          .limit(1);

        if (customer.length > 0) {
          customerInfo = `
会社名: ${customer[0].companyName || "不明"}
担当者名: ${customer[0].contactName}
メールアドレス: ${customer[0].email || "不明"}
`;
        }
      } else if (input.companyName || input.contactName) {
        customerInfo = `
会社名: ${input.companyName || "不明"}
担当者名: ${input.contactName || "不明"}
`;
      }

      // AIプロンプト作成
      const prompt = `あなたはプロの営業担当者です。以下の情報をもとに、効果的な営業メールを作成してください。

【メールの種類】
${input.category}

【顧客情報】
${customerInfo}

【商品・サービス】
${input.productService || "貴社のビジネスに最適なソリューション"}

【追加情報】
${input.additionalInfo || "なし"}

【要件】
- 件名と本文を作成してください
- 件名は魅力的で開封率が高くなるようにしてください
- 本文は丁寧で親しみやすく、かつプロフェッショナルなトーンで書いてください
- 具体的な価値提案を含めてください
- 行動喚起（CTA）を明確にしてください
- 日本語で作成してください

【出力形式】
件名: [ここに件名]

本文:
[ここに本文]`;

      // AI生成
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "あなたはプロの営業メール作成アシスタントです。" },
          { role: "user", content: prompt },
        ],
      });

      const generatedText = typeof response.choices[0].message.content === 'string' 
        ? response.choices[0].message.content 
        : '';

      // 件名と本文を分離
      const subjectMatch = generatedText.match(/件名[：:]s*(.+)/);
      const bodyMatch = generatedText.match(/本文[：:]s*([\s\S]+)/);

      const subject = subjectMatch ? subjectMatch[1].trim() : "営業メール";
      const body = bodyMatch ? bodyMatch[1].trim() : generatedText;

      return {
        subject,
        body,
        success: true,
      };
    }),

  /**
   * メール送信履歴を保存
   */
  saveEmail: protectedProcedure
    .input(z.object({
      customerId: z.number().optional(),
      templateId: z.number().optional(),
      subject: z.string(),
      body: z.string(),
      recipient: z.string(),
      status: z.enum(["draft", "sent"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const result = await db.insert(emailHistory).values({
        userId: ctx.user.id,
        customerId: input.customerId || null,
        templateId: input.templateId || null,
        subject: input.subject,
        body: input.body,
        recipient: input.recipient,
        status: input.status || "draft",
        sentAt: input.status === "sent" ? new Date() : null,
      }).$returningId();

      return { id: result[0].id, success: true };
    }),

  /**
   * メール送信履歴を取得
   */
  getHistory: protectedProcedure
    .input(z.object({
      customerId: z.number().optional(),
      status: z.enum(["draft", "sent"]).optional(),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const conditions = [eq(emailHistory.userId, ctx.user.id)];

      if (input.customerId) {
        conditions.push(eq(emailHistory.customerId, input.customerId));
      }

      if (input.status) {
        conditions.push(eq(emailHistory.status, input.status));
      }

      const history = await db
        .select()
        .from(emailHistory)
        .where(and(...conditions))
        .orderBy(desc(emailHistory.createdAt));
      return history;
    }),

  /**
   * メール送信履歴を削除
   */
  deleteHistory: protectedProcedure
    .input(z.object({
      id: z.number(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      await db
        .delete(emailHistory)
        .where(and(
          eq(emailHistory.id, input.id),
          eq(emailHistory.userId, ctx.user.id)
        ));

      return { success: true };
    }),
});
