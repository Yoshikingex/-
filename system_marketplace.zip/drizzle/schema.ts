import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, unique } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  
  // Stripe関連
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  
  // サブスクリプション情報
  currentPlan: mysqlEnum("current_plan", ["starter", "business", "enterprise"]),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  subscriptionStatus: mysqlEnum("subscription_status", ["active", "canceled", "past_due", "incomplete", "trialing"]),
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * システムテーブル
 * 20個の業務効率化システムの情報を保存
 */
export const systems = mysqlTable("systems", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  
  // 詳細情報
  screenshots: text("screenshots"), // JSON array of screenshot URLs
  demoVideoUrl: varchar("demo_video_url", { length: 500 }),
  tutorial: text("tutorial"), // Markdown format
  
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type System = typeof systems.$inferSelect;
export type InsertSystem = typeof systems.$inferInsert;

/**
 * ユーザーが選択したシステムの関連テーブル
 */
export const userSystems = mysqlTable("user_systems", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  systemId: int("system_id").notNull(),
  addedAt: timestamp("added_at").defaultNow().notNull(),
}, (table) => ({
  uniqUserSystem: unique().on(table.userId, table.systemId),
}));

export type UserSystem = typeof userSystems.$inferSelect;
export type InsertUserSystem = typeof userSystems.$inferInsert;

/**
 * ダウンロード履歴テーブル
 */
export const downloadHistory = mysqlTable("download_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  systemId: int("system_id").notNull(),
  downloadedAt: timestamp("downloaded_at").defaultNow().notNull(),
});

export type DownloadHistory = typeof downloadHistory.$inferSelect;
export type InsertDownloadHistory = typeof downloadHistory.$inferInsert;

/**
 * サブスクリプション履歴テーブル
 */
export const subscriptionHistory = mysqlTable("subscription_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  planType: mysqlEnum("plan_type", ["starter", "business", "enterprise"]).notNull(),
  action: mysqlEnum("action", ["created", "upgraded", "downgraded", "canceled", "renewed"]).notNull(),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  stripeInvoiceId: varchar("stripe_invoice_id", { length: 255 }),
  amount: int("amount"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type SubscriptionHistory = typeof subscriptionHistory.$inferSelect;
export type InsertSubscriptionHistory = typeof subscriptionHistory.$inferInsert;

/**
 * システムレビューテーブル
 */
export const systemReviews = mysqlTable("system_reviews", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  systemId: int("system_id").notNull(),
  rating: int("rating").notNull(), // 1-5
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  uniqUserSystemReview: unique().on(table.userId, table.systemId),
}));

export type SystemReview = typeof systemReviews.$inferSelect;
export type InsertSystemReview = typeof systemReviews.$inferInsert;
/**
 * AI使用量テーブル
 * ユーザーごとの月間AI使用回数を記録
 */
export const userAiUsage = mysqlTable("user_ai_usage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  month: varchar("month", { length: 7 }).notNull(), // YYYY-MM形式
  imageCount: int("image_count").default(0).notNull(),
  videoCount: int("video_count").default(0).notNull(),
  bgmCount: int("bgm_count").default(0).notNull(),
  promptCount: int("prompt_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  uniqUserMonth: unique().on(table.userId, table.month),
}));

export type UserAiUsage = typeof userAiUsage.$inferSelect;
export type InsertUserAiUsage = typeof userAiUsage.$inferInsert;

/**
 * 顧客管理CRM - 顧客情報テーブル
 */
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(), // システム利用者
  
  // 基本情報
  companyName: varchar("company_name", { length: 255 }),
  contactName: varchar("contact_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  
  // 住所情報
  postalCode: varchar("postal_code", { length: 20 }),
  address: text("address"),
  
  // ステータス
  status: mysqlEnum("status", ["lead", "prospect", "customer", "inactive"]).default("lead").notNull(),
  
  // タグ（カンマ区切り）
  tags: text("tags"),
  
  // メモ
  notes: text("notes"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

/**
 * 顧客管理CRM - 顧客履歴テーブル
 */
export const customerHistory = mysqlTable("customer_history", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customer_id").notNull(),
  userId: int("user_id").notNull(), // 履歴を作成したユーザー
  
  // 履歴タイプ
  type: mysqlEnum("type", ["contact", "meeting", "email", "call", "note"]).notNull(),
  
  // 履歴内容
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type CustomerHistory = typeof customerHistory.$inferSelect;
export type InsertCustomerHistory = typeof customerHistory.$inferInsert;

/**
 * 営業メール自動生成 - メールテンプレートテーブル
 */
export const emailTemplates = mysqlTable("email_templates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(), // 初回営業、フォローアップ、お礼など
  subject: varchar("subject", { length: 500 }).notNull(),
  body: text("body").notNull(),
  variables: text("variables"), // JSON形式
  isDefault: boolean("is_default").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = typeof emailTemplates.$inferInsert;

/**
 * 営業メール自動生成 - 送信履歴テーブル
 */
export const emailHistory = mysqlTable("email_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  customerId: int("customer_id"),
  templateId: int("template_id"),
  subject: varchar("subject", { length: 500 }).notNull(),
  body: text("body").notNull(),
  recipient: varchar("recipient", { length: 320 }).notNull(),
  status: mysqlEnum("status", ["draft", "sent"]).default("draft").notNull(),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type EmailHistory = typeof emailHistory.$inferSelect;
export type InsertEmailHistory = typeof emailHistory.$inferInsert;

/**
 * 見積書・請求書作成システム - 見積書テーブル
 */
export const quotations = mysqlTable("quotations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  
  // 見積書番号
  quotationNumber: varchar("quotation_number", { length: 100 }).notNull().unique(),
  
  // 顧客情報
  customerId: int("customer_id"),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 320 }),
  customerAddress: text("customer_address"),
  
  // 見積情報
  title: varchar("title", { length: 255 }).notNull(),
  issueDate: timestamp("issue_date").notNull(),
  expiryDate: timestamp("expiry_date"),
  
  // 金額
  subtotal: int("subtotal").notNull(), // 小計（円）
  taxRate: int("tax_rate").default(10).notNull(), // 消費税率（%）
  taxAmount: int("tax_amount").notNull(), // 消費税額（円）
  totalAmount: int("total_amount").notNull(), // 合計金額（円）
  
  // その他
  notes: text("notes"), // 備考
  status: mysqlEnum("status", ["draft", "sent", "accepted", "rejected"]).default("draft").notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Quotation = typeof quotations.$inferSelect;
export type InsertQuotation = typeof quotations.$inferInsert;

/**
 * 見積書・請求書作成システム - 見積書明細テーブル
 */
export const quotationItems = mysqlTable("quotation_items", {
  id: int("id").autoincrement().primaryKey(),
  quotationId: int("quotation_id").notNull(),
  
  // 明細情報
  itemName: varchar("item_name", { length: 255 }).notNull(),
  description: text("description"),
  quantity: int("quantity").notNull(),
  unitPrice: int("unit_price").notNull(), // 単価（円）
  amount: int("amount").notNull(), // 金額（円）
  
  // 並び順
  sortOrder: int("sort_order").default(0).notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type QuotationItem = typeof quotationItems.$inferSelect;
export type InsertQuotationItem = typeof quotationItems.$inferInsert;

/**
 * 見積書・請求書作成システム - 請求書テーブル
 */
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  
  // 請求書番号
  invoiceNumber: varchar("invoice_number", { length: 100 }).notNull().unique(),
  
  // 見積書との紐付け（オプション）
  quotationId: int("quotation_id"),
  
  // 顧客情報
  customerId: int("customer_id"),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 320 }),
  customerAddress: text("customer_address"),
  
  // 請求情報
  title: varchar("title", { length: 255 }).notNull(),
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date").notNull(), // 支払期限
  
  // 金額
  subtotal: int("subtotal").notNull(), // 小計（円）
  taxRate: int("tax_rate").default(10).notNull(), // 消費税率（%）
  taxAmount: int("tax_amount").notNull(), // 消費税額（円）
  totalAmount: int("total_amount").notNull(), // 合計金額（円）
  
  // 支払い情報
  paymentMethod: varchar("payment_method", { length: 100 }), // 銀行振込、クレジットカードなど
  bankInfo: text("bank_info"), // 振込先情報
  
  // その他
  notes: text("notes"), // 備考
  status: mysqlEnum("status", ["draft", "sent", "paid", "overdue", "canceled"]).default("draft").notNull(),
  paidAt: timestamp("paid_at"), // 支払日
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;

/**
 * 見積書・請求書作成システム - 請求書明細テーブル
 */
export const invoiceItems = mysqlTable("invoice_items", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoice_id").notNull(),
  
  // 明細情報
  itemName: varchar("item_name", { length: 255 }).notNull(),
  description: text("description"),
  quantity: int("quantity").notNull(),
  unitPrice: int("unit_price").notNull(), // 単価（円）
  amount: int("amount").notNull(), // 金額（円）
  
  // 並び順
  sortOrder: int("sort_order").default(0).notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type InsertInvoiceItem = typeof invoiceItems.$inferInsert;

/**
 * 会社プロフィールテーブル
 * 見積書・請求書に表示する自社情報を管理
 */
export const companyProfiles = mysqlTable("company_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(), // ユーザーID
  
  // 基本情報
  companyName: varchar("company_name", { length: 255 }).notNull(),
  companyNameKana: varchar("company_name_kana", { length: 255 }),
  postalCode: varchar("postal_code", { length: 20 }),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  fax: varchar("fax", { length: 50 }),
  email: varchar("email", { length: 320 }),
  website: varchar("website", { length: 500 }),
  
  // ロゴ
  logoUrl: varchar("logo_url", { length: 500 }),
  
  // 銀行情報
  bankName: varchar("bank_name", { length: 255 }),
  branchName: varchar("branch_name", { length: 255 }),
  accountType: varchar("account_type", { length: 50 }), // 普通、当座など
  accountNumber: varchar("account_number", { length: 50 }),
  accountHolder: varchar("account_holder", { length: 255 }),
  
  // 代表者情報
  representativeName: varchar("representative_name", { length: 255 }),
  representativeTitle: varchar("representative_title", { length: 100 }), // 代表取締役など
  
  // その他
  businessNumber: varchar("business_number", { length: 50 }), // 法人番号
  taxIdNumber: varchar("tax_id_number", { length: 50 }), // 適格請求書発行事業者登録番号（インボイス番号）
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type CompanyProfile = typeof companyProfiles.$inferSelect;
export type InsertCompanyProfile = typeof companyProfiles.$inferInsert;
