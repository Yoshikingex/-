import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { quotations, quotationItems, invoices, invoiceItems, customers } from "../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

/**
 * 見積書・請求書作成システムのtRPCルーター
 */
export const quotationInvoiceRouter = router({
  // ========== 見積書 ==========
  
  /**
   * 見積書一覧を取得
   */
  getQuotations: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("データベースに接続できません");
    
    const result = await db
      .select()
      .from(quotations)
      .where(eq(quotations.userId, ctx.user.id))
      .orderBy(desc(quotations.createdAt));
    
    return result;
  }),

  /**
   * 見積書詳細を取得（明細含む）
   */
  getQuotationDetail: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      const [quotation] = await db
        .select()
        .from(quotations)
        .where(and(eq(quotations.id, input.id), eq(quotations.userId, ctx.user.id)));
      
      if (!quotation) {
        throw new Error("見積書が見つかりません");
      }

      const items = await db
        .select()
        .from(quotationItems)
        .where(eq(quotationItems.quotationId, input.id))
        .orderBy(quotationItems.sortOrder);

      return { quotation, items };
    }),

  /**
   * 見積書を作成
   */
  createQuotation: protectedProcedure
    .input(z.object({
      quotationNumber: z.string(),
      customerId: z.number().optional(),
      customerName: z.string(),
      customerEmail: z.string().optional(),
      customerAddress: z.string().optional(),
      title: z.string(),
      issueDate: z.string(),
      expiryDate: z.string().optional(),
      notes: z.string().optional(),
      items: z.array(z.object({
        itemName: z.string(),
        description: z.string().optional(),
        quantity: z.number(),
        unitPrice: z.number(),
      })),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 明細の金額を計算
      let subtotal = 0;
      const itemsWithAmount = input.items.map((item, index) => {
        const amount = item.quantity * item.unitPrice;
        subtotal += amount;
        return {
          ...item,
          amount,
          sortOrder: index,
        };
      });

      const taxRate = 10;
      const taxAmount = Math.floor(subtotal * taxRate / 100);
      const totalAmount = subtotal + taxAmount;

      // 見積書を作成
      const [quotation] = await db.insert(quotations).values({
        userId: ctx.user.id,
        quotationNumber: input.quotationNumber,
        customerId: input.customerId,
        customerName: input.customerName,
        customerEmail: input.customerEmail,
        customerAddress: input.customerAddress,
        title: input.title,
        issueDate: new Date(input.issueDate),
        expiryDate: input.expiryDate ? new Date(input.expiryDate) : null,
        subtotal,
        taxRate,
        taxAmount,
        totalAmount,
        notes: input.notes,
        status: "draft",
      });

      // 明細を作成
      if (itemsWithAmount.length > 0) {
        await db.insert(quotationItems).values(
          itemsWithAmount.map((item) => ({
            quotationId: quotation.insertId,
            itemName: item.itemName,
            description: item.description || null,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            amount: item.amount,
            sortOrder: item.sortOrder,
          }))
        );
      }

      return { id: quotation.insertId };
    }),

  /**
   * 見積書を更新
   */
  updateQuotation: protectedProcedure
    .input(z.object({
      id: z.number(),
      quotationNumber: z.string().optional(),
      customerId: z.number().optional(),
      customerName: z.string().optional(),
      customerEmail: z.string().optional(),
      customerAddress: z.string().optional(),
      title: z.string().optional(),
      issueDate: z.string().optional(),
      expiryDate: z.string().optional(),
      notes: z.string().optional(),
      status: z.enum(["draft", "sent", "accepted", "rejected"]).optional(),
      items: z.array(z.object({
        itemName: z.string(),
        description: z.string().optional(),
        quantity: z.number(),
        unitPrice: z.number(),
      })).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 見積書の存在確認
      const [existing] = await db
        .select()
        .from(quotations)
        .where(and(eq(quotations.id, input.id), eq(quotations.userId, ctx.user.id)));

      if (!existing) {
        throw new Error("見積書が見つかりません");
      }

      // 明細が更新される場合は金額を再計算
      let updateData: any = {};
      
      if (input.items) {
        let subtotal = 0;
        const itemsWithAmount = input.items.map((item, index) => {
          const amount = item.quantity * item.unitPrice;
          subtotal += amount;
          return {
            ...item,
            amount,
            sortOrder: index,
          };
        });

        const taxRate = 10;
        const taxAmount = Math.floor(subtotal * taxRate / 100);
        const totalAmount = subtotal + taxAmount;

        updateData = {
          subtotal,
          taxAmount,
          totalAmount,
        };

        // 既存の明細を削除して新しい明細を作成
        await db.delete(quotationItems).where(eq(quotationItems.quotationId, input.id));
        
        if (itemsWithAmount.length > 0) {
          await db.insert(quotationItems).values(
            itemsWithAmount.map((item) => ({
              quotationId: input.id,
              itemName: item.itemName,
              description: item.description || null,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              amount: item.amount,
              sortOrder: item.sortOrder,
            }))
          );
        }
      }

      // その他のフィールドを更新
      if (input.quotationNumber) updateData.quotationNumber = input.quotationNumber;
      if (input.customerId !== undefined) updateData.customerId = input.customerId;
      if (input.customerName) updateData.customerName = input.customerName;
      if (input.customerEmail !== undefined) updateData.customerEmail = input.customerEmail;
      if (input.customerAddress !== undefined) updateData.customerAddress = input.customerAddress;
      if (input.title) updateData.title = input.title;
      if (input.issueDate) updateData.issueDate = new Date(input.issueDate);
      if (input.expiryDate !== undefined) updateData.expiryDate = input.expiryDate ? new Date(input.expiryDate) : null;
      if (input.notes !== undefined) updateData.notes = input.notes;
      if (input.status) updateData.status = input.status;

      await db.update(quotations).set(updateData).where(eq(quotations.id, input.id));

      return { success: true };
    }),

  /**
   * 見積書を削除
   */
  deleteQuotation: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 見積書の存在確認
      const [existing] = await db
        .select()
        .from(quotations)
        .where(and(eq(quotations.id, input.id), eq(quotations.userId, ctx.user.id)));

      if (!existing) {
        throw new Error("見積書が見つかりません");
      }

      // 明細を削除
      await db.delete(quotationItems).where(eq(quotationItems.quotationId, input.id));

      // 見積書を削除
      await db.delete(quotations).where(eq(quotations.id, input.id));

      return { success: true };
    }),

  // ========== 請求書 ==========

  /**
   * 請求書一覧を取得
   */
  getInvoices: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("データベースに接続できません");
    
    const result = await db
      .select()
      .from(invoices)
      .where(eq(invoices.userId, ctx.user.id))
      .orderBy(desc(invoices.createdAt));
    
    return result;
  }),

  /**
   * 請求書詳細を取得（明細含む）
   */
  getInvoiceDetail: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      const [invoice] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id, input.id), eq(invoices.userId, ctx.user.id)));
      
      if (!invoice) {
        throw new Error("請求書が見つかりません");
      }

      const items = await db
        .select()
        .from(invoiceItems)
        .where(eq(invoiceItems.invoiceId, input.id))
        .orderBy(invoiceItems.sortOrder);

      return { invoice, items };
    }),

  /**
   * 請求書を作成
   */
  createInvoice: protectedProcedure
    .input(z.object({
      invoiceNumber: z.string(),
      quotationId: z.number().optional(),
      customerId: z.number().optional(),
      customerName: z.string(),
      customerEmail: z.string().optional(),
      customerAddress: z.string().optional(),
      title: z.string(),
      issueDate: z.string(),
      dueDate: z.string(),
      paymentMethod: z.string().optional(),
      bankInfo: z.string().optional(),
      notes: z.string().optional(),
      items: z.array(z.object({
        itemName: z.string(),
        description: z.string().optional(),
        quantity: z.number(),
        unitPrice: z.number(),
      })),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 明細の金額を計算
      let subtotal = 0;
      const itemsWithAmount = input.items.map((item, index) => {
        const amount = item.quantity * item.unitPrice;
        subtotal += amount;
        return {
          ...item,
          amount,
          sortOrder: index,
        };
      });

      const taxRate = 10;
      const taxAmount = Math.floor(subtotal * taxRate / 100);
      const totalAmount = subtotal + taxAmount;

      // 請求書を作成
      const [invoice] = await db.insert(invoices).values({
        userId: ctx.user.id,
        invoiceNumber: input.invoiceNumber,
        quotationId: input.quotationId,
        customerId: input.customerId,
        customerName: input.customerName,
        customerEmail: input.customerEmail,
        customerAddress: input.customerAddress,
        title: input.title,
        issueDate: new Date(input.issueDate),
        dueDate: new Date(input.dueDate),
        paymentMethod: input.paymentMethod,
        bankInfo: input.bankInfo,
        subtotal,
        taxRate,
        taxAmount,
        totalAmount,
        notes: input.notes,
        status: "draft",
      });

      // 明細を作成
      if (itemsWithAmount.length > 0) {
        await db.insert(invoiceItems).values(
          itemsWithAmount.map((item) => ({
            invoiceId: invoice.insertId,
            itemName: item.itemName,
            description: item.description || null,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            amount: item.amount,
            sortOrder: item.sortOrder,
          }))
        );
      }

      return { id: invoice.insertId };
    }),

  /**
   * 見積書から請求書を作成
   */
  createInvoiceFromQuotation: protectedProcedure
    .input(z.object({
      quotationId: z.number(),
      invoiceNumber: z.string(),
      issueDate: z.string(),
      dueDate: z.string(),
      paymentMethod: z.string().optional(),
      bankInfo: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 見積書を取得
      const [quotation] = await db
        .select()
        .from(quotations)
        .where(and(eq(quotations.id, input.quotationId), eq(quotations.userId, ctx.user.id)));

      if (!quotation) {
        throw new Error("見積書が見つかりません");
      }

      // 見積書の明細を取得
      const items = await db
        .select()
        .from(quotationItems)
        .where(eq(quotationItems.quotationId, input.quotationId))
        .orderBy(quotationItems.sortOrder);

      // 請求書を作成
      const [invoice] = await db.insert(invoices).values({
        userId: ctx.user.id,
        invoiceNumber: input.invoiceNumber,
        quotationId: input.quotationId,
        customerId: quotation.customerId,
        customerName: quotation.customerName,
        customerEmail: quotation.customerEmail,
        customerAddress: quotation.customerAddress,
        title: quotation.title,
        issueDate: new Date(input.issueDate),
        dueDate: new Date(input.dueDate),
        paymentMethod: input.paymentMethod,
        bankInfo: input.bankInfo,
        subtotal: quotation.subtotal,
        taxRate: quotation.taxRate,
        taxAmount: quotation.taxAmount,
        totalAmount: quotation.totalAmount,
        notes: quotation.notes,
        status: "draft",
      });

      // 明細を作成
      if (items.length > 0) {
        await db.insert(invoiceItems).values(
          items.map((item) => ({
            invoiceId: invoice.insertId,
            itemName: item.itemName,
            description: item.description,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            amount: item.amount,
            sortOrder: item.sortOrder,
          }))
        );
      }

      return { id: invoice.insertId };
    }),

  /**
   * 請求書を更新
   */
  updateInvoice: protectedProcedure
    .input(z.object({
      id: z.number(),
      invoiceNumber: z.string().optional(),
      customerId: z.number().optional(),
      customerName: z.string().optional(),
      customerEmail: z.string().optional(),
      customerAddress: z.string().optional(),
      title: z.string().optional(),
      issueDate: z.string().optional(),
      dueDate: z.string().optional(),
      paymentMethod: z.string().optional(),
      bankInfo: z.string().optional(),
      notes: z.string().optional(),
      status: z.enum(["draft", "sent", "paid", "overdue", "canceled"]).optional(),
      paidAt: z.string().optional(),
      items: z.array(z.object({
        itemName: z.string(),
        description: z.string().optional(),
        quantity: z.number(),
        unitPrice: z.number(),
      })).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 請求書の存在確認
      const [existing] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id, input.id), eq(invoices.userId, ctx.user.id)));

      if (!existing) {
        throw new Error("請求書が見つかりません");
      }

      // 明細が更新される場合は金額を再計算
      let updateData: any = {};
      
      if (input.items) {
        let subtotal = 0;
        const itemsWithAmount = input.items.map((item, index) => {
          const amount = item.quantity * item.unitPrice;
          subtotal += amount;
          return {
            ...item,
            amount,
            sortOrder: index,
          };
        });

        const taxRate = 10;
        const taxAmount = Math.floor(subtotal * taxRate / 100);
        const totalAmount = subtotal + taxAmount;

        updateData = {
          subtotal,
          taxAmount,
          totalAmount,
        };

        // 既存の明細を削除して新しい明細を作成
        await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, input.id));
        
        if (itemsWithAmount.length > 0) {
          await db.insert(invoiceItems).values(
            itemsWithAmount.map((item) => ({
              invoiceId: input.id,
              itemName: item.itemName,
              description: item.description || null,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              amount: item.amount,
              sortOrder: item.sortOrder,
            }))
          );
        }
      }

      // その他のフィールドを更新
      if (input.invoiceNumber) updateData.invoiceNumber = input.invoiceNumber;
      if (input.customerId !== undefined) updateData.customerId = input.customerId;
      if (input.customerName) updateData.customerName = input.customerName;
      if (input.customerEmail !== undefined) updateData.customerEmail = input.customerEmail;
      if (input.customerAddress !== undefined) updateData.customerAddress = input.customerAddress;
      if (input.title) updateData.title = input.title;
      if (input.issueDate) updateData.issueDate = new Date(input.issueDate);
      if (input.dueDate) updateData.dueDate = new Date(input.dueDate);
      if (input.paymentMethod !== undefined) updateData.paymentMethod = input.paymentMethod;
      if (input.bankInfo !== undefined) updateData.bankInfo = input.bankInfo;
      if (input.notes !== undefined) updateData.notes = input.notes;
      if (input.status) updateData.status = input.status;
      if (input.paidAt !== undefined) updateData.paidAt = input.paidAt ? new Date(input.paidAt) : null;

      await db.update(invoices).set(updateData).where(eq(invoices.id, input.id));

      return { success: true };
    }),

  /**
   * 請求書を削除
   */
  deleteInvoice: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("データベースに接続できません");
      
      // 請求書の存在確認
      const [existing] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id, input.id), eq(invoices.userId, ctx.user.id)));

      if (!existing) {
        throw new Error("請求書が見つかりません");
      }

      // 明細を削除
      await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, input.id));

      // 請求書を削除
      await db.delete(invoices).where(eq(invoices.id, input.id));

      return { success: true };
    }),

  /**
   * 顧客一覧を取得（見積書・請求書作成時に使用）
   */
  getCustomers: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("データベースに接続できません");
    
    const result = await db
      .select()
      .from(customers)
      .where(eq(customers.userId, ctx.user.id))
      .orderBy(desc(customers.createdAt));
    
    return result;
  }),
});
