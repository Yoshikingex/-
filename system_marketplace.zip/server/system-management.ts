import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { systems } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

/**
 * システム管理用のtRPCルーター
 * 管理者のみがアクセス可能
 */

// 管理者専用プロシージャ
const adminOnlyProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: '管理者権限が必要です' });
  }
  return next({ ctx });
});

export const systemManagementRouter = router({
  /**
   * 全システムを取得（管理者用）
   */
  listAll: adminOnlyProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'データベースに接続できません' });

    const allSystems = await db.select().from(systems);
    return allSystems;
  }),

  /**
   * システムを追加
   */
  create: adminOnlyProcedure
    .input(z.object({
      name: z.string().min(1),
      description: z.string().min(1),
      category: z.string().min(1),
      icon: z.string().min(1),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'データベースに接続できません' });

      await db.insert(systems).values({
        name: input.name,
        description: input.description,
        category: input.category,
        icon: input.icon,
        isActive: true,
      });

      return { success: true };
    }),

  /**
   * システムを更新
   */
  update: adminOnlyProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      description: z.string().min(1).optional(),
      category: z.string().min(1).optional(),
      icon: z.string().min(1).optional(),
      screenshots: z.string().optional(),
      demoVideoUrl: z.string().optional(),
      tutorial: z.string().optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'データベースに接続できません' });

      const { id, ...updateData } = input;
      await db.update(systems).set(updateData).where(eq(systems.id, id));

      return { success: true };
    }),

  /**
   * システムを削除
   */
  delete: adminOnlyProcedure
    .input(z.object({
      id: z.number(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'データベースに接続できません' });

      await db.delete(systems).where(eq(systems.id, input.id));

      return { success: true };
    }),


});
