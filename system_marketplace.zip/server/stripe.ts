import Stripe from 'stripe';
import { PLANS } from '../shared/systems';
import { STRIPE_PRODUCTS } from './products';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2025-12-15.clover',
});

export async function createCheckoutSession(params: {
  planId: string;
  userId: number;
  userEmail: string;
  userName: string;
  successUrl: string;
  cancelUrl: string;
}) {
  const { planId, userId, userEmail, userName, successUrl, cancelUrl } = params;

  // プラン情報を取得
  const plan = PLANS.find(p => p.id === planId);
  if (!plan) {
    throw new Error('Invalid plan ID');
  }

  // Stripe Product IDを取得
  const productInfo = STRIPE_PRODUCTS[planId as keyof typeof STRIPE_PRODUCTS];
  if (!productInfo) {
    throw new Error('Stripe product not configured for this plan');
  }

  // チェックアウトセッションを作成
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [
      {
        price: productInfo.priceId,
        quantity: 1,
      },
    ],
    success_url: successUrl,
    cancel_url: cancelUrl,
    customer_email: userEmail,
    client_reference_id: userId.toString(),
    metadata: {
      user_id: userId.toString(),
      customer_email: userEmail,
      customer_name: userName,
      plan_id: planId,
    },
    allow_promotion_codes: true,
    subscription_data: {
      metadata: {
        user_id: userId.toString(),
        plan_id: planId,
      },
    },
  });

  return {
    sessionId: session.id,
    url: session.url,
  };
}

export async function createCustomerPortalSession(params: {
  customerId: string;
  returnUrl: string;
}) {
  const { customerId, returnUrl } = params;

  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });

  return {
    url: session.url,
  };
}

export async function getSubscriptionDetails(subscriptionId: string) {
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  return subscription;
}

export async function cancelSubscription(subscriptionId: string) {
  const subscription = await stripe.subscriptions.cancel(subscriptionId);
  return subscription;
}
