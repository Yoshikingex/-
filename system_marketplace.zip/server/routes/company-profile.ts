import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { getDb } from "../db";
import { companyProfiles } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const companyProfileRouter = router({
  // 会社プロフィールを取得
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });
    const profiles = await db
      .select()
      .from(companyProfiles)
      .where(eq(companyProfiles.userId, ctx.user.id))
      .limit(1);
    
    return profiles[0] || null;
  }),

  // 会社プロフィールを作成または更新
  upsertProfile: protectedProcedure
    .input(
      z.object({
        companyName: z.string().min(1),
        companyNameKana: z.string().optional(),
        postalCode: z.string().optional(),
        address: z.string().optional(),
        phone: z.string().optional(),
        fax: z.string().optional(),
        email: z.string().email().optional(),
        website: z.string().url().optional().or(z.literal("")),
        logoUrl: z.string().url().optional().or(z.literal("")),
        bankName: z.string().optional(),
        branchName: z.string().optional(),
        accountType: z.string().optional(),
        accountNumber: z.string().optional(),
        accountHolder: z.string().optional(),
        representativeName: z.string().optional(),
        representativeTitle: z.string().optional(),
        businessNumber: z.string().optional(),
        taxIdNumber: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });
      
      // 既存のプロフィールを確認
      const existing = await db
        .select()
        .from(companyProfiles)
        .where(eq(companyProfiles.userId, ctx.user.id))
        .limit(1);

      if (existing.length > 0) {
        // 更新
        await db
          .update(companyProfiles)
          .set({
            ...input,
            updatedAt: new Date(),
          })
          .where(eq(companyProfiles.userId, ctx.user.id));
        
        return { success: true, message: "会社プロフィールを更新しました" };
      } else {
        // 新規作成
        await db.insert(companyProfiles).values({
          userId: ctx.user.id,
          ...input,
        });
        
        return { success: true, message: "会社プロフィールを作成しました" };
      }
    }),

  // 初期データを作成（ユーザー情報から自動生成）
  createInitialProfile: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database connection failed" });
    
    // 既存のプロフィールを確認
    const existing = await db
      .select()
      .from(companyProfiles)
      .where(eq(companyProfiles.userId, ctx.user.id))
      .limit(1);

    if (existing.length > 0) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "会社プロフィールは既に存在します",
      });
    }

    // ユーザー情報から初期プロフィールを作成
    await db.insert(companyProfiles).values({
      userId: ctx.user.id,
      companyName: ctx.user.name || "株式会社サンプル",
      email: ctx.user.email || "",
      representativeName: ctx.user.name || "",
      representativeTitle: "代表取締役",
    });

    return { success: true, message: "初期プロフィールを作成しました" };
  }),
});
