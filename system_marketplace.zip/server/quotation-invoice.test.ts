import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 999,
    openId: "test-quotation-user",
    email: "quotation@test.com",
    name: "Test Quotation User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("Quotation Invoice System", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  let testQuotationId: number;
  let testInvoiceId: number;

  beforeAll(async () => {
    const ctx = createTestContext();
    caller = appRouter.createCaller(ctx);
  });

  it("顧客一覧を取得できる", async () => {
    const customers = await caller.quotationInvoice.getCustomers();
    expect(Array.isArray(customers)).toBe(true);
  });

  it("見積書を作成できる", async () => {
    const result = await caller.quotationInvoice.createQuotation({
      quotationNumber: "Q-TEST-001",
      customerName: "テスト株式会社",
      customerEmail: "test@example.com",
      customerAddress: "東京都渋谷区1-1-1",
      title: "Webサイト制作のお見積り",
      issueDate: new Date().toISOString(),
      expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      notes: "お支払いは銀行振込でお願いいたします",
      items: [
        {
          itemName: "Webサイト制作",
          description: "コーポレートサイト制作",
          quantity: 1,
          unitPrice: 500000,
        },
        {
          itemName: "保守運用（1年間）",
          description: "月次保守",
          quantity: 12,
          unitPrice: 10000,
        },
      ],
    });

    expect(result.id).toBeDefined();
    testQuotationId = result.id;
  });

  it("見積書一覧を取得できる", async () => {
    const quotations = await caller.quotationInvoice.getQuotations();
    expect(Array.isArray(quotations)).toBe(true);
    expect(quotations.length).toBeGreaterThan(0);
  });

  it("見積書詳細を取得できる", async () => {
    const detail = await caller.quotationInvoice.getQuotationDetail({
      id: testQuotationId,
    });

    expect(detail.quotation).toBeDefined();
    expect(detail.quotation.quotationNumber).toBe("Q-TEST-001");
    expect(detail.items).toBeDefined();
    expect(detail.items.length).toBe(2);
    expect(detail.quotation.totalAmount).toBe(682000); // (500000 + 120000) * 1.1 = 682000
  });

  it("見積書を更新できる", async () => {
    const result = await caller.quotationInvoice.updateQuotation({
      id: testQuotationId,
      status: "sent",
      notes: "更新されたメモ",
    });

    expect(result.success).toBe(true);

    const detail = await caller.quotationInvoice.getQuotationDetail({
      id: testQuotationId,
    });
    expect(detail.quotation.status).toBe("sent");
    expect(detail.quotation.notes).toBe("更新されたメモ");
  });

  it("見積書から請求書を作成できる", async () => {
    const result = await caller.quotationInvoice.createInvoiceFromQuotation({
      quotationId: testQuotationId,
      invoiceNumber: "INV-TEST-001",
      issueDate: new Date().toISOString(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      paymentMethod: "銀行振込",
      bankInfo: "○○銀行 ○○支店 普通 1234567",
    });

    expect(result.id).toBeDefined();
    testInvoiceId = result.id;
  });

  it("請求書一覧を取得できる", async () => {
    const invoices = await caller.quotationInvoice.getInvoices();
    expect(Array.isArray(invoices)).toBe(true);
    expect(invoices.length).toBeGreaterThan(0);
  });

  it("請求書詳細を取得できる", async () => {
    const detail = await caller.quotationInvoice.getInvoiceDetail({
      id: testInvoiceId,
    });

    expect(detail.invoice).toBeDefined();
    expect(detail.invoice.invoiceNumber).toBe("INV-TEST-001");
    expect(detail.invoice.quotationId).toBe(testQuotationId);
    expect(detail.items).toBeDefined();
    expect(detail.items.length).toBe(2);
    expect(detail.invoice.totalAmount).toBe(682000);
  });

  it("請求書を更新できる", async () => {
    const result = await caller.quotationInvoice.updateInvoice({
      id: testInvoiceId,
      status: "paid",
      paidAt: new Date().toISOString(),
    });

    expect(result.success).toBe(true);

    const detail = await caller.quotationInvoice.getInvoiceDetail({
      id: testInvoiceId,
    });
    expect(detail.invoice.status).toBe("paid");
    expect(detail.invoice.paidAt).toBeDefined();
  });

  it("請求書を直接作成できる", async () => {
    const result = await caller.quotationInvoice.createInvoice({
      invoiceNumber: `INV-TEST-${Date.now()}`,
      customerName: "テスト株式会社2",
      customerEmail: "test2@example.com",
      title: "コンサルティング費用のご請求",
      issueDate: new Date().toISOString(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      paymentMethod: "銀行振込",
      bankInfo: "○○銀行 ○○支店 普通 1234567",
      notes: "お支払いは銀行振込でお願いいたします",
      items: [
        {
          itemName: "コンサルティング",
          description: "経営戦略コンサルティング",
          quantity: 10,
          unitPrice: 50000,
        },
      ],
    });

    expect(result.id).toBeDefined();
  });

  it("請求書を削除できる", async () => {
    const result = await caller.quotationInvoice.deleteInvoice({
      id: testInvoiceId,
    });

    expect(result.success).toBe(true);

    // 削除後は取得できないことを確認
    await expect(
      caller.quotationInvoice.getInvoiceDetail({ id: testInvoiceId })
    ).rejects.toThrow();
  });

  it("見積書を削除できる", async () => {
    const result = await caller.quotationInvoice.deleteQuotation({
      id: testQuotationId,
    });

    expect(result.success).toBe(true);

    // 削除後は取得できないことを確認
    await expect(
      caller.quotationInvoice.getQuotationDetail({ id: testQuotationId })
    ).rejects.toThrow();
  });
});
