import { drizzle } from "drizzle-orm/mysql2";
import { systems } from "../drizzle/schema";

// データベース接続
const db = drizzle(process.env.DATABASE_URL!);

// 新しい20システムのデータ
const newSystems = [
  // カテゴリー1：営業・顧客管理（5システム）
  {
    id: 1,
    name: "顧客管理CRM",
    description: "顧客情報を一元管理。商談履歴、メモ、次回アクション日を記録。営業活動を効率化します。",
    category: "営業・顧客管理",
    icon: "👥",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 顧客情報を登録\n2. 商談履歴を記録\n3. 次回アクション日を設定\n4. ダッシュボードで進捗確認",
    updated_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: "営業メール自動生成",
    description: "顧客情報を入力すると、営業メールを自動生成。テンプレート選択可能で、営業担当の時間を大幅削減。",
    category: "営業・顧客管理",
    icon: "📧",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 顧客名と業種を入力\n2. メールの目的を選択\n3. AIが最適な営業メールを生成\n4. 編集してコピー",
    updated_at: new Date().toISOString(),
  },
  {
    id: 3,
    name: "見積書・請求書作成",
    description: "商品情報を入力するだけで、見積書・請求書をPDF生成。電子帳簿保存法にも対応。",
    category: "営業・顧客管理",
    icon: "📄",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 顧客情報を選択\n2. 商品・サービスを追加\n3. 金額を入力\n4. PDFダウンロード",
    updated_at: new Date().toISOString(),
  },
  {
    id: 4,
    name: "名刺管理システム",
    description: "名刺をスキャンして自動でデータ化。OCR技術で正確に情報を抽出し、顧客管理と連携。",
    category: "営業・顧客管理",
    icon: "🎴",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 名刺を撮影またはスキャン\n2. OCRで自動データ化\n3. 顧客情報に登録\n4. タグ付けで整理",
    updated_at: new Date().toISOString(),
  },
  {
    id: 5,
    name: "商談議事録AI",
    description: "音声を録音すると、自動で議事録を作成。要点を箇条書きで整理し、議事録作成時間を大幅削減。",
    category: "営業・顧客管理",
    icon: "🎙️",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 商談中に音声録音\n2. AIが自動で文字起こし\n3. 要点を箇条書きで整理\n4. 議事録をダウンロード",
    updated_at: new Date().toISOString(),
  },

  // カテゴリー2：マーケティング・SNS（4システム）
  {
    id: 6,
    name: "SNS投稿文自動生成",
    description: "商品情報を入力すると、Twitter/Instagram/Facebook用の投稿文を自動生成。ハッシュタグも提案。",
    category: "マーケティング・SNS",
    icon: "📱",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 商品名と特徴を入力\n2. SNSプラットフォームを選択\n3. AIが投稿文を生成\n4. コピーして投稿",
    updated_at: new Date().toISOString(),
  },
  {
    id: 7,
    name: "画像生成AI",
    description: "テキストから高品質な画像を生成。マーケティング素材の作成に最適。デザイナー費用を大幅削減。",
    category: "マーケティング・SNS",
    icon: "🎨",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 生成したい画像の説明を入力\n2. スタイルを選択\n3. AIが画像を生成\n4. ダウンロードして使用",
    updated_at: new Date().toISOString(),
  },
  {
    id: 8,
    name: "キャッチコピー生成AI",
    description: "商品名と特徴を入力すると、魅力的なキャッチコピーを10案生成。コピーライター費用を削減。",
    category: "マーケティング・SNS",
    icon: "💡",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 商品名を入力\n2. 特徴を3つ入力\n3. AIが10案生成\n4. 気に入ったものを選択",
    updated_at: new Date().toISOString(),
  },
  {
    id: 9,
    name: "SEO記事作成AI",
    description: "キーワードを入力すると、SEO最適化された記事を自動生成（2,000文字）。ライター費用を削減。",
    category: "マーケティング・SNS",
    icon: "📝",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. キーワードを入力\n2. 記事の構成を選択\n3. AIが記事を生成\n4. 編集してコピー",
    updated_at: new Date().toISOString(),
  },

  // カテゴリー3：業務管理・効率化（6システム）
  {
    id: 10,
    name: "勤怠管理システム",
    description: "従業員の出退勤を記録。シフト管理や残業時間の集計も自動化。労務管理を効率化します。",
    category: "業務管理・効率化",
    icon: "⏰",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 従業員を登録\n2. 出退勤を記録\n3. シフトを作成\n4. 勤怠レポートを出力",
    updated_at: new Date().toISOString(),
  },
  {
    id: 11,
    name: "経費精算システム",
    description: "レシート写真をアップロードすると、自動で金額と項目を読み取り、経費申請。経理担当の負担を軽減。",
    category: "業務管理・効率化",
    icon: "💰",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. レシートを撮影\n2. OCRで自動読み取り\n3. 経費項目を選択\n4. 申請ボタンをクリック",
    updated_at: new Date().toISOString(),
  },
  {
    id: 12,
    name: "在庫管理システム",
    description: "商品の入出庫を記録。在庫数をリアルタイムで確認。発注アラート機能付きで欠品を防止。",
    category: "業務管理・効率化",
    icon: "📦",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 商品を登録\n2. 入出庫を記録\n3. 在庫数を確認\n4. 発注アラートを設定",
    updated_at: new Date().toISOString(),
  },
  {
    id: 13,
    name: "タスク管理・プロジェクト管理",
    description: "チーム全体のタスクを可視化。ガントチャート、カンバンボード対応。プロジェクトの進捗を一目で把握。",
    category: "業務管理・効率化",
    icon: "📊",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. プロジェクトを作成\n2. タスクを追加\n3. 担当者を割り当て\n4. 進捗を更新",
    updated_at: new Date().toISOString(),
  },
  {
    id: 14,
    name: "契約書管理システム",
    description: "契約書をアップロードして一元管理。更新期限をアラート通知。契約書の紛失・更新忘れを防止。",
    category: "業務管理・効率化",
    icon: "📑",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 契約書をアップロード\n2. 契約情報を入力\n3. 更新期限を設定\n4. アラート通知を受け取る",
    updated_at: new Date().toISOString(),
  },
  {
    id: 15,
    name: "日報・週報自動生成",
    description: "今日やったことを箇条書きで入力すると、きれいな日報・週報を自動生成。報告書作成時間を削減。",
    category: "業務管理・効率化",
    icon: "📋",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 今日の業務を箇条書き\n2. 成果を入力\n3. AIが日報を生成\n4. 上司に提出",
    updated_at: new Date().toISOString(),
  },

  // カテゴリー4：AI自動化（5システム）
  {
    id: 16,
    name: "AIチャットボット（顧客対応）",
    description: "24時間365日顧客対応。FAQから複雑な質問まで自動応答。カスタマーサポート人件費を削減。",
    category: "AI自動化",
    icon: "🤖",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. FAQを登録\n2. チャットボットを設定\n3. Webサイトに埋め込み\n4. 自動応答を開始",
    updated_at: new Date().toISOString(),
  },
  {
    id: 17,
    name: "メール自動分類・要約AI",
    description: "受信メールを自動で分類（重要/普通/スパム）。長文メールを要約。メール処理時間を大幅削減。",
    category: "AI自動化",
    icon: "✉️",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. メールアカウントを連携\n2. 分類ルールを設定\n3. AIが自動分類\n4. 要約を確認",
    updated_at: new Date().toISOString(),
  },
  {
    id: 18,
    name: "データ入力自動化",
    description: "手書き文書やPDFをアップロードすると、Excelに自動入力。データ入力作業を大幅削減。",
    category: "AI自動化",
    icon: "⚙️",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 文書をアップロード\n2. OCRで自動読み取り\n3. Excelに変換\n4. ダウンロード",
    updated_at: new Date().toISOString(),
  },
  {
    id: 19,
    name: "翻訳AI（多言語対応）",
    description: "日本語⇔英語・中国語・韓国語の翻訳を瞬時に実行。ビジネス文書対応。翻訳費用を削減。",
    category: "AI自動化",
    icon: "🌐",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 翻訳したいテキストを入力\n2. 言語を選択\n3. AIが瞬時に翻訳\n4. コピーして使用",
    updated_at: new Date().toISOString(),
  },
  {
    id: 20,
    name: "プロンプト生成AI",
    description: "目的を入力すると、最適なAIプロンプトを自動生成。他のAIツールと併用可能。AI活用の効率を向上。",
    category: "AI自動化",
    icon: "🎯",
    screenshots: JSON.stringify([]),
    demo_video_url: null,
    tutorial: "1. 目的を入力\n2. AIがプロンプトを生成\n3. 他のAIツールで使用\n4. 結果を確認",
    updated_at: new Date().toISOString(),
  },
];

async function updateSystems() {
  console.log("🗑️  既存のシステムデータを削除中...");
  await db.delete(systems);

  console.log("📝 新しい20システムを登録中...");
  
  for (const system of newSystems) {
    await db.insert(systems).values({
      id: system.id,
      name: system.name,
      description: system.description,
      category: system.category,
      icon: system.icon,
      screenshots: system.screenshots,
      demo_video_url: system.demo_video_url,
      tutorial: system.tutorial,
      updated_at: system.updated_at,
    });
    console.log(`✅ ${system.name} を登録しました`);
  }

  console.log("\n✨ 新しい20システムの登録が完了しました！");
  console.log("\n📊 登録されたシステム一覧：");

  const allSystems = await db.select({ id: systems.id, name: systems.name, category: systems.category }).from(systems).orderBy(systems.id);
  console.table(allSystems);
  
  process.exit(0);
}

updateSystems().catch((error) => {
  console.error("❌ エラーが発生しました:", error);
  process.exit(1);
});
