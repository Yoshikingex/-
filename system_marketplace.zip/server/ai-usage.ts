import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { userAiUsage } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

/**
 * プラン別の使用制限
 */
const PLAN_LIMITS = {
  starter: {
    image: 100,
    video: 0,
    bgm: 0,
    prompt: 100,
  },
  business: {
    image: 500,
    video: 20,
    bgm: 20,
    prompt: 500,
  },
  enterprise: {
    image: 2000,
    video: 100,
    bgm: 100,
    prompt: 2000,
  },
};

/**
 * 現在の月を YYYY-MM 形式で取得
 */
function getCurrentMonth(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

/**
 * AI使用量管理ルーター
 */
export const aiUsageRouter = router({
  /**
   * 現在の使用状況を取得
   */
  getCurrentUsage: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

    const currentMonth = getCurrentMonth();

    // 現在の月の使用状況を取得
    const usage = await db
      .select()
      .from(userAiUsage)
      .where(and(eq(userAiUsage.userId, ctx.user.id), eq(userAiUsage.month, currentMonth)))
      .limit(1);

    if (usage.length === 0) {
      // レコードが存在しない場合は初期値を返す
      return {
        month: currentMonth,
        imageCount: 0,
        videoCount: 0,
        bgmCount: 0,
        promptCount: 0,
      };
    }

    return usage[0];
  }),

  /**
   * プラン別の使用制限を取得
   */
  getPlanLimits: protectedProcedure.query(async ({ ctx }) => {
    const plan = ctx.user.currentPlan || "starter";
    return PLAN_LIMITS[plan];
  }),

  /**
   * 使用回数をインクリメント
   */
  incrementUsage: protectedProcedure
    .input(
      z.object({
        type: z.enum(["image", "video", "bgm", "prompt"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const currentMonth = getCurrentMonth();
      const plan = ctx.user.currentPlan || "starter";
      const limits = PLAN_LIMITS[plan as keyof typeof PLAN_LIMITS];

      // 現在の使用状況を取得
      const usage = await db
        .select()
        .from(userAiUsage)
        .where(and(eq(userAiUsage.userId, ctx.user.id), eq(userAiUsage.month, currentMonth)))
        .limit(1);

      if (usage.length === 0) {
        // 新規レコードを作成
        await db.insert(userAiUsage).values({
          userId: ctx.user.id,
          month: currentMonth,
          imageCount: input.type === "image" ? 1 : 0,
          videoCount: input.type === "video" ? 1 : 0,
          bgmCount: input.type === "bgm" ? 1 : 0,
          promptCount: input.type === "prompt" ? 1 : 0,
        });
        return { success: true };
      }

      // 使用制限チェック
      const currentUsage = usage[0];
      if (input.type === "image" && currentUsage.imageCount >= limits.image) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月の画像生成回数上限（${limits.image}回）に達しました。`,
        });
      }
      if (input.type === "video" && currentUsage.videoCount >= limits.video) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月の動画生成回数上限（${limits.video}回）に達しました。`,
        });
      }
      if (input.type === "bgm" && currentUsage.bgmCount >= limits.bgm) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月のBGM生成回数上限（${limits.bgm}回）に達しました。`,
        });
      }
      if (input.type === "prompt" && currentUsage.promptCount >= limits.prompt) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月のプロンプト生成回数上限（${limits.prompt}回）に達しました。`,
        });
      }

      // 使用回数をインクリメント
      await db
        .update(userAiUsage)
        .set({
          imageCount: input.type === "image" ? currentUsage.imageCount + 1 : currentUsage.imageCount,
          videoCount: input.type === "video" ? currentUsage.videoCount + 1 : currentUsage.videoCount,
          bgmCount: input.type === "bgm" ? currentUsage.bgmCount + 1 : currentUsage.bgmCount,
          promptCount: input.type === "prompt" ? currentUsage.promptCount + 1 : currentUsage.promptCount,
        })
        .where(eq(userAiUsage.id, currentUsage.id));

      return { success: true };
    }),

  /**
   * 使用制限をチェック（インクリメントせずにチェックのみ）
   */
  checkLimit: protectedProcedure
    .input(
      z.object({
        type: z.enum(["image", "video", "bgm", "prompt"]),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const currentMonth = getCurrentMonth();
      const plan = ctx.user.currentPlan || "starter";
      const limits = PLAN_LIMITS[plan as keyof typeof PLAN_LIMITS];

      // 現在の使用状況を取得
      const usage = await db
        .select()
        .from(userAiUsage)
        .where(and(eq(userAiUsage.userId, ctx.user.id), eq(userAiUsage.month, currentMonth)))
        .limit(1);

      const currentUsage = usage.length > 0 ? usage[0] : {
        imageCount: 0,
        videoCount: 0,
        bgmCount: 0,
        promptCount: 0,
      };

      let currentCount = 0;
      let limit = 0;

      if (input.type === "image") {
        currentCount = currentUsage.imageCount;
        limit = limits.image;
      } else if (input.type === "video") {
        currentCount = currentUsage.videoCount;
        limit = limits.video;
      } else if (input.type === "bgm") {
        currentCount = currentUsage.bgmCount;
        limit = limits.bgm;
      } else if (input.type === "prompt") {
        currentCount = currentUsage.promptCount;
        limit = limits.prompt;
      }

      return {
        canUse: currentCount < limit,
        currentCount,
        limit,
        remaining: Math.max(0, limit - currentCount),
      };
    }),
});
