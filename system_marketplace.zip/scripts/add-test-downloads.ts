import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { downloadHistory, users, systems } from "../drizzle/schema";

async function addTestDownloads() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL!);
  const db = drizzle(connection);

  console.log("テストダウンロードデータを追加中...");

  // 全システムを取得
  const allSystems = await db.select().from(systems);
  console.log(`${allSystems.length}個のシステムが見つかりました`);

  // テストユーザーを作成または取得
  const testUsers = await db.select().from(users).limit(5);
  let userIds: number[] = [];

  if (testUsers.length === 0) {
    console.log("テストユーザーが見つかりません。スキップします。");
    await connection.end();
    return;
  }

  userIds = testUsers.map(u => u.id);
  console.log(`${userIds.length}人のユーザーが見つかりました`);

  // 各システムにランダムなダウンロード数を追加
  for (const system of allSystems) {
    const downloadCount = Math.floor(Math.random() * 50) + 1; // 1-50回のダウンロード
    
    for (let i = 0; i < downloadCount; i++) {
      const randomUserId = userIds[Math.floor(Math.random() * userIds.length)];
      await db.insert(downloadHistory).values({
        userId: randomUserId,
        systemId: system.id,
      });
    }

    console.log(`${system.name}: ${downloadCount}回のダウンロードを追加`);
  }

  console.log("テストデータの追加が完了しました！");
  await connection.end();
}

addTestDownloads().catch(console.error);
