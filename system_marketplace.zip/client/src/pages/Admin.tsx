import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { 
  Sparkles, 
  ArrowLeft,
  Users,
  DollarSign,
  TrendingUp,
  Package,
  Loader2,
} from "lucide-react";
import { useEffect } from "react";

export default function Admin() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  // 管理者権限チェック
  useEffect(() => {
    if (user && user.role !== 'admin') {
      setLocation('/dashboard');
    }
  }, [user, setLocation]);

  const { data: stats, isLoading: statsLoading } = trpc.admin.getStats.useQuery();
  const { data: allUsers, isLoading: usersLoading } = trpc.admin.getAllUsers.useQuery();
  const { data: allHistory, isLoading: historyLoading } = trpc.admin.getAllSubscriptionHistory.useQuery();

  const handleLogout = async () => {
    await logout();
    setLocation('/');
  };

  const isLoading = statsLoading || usersLoading || historyLoading;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">System Marketplace</span>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/systems">
              <Button variant="ghost">システム一覧</Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="outline">ダッシュボード</Button>
            </Link>
            <Link href="/admin/systems">
              <Button variant="outline">システム管理</Button>
            </Link>
            <Button variant="ghost" onClick={handleLogout}>
              ログアウト
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 py-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              管理者ダッシュボード
            </h1>
            <p className="text-xl text-muted-foreground">
              プラットフォーム全体の統計と管理
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-8">
              {/* Stats Overview */}
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        総ユーザー数
                      </CardTitle>
                      <Users className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">
                      {stats?.totalUsers || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        アクティブ契約
                      </CardTitle>
                      <TrendingUp className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">
                      {stats?.activeSubscriptions || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        総収益
                      </CardTitle>
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">
                      ¥{stats?.totalRevenue ? (stats.totalRevenue / 100).toLocaleString() : 0}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        プラン分布
                      </CardTitle>
                      <Package className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">スターター</span>
                        <span className="font-semibold text-foreground">{stats?.planCounts.starter || 0}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">ビジネス</span>
                        <span className="font-semibold text-foreground">{stats?.planCounts.business || 0}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">エンタープライズ</span>
                        <span className="font-semibold text-foreground">{stats?.planCounts.enterprise || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Users Table */}
              <Card>
                <CardHeader>
                  <CardTitle>ユーザー一覧</CardTitle>
                  <CardDescription>登録されているすべてのユーザー</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">名前</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">メール</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">プラン</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">ステータス</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">登録日</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allUsers && allUsers.length > 0 ? (
                          allUsers.map(user => (
                            <tr key={user.id} className="border-b hover:bg-muted/50">
                              <td className="py-3 px-4 text-sm text-foreground">
                                {user.name || '-'}
                                {user.role === 'admin' && (
                                  <Badge variant="secondary" className="ml-2">管理者</Badge>
                                )}
                              </td>
                              <td className="py-3 px-4 text-sm text-muted-foreground">{user.email || '-'}</td>
                              <td className="py-3 px-4 text-sm">
                                {user.currentPlan ? (
                                  <Badge variant="outline">
                                    {user.currentPlan === 'starter' ? 'スターター' :
                                     user.currentPlan === 'business' ? 'ビジネス' :
                                     user.currentPlan === 'enterprise' ? 'エンタープライズ' : user.currentPlan}
                                  </Badge>
                                ) : (
                                  <span className="text-muted-foreground">未登録</span>
                                )}
                              </td>
                              <td className="py-3 px-4 text-sm">
                                <Badge variant={user.subscriptionStatus === 'active' ? 'default' : 'secondary'}>
                                  {user.subscriptionStatus === 'active' ? 'アクティブ' :
                                   user.subscriptionStatus === 'canceled' ? 'キャンセル' :
                                   user.subscriptionStatus === 'past_due' ? '支払い遅延' : '未登録'}
                                </Badge>
                              </td>
                              <td className="py-3 px-4 text-sm text-muted-foreground">
                                {new Date(user.createdAt).toLocaleDateString('ja-JP')}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="py-8 text-center text-muted-foreground">
                              ユーザーがいません
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Transaction History */}
              <Card>
                <CardHeader>
                  <CardTitle>取引履歴</CardTitle>
                  <CardDescription>すべてのサブスクリプション取引</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">日時</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">ユーザーID</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">プラン</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">アクション</th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">金額</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allHistory && allHistory.length > 0 ? (
                          allHistory.slice(0, 20).map(item => (
                            <tr key={item.id} className="border-b hover:bg-muted/50">
                              <td className="py-3 px-4 text-sm text-muted-foreground">
                                {new Date(item.createdAt).toLocaleString('ja-JP')}
                              </td>
                              <td className="py-3 px-4 text-sm text-foreground">{item.userId}</td>
                              <td className="py-3 px-4 text-sm">
                                <Badge variant="outline">
                                  {item.planType === 'starter' ? 'スターター' :
                                   item.planType === 'business' ? 'ビジネス' :
                                   item.planType === 'enterprise' ? 'エンタープライズ' : item.planType}
                                </Badge>
                              </td>
                              <td className="py-3 px-4 text-sm">
                                <Badge variant="secondary">
                                  {item.action === 'created' ? '新規登録' :
                                   item.action === 'renewed' ? '更新' :
                                   item.action === 'upgraded' ? 'アップグレード' :
                                   item.action === 'downgraded' ? 'ダウングレード' : 'キャンセル'}
                                </Badge>
                              </td>
                              <td className="py-3 px-4 text-sm text-right font-semibold text-foreground">
                                {item.amount ? `¥${(item.amount / 100).toLocaleString()}` : '-'}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="py-8 text-center text-muted-foreground">
                              取引履歴がありません
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
