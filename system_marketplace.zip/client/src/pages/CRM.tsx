import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { SystemHeader } from "@/components/SystemHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Building2,
  Mail,
  Phone,
  MapPin,
  Edit,
  Trash2,
  Users,
  TrendingUp,
  UserCheck,
  UserX,
} from "lucide-react";

type CustomerStatus = "lead" | "prospect" | "customer" | "inactive";

export default function CRM() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<CustomerStatus | "all">("all");

  // フォーム状態
  const [formData, setFormData] = useState({
    contactName: "",
    companyName: "",
    email: "",
    phone: "",
    postalCode: "",
    address: "",
    status: "lead" as CustomerStatus,
    tags: "",
    notes: "",
  });

  // tRPC queries and mutations
  const { data: customers, isLoading } = trpc.crm.getCustomers.useQuery({
    search: searchQuery,
    status: statusFilter === "all" ? undefined : statusFilter,
  });

  const createMutation = trpc.crm.createCustomer.useMutation({
    onSuccess: () => {
      toast.success("顧客を登録しました");
      setIsCreateDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const updateMutation = trpc.crm.updateCustomer.useMutation({
    onSuccess: () => {
      toast.success("顧客情報を更新しました");
      setIsEditDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const deleteMutation = trpc.crm.deleteCustomer.useMutation({
    onSuccess: () => {
      toast.success("顧客を削除しました");
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      contactName: "",
      companyName: "",
      email: "",
      phone: "",
      postalCode: "",
      address: "",
      status: "lead",
      tags: "",
      notes: "",
    });
    setSelectedCustomer(null);
  };

  const handleCreate = () => {
    createMutation.mutate(formData);
  };

  const handleUpdate = () => {
    if (!selectedCustomer) return;
    updateMutation.mutate({ id: selectedCustomer.id, ...formData });
  };

  const handleDelete = (id: number) => {
    if (confirm("本当にこの顧客を削除しますか？")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (customer: any) => {
    setSelectedCustomer(customer);
    setFormData({
      companyName: customer.companyName || "",
      contactName: customer.contactName,
      email: customer.email || "",
      phone: customer.phone || "",
      postalCode: customer.postalCode || "",
      address: customer.address || "",
      status: customer.status,
      tags: customer.tags || "",
      notes: customer.notes || "",
    });
    setIsEditDialogOpen(true);
  };

  const getStatusBadge = (status: CustomerStatus) => {
    const variants = {
      lead: { label: "見込み客", className: "bg-blue-500" },
      prospect: { label: "商談中", className: "bg-yellow-500" },
      customer: { label: "顧客", className: "bg-green-500" },
      inactive: { label: "休眠", className: "bg-gray-500" },
    };
    const { label, className } = variants[status];
    return <Badge className={className}>{label}</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      <SystemHeader />

      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* ページタイトル */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">顧客管理CRM</h1>
              <p className="text-muted-foreground mt-1">顧客情報を一元管理</p>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={resetForm}>
                  <Plus className="w-4 h-4 mr-2" />
                  新規顧客
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>新規顧客登録</DialogTitle>
                </DialogHeader>
                <CustomerForm formData={formData} setFormData={setFormData} onSubmit={handleCreate} />
              </DialogContent>
            </Dialog>
          </div>

          {/* 統計カード */}
          <div className="grid md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">総顧客数</CardTitle>
                <Users className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{customers?.length || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">見込み客</CardTitle>
                <TrendingUp className="w-4 h-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {customers?.filter((c) => c.status === "lead").length || 0}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">商談中</CardTitle>
                <UserCheck className="w-4 h-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {customers?.filter((c) => c.status === "prospect").length || 0}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">顧客</CardTitle>
                <UserCheck className="w-4 h-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {customers?.filter((c) => c.status === "customer").length || 0}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 検索・フィルター */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="顧客名、会社名で検索..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全てのステータス</SelectItem>
                    <SelectItem value="lead">見込み客</SelectItem>
                    <SelectItem value="prospect">商談中</SelectItem>
                    <SelectItem value="customer">顧客</SelectItem>
                    <SelectItem value="inactive">休眠</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* 顧客リスト */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {customers && customers.length > 0 ? (
              customers.map((customer) => (
                <Card key={customer.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                          <Building2 className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{customer.contactName}</CardTitle>
                          {customer.companyName && (
                            <p className="text-sm text-muted-foreground">{customer.companyName}</p>
                          )}
                        </div>
                      </div>
                      {getStatusBadge(customer.status)}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {customer.email && (
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="w-4 h-4 text-muted-foreground" />
                        <span className="truncate">{customer.email}</span>
                      </div>
                    )}
                    {customer.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                        <span>{customer.phone}</span>
                      </div>
                    )}
                    {customer.address && (
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span className="truncate">{customer.address}</span>
                      </div>
                    )}
                    {customer.tags && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {customer.tags.split(",").map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag.trim()}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <div className="flex gap-2 pt-4">
                      <Button variant="outline" size="sm" className="flex-1" onClick={() => handleEdit(customer)}>
                        <Edit className="w-4 h-4 mr-1" />
                        編集
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => handleDelete(customer.id)}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        削除
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="col-span-full">
                <CardContent className="py-12 text-center text-muted-foreground">
                  顧客が登録されていません。「新規顧客」ボタンから登録してください。
                </CardContent>
              </Card>
            )}
          </div>

          {/* 編集ダイアログ */}
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>顧客情報編集</DialogTitle>
              </DialogHeader>
              <CustomerForm formData={formData} setFormData={setFormData} onSubmit={handleUpdate} />
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}

// 顧客フォームコンポーネント
function CustomerForm({
  formData,
  setFormData,
  onSubmit,
}: {
  formData: any;
  setFormData: (data: any) => void;
  onSubmit: () => void;
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="contactName">担当者名 *</Label>
          <Input
            id="contactName"
            value={formData.contactName}
            onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
            placeholder="山田太郎"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="companyName">会社名</Label>
          <Input
            id="companyName"
            value={formData.companyName}
            onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            placeholder="株式会社サンプル"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email">メールアドレス</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="example@company.com"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">電話番号</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="03-1234-5678"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="postalCode">郵便番号</Label>
          <Input
            id="postalCode"
            value={formData.postalCode}
            onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
            placeholder="100-0001"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="status">ステータス</Label>
          <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="lead">見込み客</SelectItem>
              <SelectItem value="prospect">商談中</SelectItem>
              <SelectItem value="customer">顧客</SelectItem>
              <SelectItem value="inactive">休眠</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">住所</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="東京都千代田区..."
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">タグ（カンマ区切り）</Label>
        <Input
          id="tags"
          value={formData.tags}
          onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
          placeholder="VIP, IT業界, 大企業"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">メモ</Label>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="顧客に関するメモ..."
          rows={4}
        />
      </div>

      <Button onClick={onSubmit} className="w-full">
        保存
      </Button>
    </div>
  );
}
