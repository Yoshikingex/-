import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { SystemHeader } from "@/components/SystemHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, Mail, Send, History, FileText } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SalesEmail() {
  return (
    <div className="min-h-screen bg-background">
      <SystemHeader />
      <div className="p-6">
        <SalesEmailContent />
      </div>
    </div>
  );
}

function SalesEmailContent() {
  const [category, setCategory] = useState("初回営業");
  const [companyName, setCompanyName] = useState("");
  const [contactName, setContactName] = useState("");
  const [productService, setProductService] = useState("");
  const [additionalInfo, setAdditionalInfo] = useState("");
  const [generatedSubject, setGeneratedSubject] = useState("");
  const [generatedBody, setGeneratedBody] = useState("");
  const [recipient, setRecipient] = useState("");

  const generateMutation = trpc.salesEmail.generateEmail.useMutation({
    onSuccess: (data) => {
      setGeneratedSubject(data.subject);
      setGeneratedBody(data.body);
      toast("メールを生成しました");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const saveMutation = trpc.salesEmail.saveEmail.useMutation({
    onSuccess: () => {
      toast("メールを保存しました");
      historyRefetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const { data: history, refetch: historyRefetch } = trpc.salesEmail.getHistory.useQuery({});

  const handleGenerate = () => {
    if (!contactName && !companyName) {
      toast.error("会社名または担当者名を入力してください");
      return;
    }

    generateMutation.mutate({
      category,
      companyName,
      contactName,
      productService,
      additionalInfo,
    });
  };

  const handleSave = (status: "draft" | "sent") => {
    if (!generatedSubject || !generatedBody) {
      toast.error("メールを生成してください");
      return;
    }

    if (!recipient) {
      toast.error("送信先メールアドレスを入力してください");
      return;
    }

    saveMutation.mutate({
      subject: generatedSubject,
      body: generatedBody,
      recipient,
      status,
    });
  };

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">営業メール自動生成</h1>
        <p className="text-muted-foreground">
          AIが顧客情報をもとに効果的な営業メールを自動生成します
        </p>
      </div>

      <Tabs defaultValue="generate" className="space-y-6">
        <TabsList>
          <TabsTrigger value="generate">
            <Mail className="w-4 h-4 mr-2" />
            メール生成
          </TabsTrigger>
          <TabsTrigger value="history">
            <History className="w-4 h-4 mr-2" />
            送信履歴
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 入力フォーム */}
            <Card>
              <CardHeader>
                <CardTitle>顧客情報入力</CardTitle>
                <CardDescription>
                  営業メールを生成するための情報を入力してください
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">メールの種類</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="初回営業">初回営業</SelectItem>
                      <SelectItem value="フォローアップ">フォローアップ</SelectItem>
                      <SelectItem value="お礼">お礼</SelectItem>
                      <SelectItem value="提案">提案</SelectItem>
                      <SelectItem value="アポイント依頼">アポイント依頼</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyName">会社名</Label>
                  <Input
                    id="companyName"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="例: 株式会社サンプル"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactName">担当者名</Label>
                  <Input
                    id="contactName"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="例: 山田太郎"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="productService">商品・サービス</Label>
                  <Input
                    id="productService"
                    value={productService}
                    onChange={(e) => setProductService(e.target.value)}
                    placeholder="例: 業務効率化システム"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="additionalInfo">追加情報</Label>
                  <Textarea
                    id="additionalInfo"
                    value={additionalInfo}
                    onChange={(e) => setAdditionalInfo(e.target.value)}
                    placeholder="特記事項があれば入力してください"
                    rows={4}
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending}
                  className="w-full"
                >
                  {generateMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      生成中...
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4 mr-2" />
                      メールを生成
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* 生成結果 */}
            <Card>
              <CardHeader>
                <CardTitle>生成されたメール</CardTitle>
                <CardDescription>
                  生成されたメールを確認・編集できます
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="recipient">送信先メールアドレス</Label>
                  <Input
                    id="recipient"
                    type="email"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder="example@company.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">件名</Label>
                  <Input
                    id="subject"
                    value={generatedSubject}
                    onChange={(e) => setGeneratedSubject(e.target.value)}
                    placeholder="件名が表示されます"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="body">本文</Label>
                  <Textarea
                    id="body"
                    value={generatedBody}
                    onChange={(e) => setGeneratedBody(e.target.value)}
                    placeholder="本文が表示されます"
                    rows={15}
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleSave("draft")}
                    disabled={saveMutation.isPending}
                    variant="outline"
                    className="flex-1"
                  >
                    下書き保存
                  </Button>
                  <Button
                    onClick={() => handleSave("sent")}
                    disabled={saveMutation.isPending}
                    className="flex-1"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    送信済みとして保存
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>送信履歴</CardTitle>
              <CardDescription>
                過去に生成・送信したメールの履歴
              </CardDescription>
            </CardHeader>
            <CardContent>
              {history && history.length > 0 ? (
                <div className="space-y-4">
                  {history.map((item) => (
                    <Card key={item.id}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{item.subject}</CardTitle>
                            <CardDescription>
                              送信先: {item.recipient} | ステータス: {item.status === "sent" ? "送信済み" : "下書き"}
                            </CardDescription>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {new Date(item.createdAt).toLocaleDateString("ja-JP")}
                          </span>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                          {item.body.substring(0, 200)}
                          {item.body.length > 200 && "..."}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  まだ送信履歴がありません
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
