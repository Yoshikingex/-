import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { systems, downloadHistory, userSystems } from "../drizzle/schema";
import { sql, desc, count, eq } from "drizzle-orm";

export const rankingRouter = router({
  /**
   * 人気ランキングを取得（ダウンロード数順）
   */
  getPopularSystems: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(20).default(10),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const limit = input?.limit || 10;

      // ダウンロード数でランキング
      const ranking = await db
        .select({
          system: systems,
          downloadCount: count(downloadHistory.id),
        })
        .from(systems)
        .leftJoin(downloadHistory, sql`${systems.id} = ${downloadHistory.systemId}`)
        .groupBy(systems.id)
        .orderBy(desc(count(downloadHistory.id)))
        .limit(limit);

      return ranking.map((item, index) => ({
        rank: index + 1,
        system: item.system,
        downloadCount: item.downloadCount,
      }));
    }),

  /**
   * 利用者数ランキングを取得
   */
  getMostUsedSystems: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(20).default(10),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const limit = input?.limit || 10;

      // 利用者数でランキング
      const ranking = await db
        .select({
          system: systems,
          userCount: count(userSystems.id),
        })
        .from(systems)
        .leftJoin(userSystems, sql`${systems.id} = ${userSystems.systemId}`)
        .groupBy(systems.id)
        .orderBy(desc(count(userSystems.id)))
        .limit(limit);

      return ranking.map((item, index) => ({
        rank: index + 1,
        system: item.system,
        userCount: item.userCount,
      }));
    }),

  /**
   * カテゴリー別ランキングを取得
   */
  getCategoryRankings: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) {
      throw new Error("データベースに接続できません");
    }

    // 全カテゴリーを取得
    const categories = [
      "営業・顧客管理",
      "マーケティング・SNS",
      "業務管理・効率化",
      "AI自動化",
    ];

    const categoryRankings = await Promise.all(
      categories.map(async (category) => {
        const ranking = await db
          .select({
            system: systems,
            downloadCount: count(downloadHistory.id),
          })
          .from(systems)
          .leftJoin(downloadHistory, sql`${systems.id} = ${downloadHistory.systemId}`)
          .where(eq(systems.category, category))
          .groupBy(systems.id)
          .orderBy(desc(count(downloadHistory.id)))
          .limit(5);

        return {
          category,
          systems: ranking.map((item, index) => ({
            rank: index + 1,
            system: item.system,
            downloadCount: item.downloadCount,
          })),
        };
      })
    );

    return categoryRankings;
  }),

  /**
   * ダウンロード履歴を記録
   */
  recordDownload: protectedProcedure
    .input(
      z.object({
        systemId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      await db.insert(downloadHistory).values({
        userId: ctx.user.id,
        systemId: input.systemId,
      });

      return { success: true };
    }),

  /**
   * システムごとの統計情報を取得
   */
  getSystemStats: publicProcedure
    .input(
      z.object({
        systemId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // ダウンロード数
      const downloadCountResult = await db
        .select({ count: count() })
        .from(downloadHistory)
        .where(sql`${downloadHistory.systemId} = ${input.systemId}`);

      // 利用者数
      const userCountResult = await db
        .select({ count: count() })
        .from(userSystems)
        .where(sql`${userSystems.systemId} = ${input.systemId}`);

      return {
        downloadCount: downloadCountResult[0]?.count || 0,
        userCount: userCountResult[0]?.count || 0,
      };
    }),

  /**
   * 全体統計情報を取得
   */
  getOverallStats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) {
      throw new Error("データベースに接続できません");
    }

    // 総ダウンロード数
    const totalDownloadsResult = await db
      .select({ count: count() })
      .from(downloadHistory);

    // 総システム数
    const totalSystemsResult = await db
      .select({ count: count() })
      .from(systems);

    // アクティブシステム数
    const activeSystemsResult = await db
      .select({ count: count() })
      .from(systems)
      .where(sql`${systems.isActive} = true`);

    return {
      totalDownloads: totalDownloadsResult[0]?.count || 0,
      totalSystems: totalSystemsResult[0]?.count || 0,
      activeSystems: activeSystemsResult[0]?.count || 0,
    };
  }),
});
