import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { SystemHeader } from "@/components/SystemHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Upload, FileArchive, Loader2, FileText } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

const CATEGORIES = [
  { value: "ai", label: "AI" },
  { value: "management", label: "業務管理" },
  { value: "automation", label: "自動化" },
  { value: "marketing", label: "マーケティング" },
];

const ICONS = ["Sparkles", "Users", "FileText", "Calendar", "ShoppingCart", "BarChart", "Zap", "MessageSquare"];
const COLORS = ["from-blue-500 to-cyan-500", "from-purple-500 to-pink-500", "from-green-500 to-emerald-500", "from-orange-500 to-red-500"];

export default function AdminSystems() {
  return (
    <div className="min-h-screen bg-background">
      <SystemHeader />
      <div className="p-6">
        <AdminSystemsContent />
      </div>
    </div>
  );
}

function AdminSystemsContent() {
  const [, setLocation] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingSystem, setEditingSystem] = useState<any>(null);
  const [uploadingSystemId, setUploadingSystemId] = useState<number | null>(null);

  // フォーム状態
  const [formData, setFormData] = useState({
    systemId: "",
    name: "",
    nameEn: "",
    description: "",
    category: "ai" as "ai" | "management" | "automation" | "marketing",
    icon: "Sparkles",
    color: "from-blue-500 to-cyan-500",
    screenshots: "" as string,
    demoVideoUrl: "",
    tutorial: "",
    features: "" as string,
  });

  const { data: systems, isLoading, refetch } = trpc.systemManagement.listAll.useQuery();
  const createMutation = trpc.systemManagement.create.useMutation();
  const updateMutation = trpc.systemManagement.update.useMutation();
  const deleteMutation = trpc.systemManagement.delete.useMutation();
  const uploadFileMutation = trpc.systemManagement.uploadFile.useMutation();
  const deleteFileMutation = trpc.systemManagement.deleteFile.useMutation();
  const generatePDFMutation = trpc.pdfGenerator.generateSystemPDF.useMutation();

  // 権限チェック
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    setLocation("/");
    return null;
  }

  const handleCreate = async () => {
    try {
      await createMutation.mutateAsync(formData);
      toast.success("システムを追加しました");
      setIsAddDialogOpen(false);
      setFormData({
        systemId: "",
        name: "",
        nameEn: "",
        description: "",
        category: "ai",
        icon: "Sparkles",
        color: "from-blue-500 to-cyan-500",
        screenshots: "",
        demoVideoUrl: "",
        tutorial: "",
        features: "",
      });
      refetch();
    } catch (error: any) {
      toast.error(error.message || "システムの追加に失敗しました");
    }
  };

  const handleUpdate = async () => {
    try {
      // スクリーンショットとfeaturesをJSON配列に変換
      const screenshotsArray = formData.screenshots
        ? formData.screenshots.split(',').map(s => s.trim()).filter(s => s)
        : [];
      const featuresArray = formData.features
        ? formData.features.split(',').map(f => f.trim()).filter(f => f)
        : [];

      await updateMutation.mutateAsync({
        id: editingSystem.id,
        ...formData,
        screenshots: screenshotsArray.length > 0 ? JSON.stringify(screenshotsArray) : undefined,
        features: featuresArray.length > 0 ? JSON.stringify(featuresArray) : undefined,
      });
      toast.success("システムを更新しました");
      setIsEditDialogOpen(false);
      setEditingSystem(null);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "システムの更新に失敗しました");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("本当に削除しますか？")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("システムを削除しました");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "システムの削除に失敗しました");
    }
  };

  const handleFileUpload = async (systemId: number, file: File) => {
    if (file.size > 100 * 1024 * 1024) {
      toast.error("ファイルサイズが大きすぎます（最大100MB）");
      return;
    }

    if (!file.name.endsWith(".zip")) {
      toast.error("ZIPファイルのみアップロード可能です");
      return;
    }

    setUploadingSystemId(systemId);

    try {
      // ファイルをBase64に変換
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64Data = e.target?.result as string;
        const base64Content = base64Data.split(",")[1];

        await uploadFileMutation.mutateAsync({
          systemId,
          fileName: file.name,
          fileData: base64Content,
          fileType: file.type,
          fileSize: file.size,
        });

        toast.success("ファイルをアップロードしました");
        refetch();
        setUploadingSystemId(null);
      };
      reader.readAsDataURL(file);
    } catch (error: any) {
      toast.error(error.message || "ファイルのアップロードに失敗しました");
      setUploadingSystemId(null);
    }
  };

  const handleGeneratePDF = async (systemId: number) => {
    try {
      const result = await generatePDFMutation.mutateAsync({ systemId });
      
      // Base64をBlobに変換
      const byteCharacters = atob(result.pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      // ダウンロード
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = result.fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast.success("PDF資料を生成しました");
    } catch (error: any) {
      toast.error(error.message || "PDF生成に失敗しました");
    }
  };

  const handleDeleteFile = async (systemId: number) => {
    if (!confirm("ファイルを削除しますか？")) return;
    try {
      await deleteFileMutation.mutateAsync({ systemId });
      toast.success("ファイルを削除しました");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "ファイルの削除に失敗しました");
    }
  };

  const openEditDialog = (system: any) => {
    setEditingSystem(system);
        setFormData({
          systemId: system.systemId,
          name: system.name,
          nameEn: system.nameEn,
          description: system.description,
          category: system.category,
          icon: system.icon,
          color: system.color,
          screenshots: system.screenshots || "",
          demoVideoUrl: system.demoVideoUrl || "",
          tutorial: system.tutorial || "",
          features: system.features || "",
        });
    setIsEditDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">システム管理</h1>
          <p className="text-muted-foreground mt-2">システムの追加・編集・削除を行います</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="w-5 h-5 mr-2" />
              システムを追加
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>新しいシステムを追加</DialogTitle>
              <DialogDescription>システムの情報を入力してください</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="systemId">システムID</Label>
                  <Input
                    id="systemId"
                    value={formData.systemId}
                    onChange={(e) => setFormData({ ...formData, systemId: e.target.value })}
                    placeholder="bgm-generator"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">カテゴリー</Label>
                  <Select value={formData.category} onValueChange={(value: any) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">システム名（日本語）</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="BGM生成AI"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nameEn">システム名（英語）</Label>
                  <Input
                    id="nameEn"
                    value={formData.nameEn}
                    onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                    placeholder="BGM Generator"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">説明</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="AIが自動でBGMを生成します"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="icon">アイコン</Label>
                  <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ICONS.map((icon) => (
                        <SelectItem key={icon} value={icon}>
                          {icon}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="color">カラー</Label>
                  <Select value={formData.color} onValueChange={(value) => setFormData({ ...formData, color: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {COLORS.map((color) => (
                        <SelectItem key={color} value={color}>
                          {color}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                キャンセル
              </Button>
              <Button onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                追加
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {systems?.map((system) => (
          <Card key={system.id}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{system.name}</span>
                <div className="flex gap-2">
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={() => handleGeneratePDF(system.id)}
                    title="営業用PDF資料を生成"
                  >
                    <FileText className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => openEditDialog(system)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(system.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardTitle>
              <CardDescription>{system.nameEn}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{system.description}</p>
              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-medium">カテゴリー:</span> {system.category}
                </div>
              </div>
              <div className="mt-4 pt-4 border-t">
                {system.fileUrl ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      <FileArchive className="w-4 h-4" />
                      <span className="truncate max-w-[150px]">{system.fileName}</span>
                    </div>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteFile(system.id)}>
                      削除
                    </Button>
                  </div>
                ) : (
                  <div>
                    <Label htmlFor={`file-${system.id}`} className="cursor-pointer">
                      <div className="flex items-center gap-2 p-2 border rounded-md hover:bg-accent">
                        {uploadingSystemId === system.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Upload className="w-4 h-4" />
                        )}
                        <span className="text-sm">ZIPファイルをアップロード</span>
                      </div>
                    </Label>
                    <Input
                      id={`file-${system.id}`}
                      type="file"
                      accept=".zip"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(system.id, file);
                      }}
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 編集ダイアログ */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>システムを編集</DialogTitle>
            <DialogDescription>システムの情報を編集してください</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-systemId">システムID</Label>
                <Input
                  id="edit-systemId"
                  value={formData.systemId}
                  onChange={(e) => setFormData({ ...formData, systemId: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-category">カテゴリー</Label>
                <Select value={formData.category} onValueChange={(value: any) => setFormData({ ...formData, category: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">システム名（日本語）</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-nameEn">システム名（英語）</Label>
                <Input
                  id="edit-nameEn"
                  value={formData.nameEn}
                  onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">説明</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-icon">アイコン</Label>
                <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ICONS.map((icon) => (
                      <SelectItem key={icon} value={icon}>
                        {icon}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-color">カラー</Label>
                <Select value={formData.color} onValueChange={(value) => setFormData({ ...formData, color: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COLORS.map((color) => (
                      <SelectItem key={color} value={color}>
                        {color}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-screenshots">スクリーンショットURL（カンマ区切り）</Label>
              <Textarea
                id="edit-screenshots"
                value={formData.screenshots}
                onChange={(e) => setFormData({ ...formData, screenshots: e.target.value })}
                placeholder="https://example.com/screenshot1.png, https://example.com/screenshot2.png"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-demoVideoUrl">デモ動画URL（YouTube埋め込みURL）</Label>
              <Input
                id="edit-demoVideoUrl"
                value={formData.demoVideoUrl}
                onChange={(e) => setFormData({ ...formData, demoVideoUrl: e.target.value })}
                placeholder="https://www.youtube.com/embed/VIDEO_ID"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-tutorial">利用チュートリアル（Markdown形式）</Label>
              <Textarea
                id="edit-tutorial"
                value={formData.tutorial}
                onChange={(e) => setFormData({ ...formData, tutorial: e.target.value })}
                placeholder="## 使い方\n1. ステップ1\n2. ステップ2"
                rows={5}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-features">主な機能（カンマ区切り）</Label>
              <Textarea
                id="edit-features"
                value={formData.features}
                onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                placeholder="機能1, 機能2, 機能3"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              キャンセル
            </Button>
            <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
              {updateMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              更新
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
