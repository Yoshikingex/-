import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";
import { TRPCError } from "@trpc/server";
import { aiUsageRouter } from "./ai-usage";

export const aiSystemsRouter = router({
  generateImage: protectedProcedure
    .input(z.object({ prompt: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // 使用量制限チェック
      const caller = aiUsageRouter.createCaller({ user: ctx.user, req: ctx.req, res: ctx.res });
      const limitCheck = await caller.checkLimit({ type: "image" });
      if (!limitCheck.canUse) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月の画像生成回数上限（${limitCheck.limit}回）に達しました。`,
        });
      }

      const { url } = await generateImage({ prompt: input.prompt });
      
      // 使用回数をインクリメント
      await caller.incrementUsage({ type: "image" });
      
      return { imageUrl: url };
    }),

  generatePrompt: protectedProcedure
    .input(z.object({ topic: z.string() }))
    .mutation(async ({ ctx, input }) => {
      // 使用量制限チェック
      const caller = aiUsageRouter.createCaller({ user: ctx.user, req: ctx.req, res: ctx.res });
      const limitCheck = await caller.checkLimit({ type: "prompt" });
      if (!limitCheck.canUse) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `今月のプロンプト生成回数上限（${limitCheck.limit}回）に達しました。`,
        });
      }

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content:
              "あなたはプロフェッショナルなプロンプトエンジニアです。ユーザーが提供するトピックに基づいて、詳細で効果的なプロンプトを生成してください。",
          },
          {
            role: "user",
            content: `以下のトピックについて、詳細で効果的なプロンプトを生成してください：\n\n${input.topic}`,
          },
        ],
      });

      const content = response.choices[0]?.message?.content;
      const prompt = typeof content === 'string' ? content : '';
      
      // 使用回数をインクリメント
      await caller.incrementUsage({ type: "prompt" });
      
      return { prompt };
    }),

  // 動画生成AI（Runway Gen-3 API統合予定）
  generateVideo: protectedProcedure
    .input(z.object({ prompt: z.string() }))
    .mutation(async ({ input }) => {
      // TODO: Runway Gen-3 API統合
      throw new Error("動画生成機能は準備中です。Runway APIキーを設定してください。");
    }),

  // BGM生成AI（Mubert API統合予定）
  generateBGM: protectedProcedure
    .input(z.object({ prompt: z.string(), duration: z.number().optional() }))
    .mutation(async ({ input }) => {
      // TODO: Mubert API統合
      throw new Error("BGM生成機能は準備中です。Mubert APIキーを設定してください。");
    }),
});
