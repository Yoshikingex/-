export type SystemCategory = 'ai' | 'management' | 'automation' | 'marketing';

export interface System {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  category: SystemCategory;
  features: string[];
  icon: string;
  color: string;
}

export const SYSTEMS: System[] = [
  {
    id: 'bgm-ai',
    name: 'BGM生成AI',
    nameEn: 'BGM Generation AI',
    description: 'AIが自動で店舗やオフィスに最適なBGMを生成します。シーンや時間帯に応じた音楽を提供。',
    category: 'ai',
    features: ['シーン別BGM生成', '時間帯自動調整', '著作権フリー', 'ダウンロード可能'],
    icon: 'Music',
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 'customer-management',
    name: '顧客管理システム',
    nameEn: 'Customer Management',
    description: '顧客情報を一元管理し、営業活動を効率化。履歴管理やセグメント分析機能を搭載。',
    category: 'management',
    features: ['顧客情報管理', '商談履歴記録', 'セグメント分析', 'CSV一括登録'],
    icon: 'Users',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'attendance-management',
    name: '勤務管理システム',
    nameEn: 'Attendance Management',
    description: '従業員の出退勤を自動記録。シフト管理や残業時間の集計も簡単に。',
    category: 'management',
    features: ['打刻機能', 'シフト管理', '残業時間集計', '給与計算連携'],
    icon: 'Clock',
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 'business-card-management',
    name: '名刺管理システム',
    nameEn: 'Business Card Management',
    description: '名刺をスキャンして自動でデータ化。OCR技術で正確に情報を抽出します。',
    category: 'management',
    features: ['OCR自動読取', 'クラウド保存', '検索機能', 'CRM連携'],
    icon: 'CreditCard',
    color: 'from-orange-500 to-red-500',
  },
  {
    id: 'ordering-system',
    name: '発注システム',
    nameEn: 'Ordering System',
    description: '在庫状況に応じて自動発注。サプライヤーとの連携もスムーズに。',
    category: 'management',
    features: ['自動発注', '在庫連動', '発注履歴管理', 'サプライヤー管理'],
    icon: 'ShoppingCart',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    id: 'reservation-integration',
    name: '予約統合システム',
    nameEn: 'Reservation Integration',
    description: '複数の予約チャネルを一元管理。ダブルブッキングを防止します。',
    category: 'management',
    features: ['マルチチャネル対応', 'カレンダー同期', '自動リマインド', '予約分析'],
    icon: 'Calendar',
    color: 'from-teal-500 to-green-500',
  },
  {
    id: 'prompt-ai',
    name: 'プロンプト生成AI',
    nameEn: 'Prompt Generation AI',
    description: '目的に応じた最適なAIプロンプトを自動生成。業務効率を大幅に向上。',
    category: 'ai',
    features: ['用途別テンプレート', 'プロンプト最適化', '履歴保存', 'チーム共有'],
    icon: 'MessageSquare',
    color: 'from-violet-500 to-purple-500',
  },
  {
    id: 'image-ai',
    name: '画像生成AI',
    nameEn: 'Image Generation AI',
    description: 'テキストから高品質な画像を生成。マーケティング素材の作成に最適。',
    category: 'ai',
    features: ['テキストから画像生成', '複数スタイル対応', '高解像度出力', '商用利用可'],
    icon: 'Image',
    color: 'from-pink-500 to-rose-500',
  },
  {
    id: 'short-video-ai',
    name: 'ショート動画生成AI',
    nameEn: 'Short Video AI',
    description: 'SNS向けショート動画を自動生成。テンプレートから簡単に作成可能。',
    category: 'ai',
    features: ['自動編集', 'BGM自動選択', '字幕生成', 'SNS最適化'],
    icon: 'Video',
    color: 'from-red-500 to-orange-500',
  },
  {
    id: 'sns-auto-post',
    name: 'SNS自動投稿システム',
    nameEn: 'SNS Auto Post',
    description: '複数のSNSに予約投稿。最適な時間帯を分析して自動投稿します。',
    category: 'marketing',
    features: ['マルチSNS対応', '予約投稿', '最適時間分析', '効果測定'],
    icon: 'Share2',
    color: 'from-blue-500 to-indigo-500',
  },
  {
    id: 'affiliate-auto',
    name: 'アフィリエイト自動システム',
    nameEn: 'Affiliate Automation',
    description: 'アフィリエイトリンクの管理と成果を自動追跡。収益を最大化します。',
    category: 'marketing',
    features: ['リンク管理', '成果追跡', 'レポート生成', '複数ASP対応'],
    icon: 'TrendingUp',
    color: 'from-green-500 to-teal-500',
  },
  {
    id: 'email-automation',
    name: 'メール自動配信システム',
    nameEn: 'Email Automation',
    description: '顧客の行動に応じて自動でメールを配信。開封率やクリック率も分析。',
    category: 'marketing',
    features: ['シナリオ配信', 'セグメント配信', 'A/Bテスト', '効果分析'],
    icon: 'Mail',
    color: 'from-yellow-500 to-orange-500',
  },
  {
    id: 'chatbot-ai',
    name: 'AIチャットボット',
    nameEn: 'AI Chatbot',
    description: '24時間365日顧客対応。FAQから複雑な質問まで自動応答します。',
    category: 'ai',
    features: ['自然言語処理', '多言語対応', '学習機能', 'API連携'],
    icon: 'Bot',
    color: 'from-cyan-500 to-blue-500',
  },
  {
    id: 'document-ai',
    name: '文書作成AI',
    nameEn: 'Document AI',
    description: '議事録や報告書を自動生成。音声入力にも対応しています。',
    category: 'ai',
    features: ['自動文書生成', '音声入力対応', 'テンプレート豊富', 'PDF出力'],
    icon: 'FileText',
    color: 'from-slate-500 to-gray-500',
  },
  {
    id: 'invoice-system',
    name: '請求書管理システム',
    nameEn: 'Invoice Management',
    description: '請求書の作成から送付、入金管理まで一元化。電子帳簿保存法にも対応。',
    category: 'management',
    features: ['請求書作成', '自動送付', '入金管理', '電子帳簿対応'],
    icon: 'Receipt',
    color: 'from-emerald-500 to-green-500',
  },
  {
    id: 'project-management',
    name: 'プロジェクト管理システム',
    nameEn: 'Project Management',
    description: 'タスク管理からガントチャートまで。チーム全体の進捗を可視化します。',
    category: 'management',
    features: ['タスク管理', 'ガントチャート', '工数管理', 'チャット機能'],
    icon: 'Briefcase',
    color: 'from-purple-500 to-indigo-500',
  },
  {
    id: 'analytics-dashboard',
    name: '分析ダッシュボード',
    nameEn: 'Analytics Dashboard',
    description: '各種データを統合して可視化。経営判断に必要な情報を一目で把握。',
    category: 'management',
    features: ['リアルタイム分析', 'カスタムレポート', 'データ統合', 'アラート機能'],
    icon: 'BarChart3',
    color: 'from-blue-500 to-purple-500',
  },
  {
    id: 'contract-management',
    name: '契約管理システム',
    nameEn: 'Contract Management',
    description: '契約書の作成から更新期限の管理まで。電子署名にも対応しています。',
    category: 'management',
    features: ['契約書作成', '期限管理', '電子署名', 'バージョン管理'],
    icon: 'FileCheck',
    color: 'from-indigo-500 to-blue-500',
  },
  {
    id: 'seo-optimizer',
    name: 'SEO最適化システム',
    nameEn: 'SEO Optimizer',
    description: 'WebサイトのSEOを自動分析し、改善提案を行います。検索順位も追跡。',
    category: 'marketing',
    features: ['SEO分析', 'キーワード提案', '順位追跡', '競合分析'],
    icon: 'Search',
    color: 'from-green-500 to-lime-500',
  },
  {
    id: 'workflow-automation',
    name: 'ワークフロー自動化',
    nameEn: 'Workflow Automation',
    description: '承認フローや定型業務を自動化。ノーコードで簡単に設定できます。',
    category: 'automation',
    features: ['承認フロー', 'ノーコード設定', '各種ツール連携', '実行ログ'],
    icon: 'Workflow',
    color: 'from-orange-500 to-amber-500',
  },
];

export type PlanType = 'starter' | 'business' | 'enterprise';

export interface Plan {
  id: PlanType;
  name: string;
  nameEn: string;
  price: number;
  systemLimit: number;
  features: string[];
  popular?: boolean;
  stripePriceId: string; // Stripe Price ID
}

export const PLANS: Plan[] = [
  {
    id: 'starter',
    name: 'スターター',
    nameEn: 'Starter',
    price: 29800,
    systemLimit: 5,
    features: [
      '5つのシステムを利用可能',
      '基本的なサポート',
      'メールサポート',
      '月次レポート',
    ],
    stripePriceId: process.env.STRIPE_PRICE_STARTER || 'price_starter',
  },
  {
    id: 'business',
    name: 'ビジネス',
    nameEn: 'Business',
    price: 59800,
    systemLimit: 12,
    features: [
      '12個のシステムを利用可能',
      '優先サポート',
      'チャット・メールサポート',
      '週次レポート',
      'API連携可能',
    ],
    popular: true,
    stripePriceId: process.env.STRIPE_PRICE_BUSINESS || 'price_business',
  },
  {
    id: 'enterprise',
    name: 'エンタープライズ',
    nameEn: 'Enterprise',
    price: 99800,
    systemLimit: 20,
    features: [
      '全20個のシステムを利用可能',
      '専任サポート担当',
      '24時間サポート',
      'リアルタイムレポート',
      'API連携無制限',
      'カスタマイズ対応',
    ],
    stripePriceId: process.env.STRIPE_PRICE_ENTERPRISE || 'price_enterprise',
  },
];
