CREATE TABLE `customer_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customer_id` int NOT NULL,
	`user_id` int NOT NULL,
	`type` enum('contact','meeting','email','call','note') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customer_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`company_name` varchar(255),
	`contact_name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(50),
	`postal_code` varchar(20),
	`address` text,
	`status` enum('lead','prospect','customer','inactive') NOT NULL DEFAULT 'lead',
	`tags` text,
	`notes` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
