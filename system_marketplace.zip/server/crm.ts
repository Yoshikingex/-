import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { customers, customerHistory } from "../drizzle/schema";
import { eq, and, like, or, desc } from "drizzle-orm";

export const crmRouter = router({
  /**
   * 顧客一覧を取得
   */
  getCustomers: protectedProcedure
    .input(
      z.object({
        search: z.string().optional(),
        status: z.enum(["lead", "prospect", "customer", "inactive"]).optional(),
        tag: z.string().optional(),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      let query = db
        .select()
        .from(customers)
        .where(eq(customers.userId, ctx.user.id))
        .$dynamic();

      // 検索フィルター
      if (input?.search) {
        query = query.where(
          or(
            like(customers.companyName, `%${input.search}%`),
            like(customers.contactName, `%${input.search}%`),
            like(customers.email, `%${input.search}%`)
          )
        );
      }

      // ステータスフィルター
      if (input?.status) {
        query = query.where(eq(customers.status, input.status));
      }

      // タグフィルター
      if (input?.tag) {
        query = query.where(like(customers.tags, `%${input.tag}%`));
      }

      const result = await query.orderBy(desc(customers.createdAt));
      return result;
    }),

  /**
   * 顧客詳細を取得
   */
  getCustomer: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const result = await db
        .select()
        .from(customers)
        .where(
          and(
            eq(customers.id, input.id),
            eq(customers.userId, ctx.user.id)
          )
        )
        .limit(1);

      if (result.length === 0) {
        throw new Error("顧客が見つかりません");
      }

      return result[0];
    }),

  /**
   * 顧客を作成
   */
  createCustomer: protectedProcedure
    .input(
      z.object({
        companyName: z.string().optional(),
        contactName: z.string().min(1, "担当者名は必須です"),
        email: z.string().email("有効なメールアドレスを入力してください").optional().or(z.literal("")),
        phone: z.string().optional(),
        postalCode: z.string().optional(),
        address: z.string().optional(),
        status: z.enum(["lead", "prospect", "customer", "inactive"]).default("lead"),
        tags: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      const result = await db.insert(customers).values({
        userId: ctx.user.id,
        companyName: input.companyName || null,
        contactName: input.contactName,
        email: input.email || null,
        phone: input.phone || null,
        postalCode: input.postalCode || null,
        address: input.address || null,
        status: input.status,
        tags: input.tags || null,
        notes: input.notes || null,
      }).$returningId();

      return { id: result[0].id, success: true };
    }),

  /**
   * 顧客を更新
   */
  updateCustomer: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        companyName: z.string().optional(),
        contactName: z.string().min(1, "担当者名は必須です"),
        email: z.string().email("有効なメールアドレスを入力してください").optional().or(z.literal("")),
        phone: z.string().optional(),
        postalCode: z.string().optional(),
        address: z.string().optional(),
        status: z.enum(["lead", "prospect", "customer", "inactive"]),
        tags: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      await db
        .update(customers)
        .set({
          companyName: input.companyName || null,
          contactName: input.contactName,
          email: input.email || null,
          phone: input.phone || null,
          postalCode: input.postalCode || null,
          address: input.address || null,
          status: input.status,
          tags: input.tags || null,
          notes: input.notes || null,
        })
        .where(
          and(
            eq(customers.id, input.id),
            eq(customers.userId, ctx.user.id)
          )
        );

      return { success: true };
    }),

  /**
   * 顧客を削除
   */
  deleteCustomer: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // 顧客履歴も削除
      await db
        .delete(customerHistory)
        .where(eq(customerHistory.customerId, input.id));

      // 顧客を削除
      await db
        .delete(customers)
        .where(
          and(
            eq(customers.id, input.id),
            eq(customers.userId, ctx.user.id)
          )
        );

      return { success: true };
    }),

  /**
   * 顧客履歴を取得
   */
  getCustomerHistory: protectedProcedure
    .input(z.object({ customerId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // 顧客が自分のものか確認
      const customer = await db
        .select()
        .from(customers)
        .where(
          and(
            eq(customers.id, input.customerId),
            eq(customers.userId, ctx.user.id)
          )
        )
        .limit(1);

      if (customer.length === 0) {
        throw new Error("顧客が見つかりません");
      }

      const history = await db
        .select()
        .from(customerHistory)
        .where(eq(customerHistory.customerId, input.customerId))
        .orderBy(desc(customerHistory.createdAt));

      return history;
    }),

  /**
   * 顧客履歴を追加
   */
  addCustomerHistory: protectedProcedure
    .input(
      z.object({
        customerId: z.number(),
        type: z.enum(["contact", "meeting", "email", "call", "note"]),
        title: z.string().min(1, "タイトルは必須です"),
        content: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // 顧客が自分のものか確認
      const customer = await db
        .select()
        .from(customers)
        .where(
          and(
            eq(customers.id, input.customerId),
            eq(customers.userId, ctx.user.id)
          )
        )
        .limit(1);

      if (customer.length === 0) {
        throw new Error("顧客が見つかりません");
      }

      const result = await db.insert(customerHistory).values({
        customerId: input.customerId,
        userId: ctx.user.id,
        type: input.type,
        title: input.title,
        content: input.content || null,
      }).$returningId();

      return { id: result[0].id, success: true };
    }),

  /**
   * 顧客履歴を削除
   */
  deleteCustomerHistory: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      await db
        .delete(customerHistory)
        .where(
          and(
            eq(customerHistory.id, input.id),
            eq(customerHistory.userId, ctx.user.id)
          )
        );

      return { success: true };
    }),

  /**
   * 統計情報を取得
   */
  getStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      throw new Error("データベースに接続できません");
    }

    const allCustomers = await db
      .select()
      .from(customers)
      .where(eq(customers.userId, ctx.user.id));

    const stats = {
      total: allCustomers.length,
      lead: allCustomers.filter(c => c.status === "lead").length,
      prospect: allCustomers.filter(c => c.status === "prospect").length,
      customer: allCustomers.filter(c => c.status === "customer").length,
      inactive: allCustomers.filter(c => c.status === "inactive").length,
    };

    return stats;
  }),
});
