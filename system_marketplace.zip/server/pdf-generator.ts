import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import { systems } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import PDFDocument from "pdfkit";
import { PLANS } from "../shared/systems";

export const pdfGeneratorRouter = router({
  /**
   * システムの営業用PDF資料を生成
   */
  generateSystemPDF: protectedProcedure
    .input(
      z.object({
        systemId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // 管理者権限チェック
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "管理者のみアクセス可能です" });
      }

      const db = await getDb();
      if (!db) {
        throw new Error("データベースに接続できません");
      }

      // システム情報を取得
      const systemResult = await db
        .select()
        .from(systems)
        .where(eq(systems.id, input.systemId))
        .limit(1);

      if (systemResult.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "システムが見つかりません" });
      }

      const system = systemResult[0];

      // PDFを生成
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 50, bottom: 50, left: 50, right: 50 },
      });

      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));

      return new Promise<{ pdfBase64: string; fileName: string }>((resolve, reject) => {
        doc.on("end", () => {
          const pdfBuffer = Buffer.concat(chunks);
          const pdfBase64 = pdfBuffer.toString("base64");
          resolve({
            pdfBase64,
            fileName: `${system.name}_営業資料.pdf`,
          });
        });

        doc.on("error", reject);

        // PDFコンテンツを作成
        try {
          // ヘッダー
          doc
            .fontSize(28)
            .fillColor("#2563eb")
            .text("System Marketplace", { align: "center" });

          doc.moveDown(0.5);
          doc
            .fontSize(12)
            .fillColor("#666666")
            .text("業務効率化システム販売プラットフォーム", { align: "center" });

          doc.moveDown(2);

          // システム名
          doc
            .fontSize(24)
            .fillColor("#000000")
            .text(system.name || "", { align: "center" });



          doc.moveDown(2);

          // カテゴリー
          const categoryMap: Record<string, string> = {
            ai: "AI技術",
            management: "業務管理",
            marketing: "マーケティング",
            automation: "自動化",
          };
          const categoryName = categoryMap[system.category as string] || system.category;

          doc
            .fontSize(12)
            .fillColor("#2563eb")
            .text(`カテゴリー: ${categoryName}`, { align: "center" });

          doc.moveDown(2);

          // 区切り線
          doc
            .moveTo(50, doc.y)
            .lineTo(545, doc.y)
            .strokeColor("#cccccc")
            .stroke();

          doc.moveDown(1);

          // システム概要
          doc
            .fontSize(18)
            .fillColor("#000000")
            .text("システム概要");

          doc.moveDown(0.5);
          doc
            .fontSize(12)
            .fillColor("#333333")
            .text(system.description || "", { align: "justify" });

          doc.moveDown(2);

          // 主な機能
          doc
            .fontSize(18)
            .fillColor("#000000")
            .text("主な機能");

          doc.moveDown(0.5);
          const features = [
            "直感的で使いやすいインターフェース",
            "高速処理とリアルタイム同期",
            "セキュアなデータ管理",
            "他システムとの連携機能",
            "カスタマイズ可能な設定",
          ];

          features.forEach((feature) => {
            doc
              .fontSize(12)
              .fillColor("#333333")
              .text(`• ${feature}`, { indent: 20 });
            doc.moveDown(0.3);
          });

          doc.moveDown(1);

          // 料金プラン
          doc
            .fontSize(18)
            .fillColor("#000000")
            .text("料金プラン");

          doc.moveDown(0.5);

          PLANS.forEach((plan) => {
            doc
              .fontSize(14)
              .fillColor("#2563eb")
              .text(plan.name);

            doc.moveDown(0.3);
            doc
              .fontSize(12)
              .fillColor("#333333")
              .text(`月額: ¥${plan.price.toLocaleString()}`, { indent: 20 });

            doc
              .fontSize(12)
              .fillColor("#666666")
              .text(`利用可能システム数: ${plan.systemLimit}個`, { indent: 20 });

            doc.moveDown(0.8);
          });

          doc.moveDown(1);

          // 導入メリット
          doc
            .fontSize(18)
            .fillColor("#000000")
            .text("導入メリット");

          doc.moveDown(0.5);
          const benefits = [
            "業務効率が最大70%向上",
            "導入後すぐに利用開始可能",
            "専任サポートチームによる手厚いサポート",
            "定期的な機能アップデート",
            "エンタープライズグレードのセキュリティ",
          ];

          benefits.forEach((benefit) => {
            doc
              .fontSize(12)
              .fillColor("#333333")
              .text(`✓ ${benefit}`, { indent: 20 });
            doc.moveDown(0.3);
          });

          // フッター
          doc.moveDown(3);
          doc
            .moveTo(50, doc.y)
            .lineTo(545, doc.y)
            .strokeColor("#cccccc")
            .stroke();

          doc.moveDown(0.5);
          doc
            .fontSize(10)
            .fillColor("#666666")
            .text("お問い合わせ: info@system-marketplace.com", { align: "center" });

          doc
            .fontSize(10)
            .fillColor("#666666")
            .text("© 2026 System Marketplace. All rights reserved.", { align: "center" });

          doc.end();
        } catch (error) {
          reject(error);
        }
      });
    }),
});
