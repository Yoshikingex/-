import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { users } from "../drizzle/schema";

describe("CRM機能テスト", () => {
  let testUser: any;
  let caller: any;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("データベースに接続できません");

    // テストユーザーを作成
    const result = await db
      .insert(users)
      .values({
        openId: `test-crm-${Date.now()}`,
        name: "CRMテストユーザー",
        email: "crm-test@example.com",
        role: "user",
      })
      .$returningId();

    testUser = { id: result[0].id, openId: `test-crm-${Date.now()}`, name: "CRMテストユーザー", role: "user" };

    // tRPC callerを作成
    caller = appRouter.createCaller({
      user: testUser,
      req: {} as any,
      res: {} as any,
    });
  });

  it("顧客を作成できる", async () => {
    const result = await caller.crm.createCustomer({
      companyName: "テスト株式会社",
      contactName: "山田太郎",
      email: "yamada@test.com",
      phone: "03-1234-5678",
      status: "lead",
      tags: "VIP, IT業界",
      notes: "テスト顧客です",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeGreaterThan(0);
  });

  it("顧客一覧を取得できる", async () => {
    const customers = await caller.crm.getCustomers({});
    expect(Array.isArray(customers)).toBe(true);
    expect(customers.length).toBeGreaterThan(0);
  });

  it("顧客を検索できる", async () => {
    const customers = await caller.crm.getCustomers({
      search: "山田",
    });
    expect(Array.isArray(customers)).toBe(true);
    expect(customers.some((c: any) => c.contactName.includes("山田"))).toBe(true);
  });

  it("ステータスでフィルターできる", async () => {
    const customers = await caller.crm.getCustomers({
      status: "lead",
    });
    expect(Array.isArray(customers)).toBe(true);
    expect(customers.every((c: any) => c.status === "lead")).toBe(true);
  });

  it("顧客情報を更新できる", async () => {
    // まず顧客を作成
    const createResult = await caller.crm.createCustomer({
      contactName: "更新テスト",
      status: "lead",
    });

    // 顧客情報を更新
    const updateResult = await caller.crm.updateCustomer({
      id: createResult.id,
      contactName: "更新後の名前",
      status: "customer",
    });

    expect(updateResult.success).toBe(true);

    // 更新されたか確認
    const customer = await caller.crm.getCustomer({ id: createResult.id });
    expect(customer.contactName).toBe("更新後の名前");
    expect(customer.status).toBe("customer");
  });

  it("顧客履歴を追加できる", async () => {
    // まず顧客を作成
    const createResult = await caller.crm.createCustomer({
      contactName: "履歴テスト",
      status: "lead",
    });

    // 顧客履歴を追加
    const historyResult = await caller.crm.addCustomerHistory({
      customerId: createResult.id,
      type: "meeting",
      title: "初回商談",
      content: "商談の内容...",
    });

    expect(historyResult.success).toBe(true);

    // 履歴を取得
    const history = await caller.crm.getCustomerHistory({ customerId: createResult.id });
    expect(Array.isArray(history)).toBe(true);
    expect(history.length).toBeGreaterThan(0);
    expect(history[0].title).toBe("初回商談");
  });

  it("統計情報を取得できる", async () => {
    const stats = await caller.crm.getStats();
    expect(stats).toHaveProperty("total");
    expect(stats).toHaveProperty("lead");
    expect(stats).toHaveProperty("prospect");
    expect(stats).toHaveProperty("customer");
    expect(stats).toHaveProperty("inactive");
    expect(stats.total).toBeGreaterThan(0);
  });

  it("顧客を削除できる", async () => {
    // まず顧客を作成
    const createResult = await caller.crm.createCustomer({
      contactName: "削除テスト",
      status: "lead",
    });

    // 顧客を削除
    const deleteResult = await caller.crm.deleteCustomer({ id: createResult.id });
    expect(deleteResult.success).toBe(true);

    // 削除されたか確認（エラーが発生するはず）
    await expect(caller.crm.getCustomer({ id: createResult.id })).rejects.toThrow();
  });
});
