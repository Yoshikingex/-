import { eq, and, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, systems, userSystems, subscriptionHistory, InsertSystem, InsertUserSystem, InsertSubscriptionHistory } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "stripeCustomerId", "stripeSubscriptionId"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    
    // Subscription fields
    if (user.currentPlan !== undefined) {
      values.currentPlan = user.currentPlan;
      updateSet.currentPlan = user.currentPlan;
    }
    if (user.subscriptionStatus !== undefined) {
      values.subscriptionStatus = user.subscriptionStatus;
      updateSet.subscriptionStatus = user.subscriptionStatus;
    }
    if (user.subscriptionStartDate !== undefined) {
      values.subscriptionStartDate = user.subscriptionStartDate;
      updateSet.subscriptionStartDate = user.subscriptionStartDate;
    }
    if (user.subscriptionEndDate !== undefined) {
      values.subscriptionEndDate = user.subscriptionEndDate;
      updateSet.subscriptionEndDate = user.subscriptionEndDate;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserSubscription(
  userId: number,
  data: {
    currentPlan?: "starter" | "business" | "enterprise" | null;
    stripeSubscriptionId?: string | null;
    subscriptionStatus?: "active" | "canceled" | "past_due" | "incomplete" | "trialing" | null;
    subscriptionStartDate?: Date | null;
    subscriptionEndDate?: Date | null;
    stripeCustomerId?: string | null;
  }
) {
  const db = await getDb();
  if (!db) return;

  await db.update(users).set(data).where(eq(users.id, userId));
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users);
}

// ========== System Management ==========

export async function getAllSystems() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(systems).where(eq(systems.isActive, true));
}

export async function getSystemById(systemId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(systems).where(eq(systems.id, systemId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}



export async function createSystem(system: InsertSystem) {
  const db = await getDb();
  if (!db) return;

  await db.insert(systems).values(system);
}

export async function bulkCreateSystems(systemList: InsertSystem[]) {
  const db = await getDb();
  if (!db) return;

  await db.insert(systems).values(systemList);
}

// ========== User Systems Management ==========

export async function getUserSystems(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select({
      id: userSystems.id,
      userId: userSystems.userId,
      systemId: userSystems.systemId,
      addedAt: userSystems.addedAt,
      system: systems,
    })
    .from(userSystems)
    .leftJoin(systems, eq(userSystems.systemId, systems.id))
    .where(eq(userSystems.userId, userId));

  return result;
}

export async function addUserSystem(data: InsertUserSystem) {
  const db = await getDb();
  if (!db) return;

  await db.insert(userSystems).values(data).onDuplicateKeyUpdate({
    set: { addedAt: new Date() },
  });
}

export async function removeUserSystem(userId: number, systemId: number) {
  const db = await getDb();
  if (!db) return;

  await db.delete(userSystems).where(
    and(
      eq(userSystems.userId, userId),
      eq(userSystems.systemId, systemId)
    )
  );
}

export async function removeAllUserSystems(userId: number) {
  const db = await getDb();
  if (!db) return;

  await db.delete(userSystems).where(eq(userSystems.userId, userId));
}

export async function setUserSystems(userId: number, systemIds: number[]) {
  const db = await getDb();
  if (!db) return;

  await removeAllUserSystems(userId);

  if (systemIds.length > 0) {
    const values = systemIds.map(systemId => ({
      userId,
      systemId,
    }));
    await db.insert(userSystems).values(values);
  }
}

// ========== Subscription History ==========

export async function addSubscriptionHistory(data: InsertSubscriptionHistory) {
  const db = await getDb();
  if (!db) return;

  await db.insert(subscriptionHistory).values(data);
}

export async function getSubscriptionHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(subscriptionHistory)
    .where(eq(subscriptionHistory.userId, userId));
}

export async function getAllSubscriptionHistory() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(subscriptionHistory);
}
