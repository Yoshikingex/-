import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { SystemHeader } from "@/components/SystemHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Edit, FileText, Send, CheckCircle, XCircle, Clock, Eye } from "lucide-react";
import { toast } from "sonner";
import { QuotationPreview } from "@/components/QuotationPreview";
import { InvoicePreview } from "@/components/InvoicePreview";

type QuotationItem = {
  itemName: string;
  description?: string;
  quantity: number;
  unitPrice: number;
};

type InvoiceItem = {
  itemName: string;
  description?: string;
  quantity: number;
  unitPrice: number;
};

export default function QuotationInvoice() {
  // toast from sonner
  const [activeTab, setActiveTab] = useState<"quotations" | "invoices">("quotations");
  
  // 見積書関連
  const [isQuotationDialogOpen, setIsQuotationDialogOpen] = useState(false);
  const [editingQuotation, setEditingQuotation] = useState<any>(null);
  const [quotationItems, setQuotationItems] = useState<QuotationItem[]>([
    { itemName: "", description: "", quantity: 1, unitPrice: 0 }
  ]);
  
  // 請求書関連
  const [isInvoiceDialogOpen, setIsInvoiceDialogOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<any>(null);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([
    { itemName: "", description: "", quantity: 1, unitPrice: 0 }
  ]);

  // プレビュー関連
  const [previewQuotationId, setPreviewQuotationId] = useState<number | null>(null);
  const [previewInvoiceId, setPreviewInvoiceId] = useState<number | null>(null);
  const { data: quotationDetail } = trpc.quotationInvoice.getQuotationDetail.useQuery(
    { id: previewQuotationId! },
    { enabled: !!previewQuotationId }
  );
  const { data: invoiceDetail } = trpc.quotationInvoice.getInvoiceDetail.useQuery(
    { id: previewInvoiceId! },
    { enabled: !!previewInvoiceId }
  );

  // データ取得
  const { data: quotations = [], refetch: refetchQuotations } = trpc.quotationInvoice.getQuotations.useQuery();
  const { data: invoices = [], refetch: refetchInvoices } = trpc.quotationInvoice.getInvoices.useQuery();
  const { data: customers = [] } = trpc.quotationInvoice.getCustomers.useQuery();

  // Mutations
  const createQuotation = trpc.quotationInvoice.createQuotation.useMutation({
    onSuccess: () => {
      toast.success("見積書を作成しました");
      refetchQuotations();
      setIsQuotationDialogOpen(false);
      resetQuotationForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const updateQuotation = trpc.quotationInvoice.updateQuotation.useMutation({
    onSuccess: () => {
      toast.success("見積書を更新しました");
      refetchQuotations();
      setIsQuotationDialogOpen(false);
      resetQuotationForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const deleteQuotation = trpc.quotationInvoice.deleteQuotation.useMutation({
    onSuccess: () => {
      toast.success("見積書を削除しました");
      refetchQuotations();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const createInvoice = trpc.quotationInvoice.createInvoice.useMutation({
    onSuccess: () => {
      toast.success("請求書を作成しました");
      refetchInvoices();
      setIsInvoiceDialogOpen(false);
      resetInvoiceForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const updateInvoice = trpc.quotationInvoice.updateInvoice.useMutation({
    onSuccess: () => {
      toast.success("請求書を更新しました");
      refetchInvoices();
      setIsInvoiceDialogOpen(false);
      resetInvoiceForm();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const deleteInvoice = trpc.quotationInvoice.deleteInvoice.useMutation({
    onSuccess: () => {
      toast.success("請求書を削除しました");
      refetchInvoices();
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  const createInvoiceFromQuotation = trpc.quotationInvoice.createInvoiceFromQuotation.useMutation({
    onSuccess: () => {
      toast.success("見積書から請求書を作成しました");
      refetchInvoices();
      setActiveTab("invoices");
    },
    onError: (error) => {
      toast.error(`エラー: ${error.message}`);
    }
  });

  // フォームリセット
  const resetQuotationForm = () => {
    setEditingQuotation(null);
    setQuotationItems([{ itemName: "", description: "", quantity: 1, unitPrice: 0 }]);
  };

  const resetInvoiceForm = () => {
    setEditingInvoice(null);
    setInvoiceItems([{ itemName: "", description: "", quantity: 1, unitPrice: 0 }]);
  };

  // 見積書明細の追加・削除
  const addQuotationItem = () => {
    setQuotationItems([...quotationItems, { itemName: "", description: "", quantity: 1, unitPrice: 0 }]);
  };

  const removeQuotationItem = (index: number) => {
    setQuotationItems(quotationItems.filter((_, i) => i !== index));
  };

  const updateQuotationItem = (index: number, field: keyof QuotationItem, value: any) => {
    const newItems = [...quotationItems];
    newItems[index] = { ...newItems[index], [field]: value };
    setQuotationItems(newItems);
  };

  // 請求書明細の追加・削除
  const addInvoiceItem = () => {
    setInvoiceItems([...invoiceItems, { itemName: "", description: "", quantity: 1, unitPrice: 0 }]);
  };

  const removeInvoiceItem = (index: number) => {
    setInvoiceItems(invoiceItems.filter((_, i) => i !== index));
  };

  const updateInvoiceItem = (index: number, field: keyof InvoiceItem, value: any) => {
    const newItems = [...invoiceItems];
    newItems[index] = { ...newItems[index], [field]: value };
    setInvoiceItems(newItems);
  };

  // 金額計算
  const calculateQuotationTotal = () => {
    const subtotal = quotationItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    const tax = Math.floor(subtotal * 0.1);
    return { subtotal, tax, total: subtotal + tax };
  };

  const calculateInvoiceTotal = () => {
    const subtotal = invoiceItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    const tax = Math.floor(subtotal * 0.1);
    return { subtotal, tax, total: subtotal + tax };
  };

  // 見積書フォーム送信
  const handleQuotationSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const customerId = formData.get("customerId") as string;
    const data = {
      quotationNumber: formData.get("quotationNumber") as string,
      customerId: customerId && customerId !== "new" ? Number(customerId) : undefined,
      customerName: formData.get("customerName") as string,
      customerEmail: formData.get("customerEmail") as string || undefined,
      customerAddress: formData.get("customerAddress") as string || undefined,
      title: formData.get("title") as string,
      issueDate: formData.get("issueDate") as string,
      expiryDate: formData.get("expiryDate") as string || undefined,
      notes: formData.get("notes") as string || undefined,
      items: quotationItems.filter(item => item.itemName.trim() !== ""),
    };

    if (editingQuotation) {
      updateQuotation.mutate({ id: editingQuotation.id, ...data });
    } else {
      createQuotation.mutate(data);
    }
  };

  // 請求書フォーム送信
  const handleInvoiceSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const customerId = formData.get("customerId") as string;
    const data = {
      invoiceNumber: formData.get("invoiceNumber") as string,
      customerId: customerId && customerId !== "new" ? Number(customerId) : undefined,
      customerName: formData.get("customerName") as string,
      customerEmail: formData.get("customerEmail") as string || undefined,
      customerAddress: formData.get("customerAddress") as string || undefined,
      title: formData.get("title") as string,
      issueDate: formData.get("issueDate") as string,
      dueDate: formData.get("dueDate") as string,
      paymentMethod: formData.get("paymentMethod") as string || undefined,
      bankInfo: formData.get("bankInfo") as string || undefined,
      notes: formData.get("notes") as string || undefined,
      items: invoiceItems.filter(item => item.itemName.trim() !== ""),
    };

    if (editingInvoice) {
      updateInvoice.mutate({ id: editingInvoice.id, ...data });
    } else {
      createInvoice.mutate(data);
    }
  };

  // ステータスアイコン
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft": return <Clock className="h-4 w-4 text-gray-500" />;
      case "sent": return <Send className="h-4 w-4 text-blue-500" />;
      case "accepted": return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "rejected": return <XCircle className="h-4 w-4 text-red-500" />;
      case "paid": return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "overdue": return <XCircle className="h-4 w-4 text-red-500" />;
      case "canceled": return <XCircle className="h-4 w-4 text-gray-500" />;
      default: return null;
    }
  };

  // ステータスラベル
  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      draft: "下書き",
      sent: "送信済み",
      accepted: "承認済み",
      rejected: "却下",
      paid: "支払済み",
      overdue: "期限超過",
      canceled: "キャンセル",
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <SystemHeader />
      
      <div className="container mx-auto py-8 px-4">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">見積書・請求書作成</h1>
          <p className="text-gray-600 mt-2">見積書と請求書を簡単に作成・管理できます</p>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "quotations" | "invoices")}>
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="quotations">見積書</TabsTrigger>
            <TabsTrigger value="invoices">請求書</TabsTrigger>
          </TabsList>

          {/* 見積書タブ */}
          <TabsContent value="quotations" className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={isQuotationDialogOpen} onOpenChange={setIsQuotationDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={resetQuotationForm}>
                    <Plus className="h-4 w-4 mr-2" />
                    新規見積書
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingQuotation ? "見積書を編集" : "新規見積書を作成"}</DialogTitle>
                    <DialogDescription>
                      見積書の情報を入力してください
                    </DialogDescription>
                  </DialogHeader>
                  
                  <form onSubmit={handleQuotationSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="quotationNumber">見積書番号 *</Label>
                        <Input
                          id="quotationNumber"
                          name="quotationNumber"
                          defaultValue={editingQuotation?.quotationNumber}
                          required
                          placeholder="Q-2024-001"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerId">顧客選択</Label>
                        <Select name="customerId" defaultValue={editingQuotation?.customerId?.toString()}>
                          <SelectTrigger>
                            <SelectValue placeholder="顧客を選択" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="new">新規顧客</SelectItem>
                            {customers.map((customer) => (
                              <SelectItem key={customer.id} value={customer.id.toString()}>
                                {customer.companyName || customer.contactName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="customerName">顧客名 *</Label>
                        <Input
                          id="customerName"
                          name="customerName"
                          defaultValue={editingQuotation?.customerName}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerEmail">メールアドレス</Label>
                        <Input
                          id="customerEmail"
                          name="customerEmail"
                          type="email"
                          defaultValue={editingQuotation?.customerEmail}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="customerAddress">住所</Label>
                      <Textarea
                        id="customerAddress"
                        name="customerAddress"
                        defaultValue={editingQuotation?.customerAddress}
                        rows={2}
                      />
                    </div>

                    <div>
                      <Label htmlFor="title">件名 *</Label>
                      <Input
                        id="title"
                        name="title"
                        defaultValue={editingQuotation?.title}
                        required
                        placeholder="Webサイト制作のお見積り"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="issueDate">発行日 *</Label>
                        <Input
                          id="issueDate"
                          name="issueDate"
                          type="date"
                          defaultValue={editingQuotation?.issueDate ? new Date(editingQuotation.issueDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="expiryDate">有効期限</Label>
                        <Input
                          id="expiryDate"
                          name="expiryDate"
                          type="date"
                          defaultValue={editingQuotation?.expiryDate ? new Date(editingQuotation.expiryDate).toISOString().split('T')[0] : ""}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Label>明細 *</Label>
                        <Button type="button" variant="outline" size="sm" onClick={addQuotationItem}>
                          <Plus className="h-4 w-4 mr-1" />
                          明細を追加
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        {quotationItems.map((item, index) => (
                          <Card key={index}>
                            <CardContent className="pt-4">
                              <div className="grid grid-cols-12 gap-2">
                                <div className="col-span-4">
                                  <Input
                                    placeholder="商品・サービス名"
                                    value={item.itemName}
                                    onChange={(e) => updateQuotationItem(index, "itemName", e.target.value)}
                                  />
                                </div>
                                <div className="col-span-3">
                                  <Input
                                    placeholder="説明"
                                    value={item.description}
                                    onChange={(e) => updateQuotationItem(index, "description", e.target.value)}
                                  />
                                </div>
                                <div className="col-span-2">
                                  <Input
                                    type="number"
                                    placeholder="数量"
                                    value={item.quantity}
                                    onChange={(e) => updateQuotationItem(index, "quantity", Number(e.target.value))}
                                  />
                                </div>
                                <div className="col-span-2">
                                  <Input
                                    type="number"
                                    placeholder="単価"
                                    value={item.unitPrice}
                                    onChange={(e) => updateQuotationItem(index, "unitPrice", Number(e.target.value))}
                                  />
                                </div>
                                <div className="col-span-1 flex items-center justify-center">
                                  {quotationItems.length > 1 && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeQuotationItem(index)}
                                    >
                                      <Trash2 className="h-4 w-4 text-red-500" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                              <div className="text-right text-sm text-gray-600 mt-1">
                                金額: ¥{(item.quantity * item.unitPrice).toLocaleString()}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>

                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <div className="space-y-1 text-right">
                          <div className="flex justify-between">
                            <span className="text-gray-600">小計:</span>
                            <span className="font-medium">¥{calculateQuotationTotal().subtotal.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">消費税 (10%):</span>
                            <span className="font-medium">¥{calculateQuotationTotal().tax.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-lg font-bold border-t pt-1">
                            <span>合計:</span>
                            <span>¥{calculateQuotationTotal().total.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="notes">備考</Label>
                      <Textarea
                        id="notes"
                        name="notes"
                        defaultValue={editingQuotation?.notes}
                        rows={3}
                        placeholder="お支払い条件、納期などを記載"
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setIsQuotationDialogOpen(false)}>
                        キャンセル
                      </Button>
                      <Button type="submit" disabled={createQuotation.isPending || updateQuotation.isPending}>
                        {editingQuotation ? "更新" : "作成"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {quotations.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-gray-500">
                    見積書がまだありません。新規見積書を作成してください。
                  </CardContent>
                </Card>
              ) : (
                quotations.map((quotation) => (
                  <Card key={quotation.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {quotation.quotationNumber}
                            {getStatusIcon(quotation.status)}
                            <span className="text-sm font-normal text-gray-500">
                              {getStatusLabel(quotation.status)}
                            </span>
                          </CardTitle>
                          <CardDescription>{quotation.title}</CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPreviewQuotationId(quotation.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingQuotation(quotation);
                              setIsQuotationDialogOpen(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (confirm("この見積書を削除しますか？")) {
                                deleteQuotation.mutate({ id: quotation.id });
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              const invoiceNumber = `INV-${new Date().getFullYear()}-${String(invoices.length + 1).padStart(3, '0')}`;
                              const today = new Date().toISOString().split('T')[0];
                              const dueDate = new Date();
                              dueDate.setDate(dueDate.getDate() + 30);
                              
                              createInvoiceFromQuotation.mutate({
                                quotationId: quotation.id,
                                invoiceNumber,
                                issueDate: today,
                                dueDate: dueDate.toISOString().split('T')[0],
                              });
                            }}
                          >
                            <FileText className="h-4 w-4 mr-1" />
                            請求書作成
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">顧客名</p>
                          <p className="font-medium">{quotation.customerName}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">発行日</p>
                          <p className="font-medium">{new Date(quotation.issueDate).toLocaleDateString('ja-JP')}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">有効期限</p>
                          <p className="font-medium">
                            {quotation.expiryDate ? new Date(quotation.expiryDate).toLocaleDateString('ja-JP') : '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600">合計金額</p>
                          <p className="font-bold text-lg">¥{quotation.totalAmount.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* 請求書タブ */}
          <TabsContent value="invoices" className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={isInvoiceDialogOpen} onOpenChange={setIsInvoiceDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={resetInvoiceForm}>
                    <Plus className="h-4 w-4 mr-2" />
                    新規請求書
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingInvoice ? "請求書を編集" : "新規請求書を作成"}</DialogTitle>
                    <DialogDescription>
                      請求書の情報を入力してください
                    </DialogDescription>
                  </DialogHeader>
                  
                  <form onSubmit={handleInvoiceSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="invoiceNumber">請求書番号 *</Label>
                        <Input
                          id="invoiceNumber"
                          name="invoiceNumber"
                          defaultValue={editingInvoice?.invoiceNumber}
                          required
                          placeholder="INV-2024-001"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerId">顧客選択</Label>
                        <Select name="customerId" defaultValue={editingInvoice?.customerId?.toString()}>
                          <SelectTrigger>
                            <SelectValue placeholder="顧客を選択" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="new">新規顧客</SelectItem>
                            {customers.map((customer) => (
                              <SelectItem key={customer.id} value={customer.id.toString()}>
                                {customer.companyName || customer.contactName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="customerName">顧客名 *</Label>
                        <Input
                          id="customerName"
                          name="customerName"
                          defaultValue={editingInvoice?.customerName}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerEmail">メールアドレス</Label>
                        <Input
                          id="customerEmail"
                          name="customerEmail"
                          type="email"
                          defaultValue={editingInvoice?.customerEmail}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="customerAddress">住所</Label>
                      <Textarea
                        id="customerAddress"
                        name="customerAddress"
                        defaultValue={editingInvoice?.customerAddress}
                        rows={2}
                      />
                    </div>

                    <div>
                      <Label htmlFor="title">件名 *</Label>
                      <Input
                        id="title"
                        name="title"
                        defaultValue={editingInvoice?.title}
                        required
                        placeholder="Webサイト制作費用のご請求"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="issueDate">発行日 *</Label>
                        <Input
                          id="issueDate"
                          name="issueDate"
                          type="date"
                          defaultValue={editingInvoice?.issueDate ? new Date(editingInvoice.issueDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="dueDate">支払期限 *</Label>
                        <Input
                          id="dueDate"
                          name="dueDate"
                          type="date"
                          defaultValue={editingInvoice?.dueDate ? new Date(editingInvoice.dueDate).toISOString().split('T')[0] : ""}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="paymentMethod">支払方法</Label>
                        <Input
                          id="paymentMethod"
                          name="paymentMethod"
                          defaultValue={editingInvoice?.paymentMethod}
                          placeholder="銀行振込"
                        />
                      </div>
                      <div>
                        <Label htmlFor="bankInfo">振込先情報</Label>
                        <Input
                          id="bankInfo"
                          name="bankInfo"
                          defaultValue={editingInvoice?.bankInfo}
                          placeholder="○○銀行 ○○支店 普通 1234567"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Label>明細 *</Label>
                        <Button type="button" variant="outline" size="sm" onClick={addInvoiceItem}>
                          <Plus className="h-4 w-4 mr-1" />
                          明細を追加
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        {invoiceItems.map((item, index) => (
                          <Card key={index}>
                            <CardContent className="pt-4">
                              <div className="grid grid-cols-12 gap-2">
                                <div className="col-span-4">
                                  <Input
                                    placeholder="商品・サービス名"
                                    value={item.itemName}
                                    onChange={(e) => updateInvoiceItem(index, "itemName", e.target.value)}
                                  />
                                </div>
                                <div className="col-span-3">
                                  <Input
                                    placeholder="説明"
                                    value={item.description}
                                    onChange={(e) => updateInvoiceItem(index, "description", e.target.value)}
                                  />
                                </div>
                                <div className="col-span-2">
                                  <Input
                                    type="number"
                                    placeholder="数量"
                                    value={item.quantity}
                                    onChange={(e) => updateInvoiceItem(index, "quantity", Number(e.target.value))}
                                  />
                                </div>
                                <div className="col-span-2">
                                  <Input
                                    type="number"
                                    placeholder="単価"
                                    value={item.unitPrice}
                                    onChange={(e) => updateInvoiceItem(index, "unitPrice", Number(e.target.value))}
                                  />
                                </div>
                                <div className="col-span-1 flex items-center justify-center">
                                  {invoiceItems.length > 1 && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeInvoiceItem(index)}
                                    >
                                      <Trash2 className="h-4 w-4 text-red-500" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                              <div className="text-right text-sm text-gray-600 mt-1">
                                金額: ¥{(item.quantity * item.unitPrice).toLocaleString()}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>

                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <div className="space-y-1 text-right">
                          <div className="flex justify-between">
                            <span className="text-gray-600">小計:</span>
                            <span className="font-medium">¥{calculateInvoiceTotal().subtotal.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">消費税 (10%):</span>
                            <span className="font-medium">¥{calculateInvoiceTotal().tax.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-lg font-bold border-t pt-1">
                            <span>合計:</span>
                            <span>¥{calculateInvoiceTotal().total.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="notes">備考</Label>
                      <Textarea
                        id="notes"
                        name="notes"
                        defaultValue={editingInvoice?.notes}
                        rows={3}
                        placeholder="お支払い条件、納期などを記載"
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setIsInvoiceDialogOpen(false)}>
                        キャンセル
                      </Button>
                      <Button type="submit" disabled={createInvoice.isPending || updateInvoice.isPending}>
                        {editingInvoice ? "更新" : "作成"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {invoices.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-gray-500">
                    請求書がまだありません。新規請求書を作成してください。
                  </CardContent>
                </Card>
              ) : (
                invoices.map((invoice) => (
                  <Card key={invoice.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {invoice.invoiceNumber}
                            {getStatusIcon(invoice.status)}
                            <span className="text-sm font-normal text-gray-500">
                              {getStatusLabel(invoice.status)}
                            </span>
                          </CardTitle>
                          <CardDescription>{invoice.title}</CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPreviewInvoiceId(invoice.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingInvoice(invoice);
                              setIsInvoiceDialogOpen(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (confirm("この請求書を削除しますか？")) {
                                deleteInvoice.mutate({ id: invoice.id });
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">顧客名</p>
                          <p className="font-medium">{invoice.customerName}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">発行日</p>
                          <p className="font-medium">{new Date(invoice.issueDate).toLocaleDateString('ja-JP')}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">支払期限</p>
                          <p className="font-medium">{new Date(invoice.dueDate).toLocaleDateString('ja-JP')}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">合計金額</p>
                          <p className="font-bold text-lg">¥{invoice.totalAmount.toLocaleString()}</p>
                        </div>
                        {invoice.paymentMethod && (
                          <div>
                            <p className="text-gray-600">支払方法</p>
                            <p className="font-medium">{invoice.paymentMethod}</p>
                          </div>
                        )}
                        {invoice.paidAt && (
                          <div>
                            <p className="text-gray-600">支払日</p>
                            <p className="font-medium">{new Date(invoice.paidAt).toLocaleDateString('ja-JP')}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* プレビューダイアログ */}
      {quotationDetail && (
        <QuotationPreview
          open={!!previewQuotationId}
          onOpenChange={(open) => !open && setPreviewQuotationId(null)}
          quotation={quotationDetail.quotation}
          items={quotationDetail.items}
        />
      )}
      {invoiceDetail && (
        <InvoicePreview
          open={!!previewInvoiceId}
          onOpenChange={(open) => !open && setPreviewInvoiceId(null)}
          invoice={invoiceDetail.invoice}
          items={invoiceDetail.items}
        />
      )}
    </div>
  );
}
