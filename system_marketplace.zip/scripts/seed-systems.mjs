import { drizzle } from 'drizzle-orm/mysql2';
import { systems } from '../drizzle/schema.js';
import 'dotenv/config';

const SYSTEMS_DATA = [
  {
    systemId: 'bgm-ai',
    name: 'BGM生成AI',
    nameEn: 'BGM Generation AI',
    description: 'AIが自動で店舗やオフィスに最適なBGMを生成します。シーンや時間帯に応じた音楽を提供。',
    category: 'ai',
    icon: 'Music',
    color: 'from-purple-500 to-pink-500',
    isActive: true,
  },
  {
    systemId: 'customer-management',
    name: '顧客管理システム',
    nameEn: 'Customer Management',
    description: '顧客情報を一元管理し、営業活動を効率化。履歴管理やセグメント分析機能を搭載。',
    category: 'management',
    icon: 'Users',
    color: 'from-blue-500 to-cyan-500',
    isActive: true,
  },
  {
    systemId: 'attendance-management',
    name: '勤務管理システム',
    nameEn: 'Attendance Management',
    description: '従業員の出退勤を自動記録。シフト管理や残業時間の集計も簡単に。',
    category: 'management',
    icon: 'Clock',
    color: 'from-green-500 to-emerald-500',
    isActive: true,
  },
  {
    systemId: 'business-card-management',
    name: '名刺管理システム',
    nameEn: 'Business Card Management',
    description: '名刺をスキャンして自動でデータ化。OCR技術で正確に情報を抽出します。',
    category: 'management',
    icon: 'CreditCard',
    color: 'from-orange-500 to-red-500',
    isActive: true,
  },
  {
    systemId: 'ordering-system',
    name: '発注システム',
    nameEn: 'Ordering System',
    description: '在庫状況に応じて自動発注。サプライヤーとの連携もスムーズに。',
    category: 'management',
    icon: 'ShoppingCart',
    color: 'from-indigo-500 to-purple-500',
    isActive: true,
  },
  {
    systemId: 'reservation-integration',
    name: '予約統合システム',
    nameEn: 'Reservation Integration',
    description: '複数の予約チャネルを一元管理。ダブルブッキングを防止します。',
    category: 'management',
    icon: 'Calendar',
    color: 'from-teal-500 to-green-500',
    isActive: true,
  },
  {
    systemId: 'prompt-ai',
    name: 'プロンプト生成AI',
    nameEn: 'Prompt Generation AI',
    description: '目的に応じた最適なAIプロンプトを自動生成。業務効率を大幅に向上。',
    category: 'ai',
    icon: 'MessageSquare',
    color: 'from-violet-500 to-purple-500',
    isActive: true,
  },
  {
    systemId: 'image-ai',
    name: '画像生成AI',
    nameEn: 'Image Generation AI',
    description: 'テキストから高品質な画像を生成。マーケティング素材の作成に最適。',
    category: 'ai',
    icon: 'Image',
    color: 'from-pink-500 to-rose-500',
    isActive: true,
  },
  {
    systemId: 'short-video-ai',
    name: 'ショート動画生成AI',
    nameEn: 'Short Video AI',
    description: 'SNS向けショート動画を自動生成。テンプレートから簡単に作成可能。',
    category: 'ai',
    icon: 'Video',
    color: 'from-red-500 to-orange-500',
    isActive: true,
  },
  {
    systemId: 'sns-auto-post',
    name: 'SNS自動投稿システム',
    nameEn: 'SNS Auto Post',
    description: '複数のSNSに予約投稿。最適な時間帯を分析して自動投稿します。',
    category: 'marketing',
    icon: 'Share2',
    color: 'from-blue-500 to-indigo-500',
    isActive: true,
  },
  {
    systemId: 'affiliate-auto',
    name: 'アフィリエイト自動システム',
    nameEn: 'Affiliate Automation',
    description: 'アフィリエイトリンクの管理と成果を自動追跡。収益を最大化します。',
    category: 'marketing',
    icon: 'TrendingUp',
    color: 'from-green-500 to-teal-500',
    isActive: true,
  },
  {
    systemId: 'email-automation',
    name: 'メール自動配信システム',
    nameEn: 'Email Automation',
    description: '顧客の行動に応じて自動でメールを配信。開封率やクリック率も分析。',
    category: 'marketing',
    icon: 'Mail',
    color: 'from-yellow-500 to-orange-500',
    isActive: true,
  },
  {
    systemId: 'chatbot-ai',
    name: 'AIチャットボット',
    nameEn: 'AI Chatbot',
    description: '24時間365日顧客対応。FAQから複雑な質問まで自動応答します。',
    category: 'ai',
    icon: 'Bot',
    color: 'from-cyan-500 to-blue-500',
    isActive: true,
  },
  {
    systemId: 'document-ai',
    name: '文書作成AI',
    nameEn: 'Document AI',
    description: '議事録や報告書を自動生成。音声入力にも対応しています。',
    category: 'ai',
    icon: 'FileText',
    color: 'from-slate-500 to-gray-500',
    isActive: true,
  },
  {
    systemId: 'invoice-system',
    name: '請求書管理システム',
    nameEn: 'Invoice Management',
    description: '請求書の作成から送付、入金管理まで一元化。電子帳簿保存法にも対応。',
    category: 'management',
    icon: 'Receipt',
    color: 'from-emerald-500 to-green-500',
    isActive: true,
  },
  {
    systemId: 'project-management',
    name: 'プロジェクト管理システム',
    nameEn: 'Project Management',
    description: 'タスク管理からガントチャートまで。チーム全体の進捗を可視化します。',
    category: 'management',
    icon: 'Briefcase',
    color: 'from-purple-500 to-indigo-500',
    isActive: true,
  },
  {
    systemId: 'analytics-dashboard',
    name: '分析ダッシュボード',
    nameEn: 'Analytics Dashboard',
    description: '各種データを統合して可視化。経営判断に必要な情報を一目で把握。',
    category: 'management',
    icon: 'BarChart3',
    color: 'from-blue-500 to-purple-500',
    isActive: true,
  },
  {
    systemId: 'contract-management',
    name: '契約管理システム',
    nameEn: 'Contract Management',
    description: '契約書の作成から更新期限の管理まで。電子署名にも対応しています。',
    category: 'management',
    icon: 'FileCheck',
    color: 'from-indigo-500 to-blue-500',
    isActive: true,
  },
  {
    systemId: 'seo-optimizer',
    name: 'SEO最適化システム',
    nameEn: 'SEO Optimizer',
    description: 'WebサイトのSEOを自動分析し、改善提案を行います。検索順位も追跡。',
    category: 'marketing',
    icon: 'Search',
    color: 'from-green-500 to-lime-500',
    isActive: true,
  },
  {
    systemId: 'workflow-automation',
    name: 'ワークフロー自動化',
    nameEn: 'Workflow Automation',
    description: '承認フローや定型業務を自動化。ノーコードで簡単に設定できます。',
    category: 'automation',
    icon: 'Workflow',
    color: 'from-orange-500 to-amber-500',
    isActive: true,
  },
];

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL is not set');
    process.exit(1);
  }

  const db = drizzle(process.env.DATABASE_URL);

  console.log('Seeding systems...');

  for (const system of SYSTEMS_DATA) {
    try {
      await db.insert(systems).values(system).onDuplicateKeyUpdate({
        set: {
          name: system.name,
          nameEn: system.nameEn,
          description: system.description,
          category: system.category,
          icon: system.icon,
          color: system.color,
          isActive: system.isActive,
        },
      });
      console.log(`✓ ${system.name}`);
    } catch (error) {
      console.error(`✗ ${system.name}:`, error);
    }
  }

  console.log('Seeding completed!');
  process.exit(0);
}

main();
